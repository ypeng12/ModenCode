
### build 

```sam build ```

### deploy
``` sam deploy --image-repository 213059449037.dkr.ecr.us-east-1.amazonaws.com/modesens-imgcompare```


### ec2
must x86-64
```shell
sudo yum install -y docker
sudo systemctl start docker
sudo systemctl enable docker
# 下载最新稳定版 Docker Compose
DOCKER_COMPOSE_VERSION="v2.24.7"  # 可替换为最新版本（参考 GitHub 发布页）
sudo curl -SL https://github.com/docker/compose/releases/download/${DOCKER_COMPOSE_VERSION}/docker-compose-linux-x86_64 -o /usr/local/bin/docker-compose

# 赋予可执行权限
sudo chmod +x /usr/local/bin/docker-compose

# 验证安装
docker-compose --version

docker-compose build
docker-compose up -d

sudo iptables -A INPUT -p tcp --dport 80 -j ACCEPT
sudo service iptables save

```