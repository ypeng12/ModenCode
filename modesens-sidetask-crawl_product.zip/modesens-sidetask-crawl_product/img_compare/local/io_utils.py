import cv2
import numpy as np
from PIL import Image
import requests
from io import BytesIO
import re

__all__ = [
    'load_image',
    'resize_image',
    'replace_s3_url',
]

def load_image(url_or_path):
    """
    Load an image from URL or local path into an OpenCV BGR numpy array.
    """
    try:
        if isinstance(url_or_path, str) and url_or_path.startswith('http'):
            resp = requests.get(url_or_path, verify=False, timeout=5)
            if resp.status_code != 200:
                return None
            img = Image.open(BytesIO(resp.content))
            img = np.array(img)
            if img.ndim == 3 and img.shape[2] == 3:
                return cv2.cvtColor(img, cv2.COLOR_RGB2BGR)
            return img
        # local file
        return cv2.imread(url_or_path)
    except Exception:
        return None


def resize_image(img, max_dimension=800):
    """Resize image keeping aspect ratio up to max_dimension."""
    if img is None:
        return None
    h, w = img.shape[:2]
    factor = min(max_dimension / w, max_dimension / h)
    if factor >= 1.0:
        return img
    new_size = (int(w * factor), int(h * factor))
    return cv2.resize(img, new_size)


def replace_s3_url(url: str) -> str:
    """Shorten S3 URLs by removing prefix and keeping key."""
    if not url:
        return url
    if url.startswith('https://s3.amazonaws.com/'):
        last = url.split('/')[-1]
        if '-' in last and re.match(r'.*\d{6,}$', last):
            key = last.split('-')[-1]
            return url.replace(last, key)
    return url 