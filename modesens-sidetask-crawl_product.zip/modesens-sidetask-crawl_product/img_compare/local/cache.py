import os
import tempfile
import cv2
import numpy as np

# Directories for debug and cache
DEBUG_DIR = os.path.join(tempfile.gettempdir(), "img_compare_debug")
CACHE_DIR = os.path.join(tempfile.gettempdir(), "img_compare_cache")

# In-memory image cache: {url: (cropped_img, marked_img, coords)}
image_cache = {}
# Cache statistics: hits, misses, total_requests
cache_stats = {'hits': 0, 'misses': 0, 'total_requests': 0}


def get_cache_stats():
    """Return cache statistics and estimated memory usage."""
    cache_size = len(image_cache)
    memory = 0
    for _, (img, marked_img, _) in image_cache.items():
        if img is not None:
            memory += img.nbytes
        if marked_img is not None:
            memory += marked_img.nbytes
    memory_mb = memory / (1024 * 1024)
    hit_rate = 0
    total = cache_stats.get('total_requests', 0)
    if total > 0:
        hit_rate = cache_stats.get('hits', 0) / total * 100
    return {
        'cache_size': cache_size,
        'memory_usage_mb': memory_mb,
        'hits': cache_stats.get('hits', 0),
        'misses': cache_stats.get('misses', 0),
        'total_requests': total,
        'hit_rate': hit_rate
    }


def clear_image_cache():
    """Clear the in-memory image cache and reset stats."""
    global image_cache, cache_stats
    image_cache = {}
    cache_stats = {'hits': 0, 'misses': 0, 'total_requests': 0}


def preload_images(image_urls):
    """
    Preload and cache images from URLs.
    Returns number of successfully loaded images.
    """
    if not image_urls:
        return 0
    count = 0
    print(f"Preloading {len(image_urls)} images...")
    for url in image_urls:
        try:
            if url in image_cache:
                cache_stats['hits'] += 1
                cache_stats['total_requests'] += 1
                count += 1
                continue
            cache_stats['misses'] += 1
            cache_stats['total_requests'] += 1
            # use existing get_image_from_url from main or io_utils
            from img_compare.main import get_image_from_url
            img, marked, coords = get_image_from_url(url, use_cache=True)
            if img is not None:
                count += 1
        except Exception:
            pass
    print("Image preloading complete")
    stats = get_cache_stats()
    print(f"Cache stats: size={stats['cache_size']} hits={stats['hits']} misses={stats['misses']} rate={stats['hit_rate']:.2f}%")
    return count 