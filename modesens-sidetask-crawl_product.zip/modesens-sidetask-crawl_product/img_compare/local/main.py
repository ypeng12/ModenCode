import requests
import json
import cv2
import numpy as np
from PIL import Image
import os
import tempfile
from io import BytesIO
from scipy.spatial.distance import cosine
from scipy.stats import moment
from skimage.metrics import structural_similarity as ssim
from skimage.feature import local_binary_pattern
from skimage.color import rgb2hsv, rgb2lab
from skimage.feature import graycomatrix, graycoprops
import logging
import torch
import webbrowser
import time
import re
import urllib3
import mysql.connector
import math
import argparse
import sys
from pathlib import Path
import hashlib
import traceback
from img_compare.metrics.hash import (
    a_hash,
    d_hash,
    p_hash,
    compare_hash,
    calculate_hash_similarity,
)
from img_compare.metrics.color import (
    calculate_histogram_similarity as _hist_sim,
    calculate_color_moments_similarity as _cm_sim,
    calculate_hsv_histogram_similarity as _hsv_sim,
    calculate_lab_similarity as _lab_sim,
    calculate_color_moments as _cm,
)
from img_compare.metrics.texture import (
    calculate_texture_similarity as _tex_sim,
    calculate_glcm_similarity as _glcm_sim,
    calculate_gabor_similarity as _gabor_sim,
)
from img_compare.metrics.shape import (
    calculate_shape_similarity as _shape_sim,
    calculate_hu_moments as _hu_m,
)
from img_compare.metrics.deep import calculate_fashion_clip_similarity as _clip_sim
from img_compare.cache import DEBUG_DIR, CACHE_DIR, image_cache, cache_stats, get_cache_stats, clear_image_cache, \
    preload_images
from img_compare.contour_utils import contour_overlap_similarity, feature_contour_similarity
from img_compare.io_utils import load_image, resize_image, replace_s3_url
from img_compare.report import generate_html_report

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

# Constants
CSRF_TOKEN = ""

SESSION_COOKIE = "otoken=kWe5wGBlvEK4AjBnj18r9JV67zpRxD"

DB = {
    'NAME': 'ladystyle',
    'USER': os.getenv(f'DB_USER', 'msproduction1'),
    'PASSWORD': os.getenv(f'DB_PASSWORD', '8aIBTE/EmWdSTTK0'),
    'HOST': 'lsdb.cnocxcr96apd.us-east-1.rds.amazonaws.com',
    'PORT': os.getenv(f'DB_PORT', '3306'),
    'CONN_MAX_AGE': 60,
    'OPTIONS': {'charset': 'utf8mb4'}
}

# Set up logging
logger = logging.getLogger(__name__)

# Global variables for FashionCLIP
fashion_clip_model = None
fashion_clip_processor = None

# Global variable to store comparison results
comparison_results = {}


def get_product_cover_url(product_ids):
    try:
        # Connect to database using configuration
        connection = mysql.connector.connect(
            host=DB['HOST'],
            user=DB['USER'],
            password=DB['PASSWORD'],
            database=DB['NAME'],
            port=int(DB['PORT'])
        )

        # Create cursor
        cursor = connection.cursor(dictionary=True)

        product_ids = [str(product_id) for product_id in product_ids]
        product_ids = ','.join(product_ids)
        query = "SELECT id, cover FROM product_product WHERE id IN (%s)" % product_ids

        # Execute query to get cover URL from product table using IN clause
        cursor.execute(query)

        # Fetch result
        result = cursor.fetchall()

        # Close cursor and connection
        cursor.close()
        connection.close()

        return {x.get("id"): x.get("cover") for x in result}
    except Exception as e:
        print(f"Error retrieving product cover from database: {str(e)}")


def scrape_merge_data(response_data=None, url="http://44.220.20.247/product/mergeexam/", params=None,
                      fetch_all=False, page_size=10, max_pages=100):
    """
    Scrapes data from the merge exam API and maps product IDs to availability IDs.

    Args:
        response_data (dict, optional): Response data if already available
        url (str): API endpoint URL
        params (dict, optional): POST parameters
        fetch_all (bool): Whether to fetch all pages of data
        page_size (int): Number of items per page
        max_pages (int): Maximum number of pages to fetch (to prevent infinite loops)

    Returns:
        dict: Dictionary mapping product IDs to lists of availability IDs
    """
    product_to_avails = {}

    # If response data is provided, process it directly
    if response_data is not None:
        return _process_response_data(response_data)

    # Initialize parameters if not provided
    if params is None:
        params = {
            "stage": 0,
            "offset": 0,
            "amount": page_size if fetch_all else page_size,
            "typ": "",
            "category": "c",
            "gender": "",
            "mid": "",
            "examer": "",
            "fromweb": 1
        }

    # Add CSRF token if needed
    if CSRF_TOKEN:
        params["csrfmiddlewaretoken"] = CSRF_TOKEN

    # If fetching a single page
    if not fetch_all:
        response = _make_api_request(url, params)
        if response:
            return _process_response_data(response)
        return {}

    # If fetching all pages
    current_page = 0
    all_results = {}

    while current_page < max_pages:
        # Update offset for pagination
        params["offset"] = current_page * page_size

        response = _make_api_request(url, params)
        if not response:
            break

        page_results = _process_response_data(response)
        all_results.update(page_results)

        # Check if we've reached the end of data
        merges = response.get("merges", [])
        if len(merges) < page_size:
            break

        current_page += 1

    # Print some cache statistics
    print("\nFinal cache statistics:")
    cache_stats = get_cache_stats()
    print(f"  Cache size: {cache_stats['cache_size']} images")
    print(f"  Memory usage: {cache_stats['memory_usage_mb']:.2f} MB")
    print(f"  Hits: {cache_stats['hits']}, Misses: {cache_stats['misses']}, Total: {cache_stats['total_requests']}")
    print(f"  Hit rate: {cache_stats['hit_rate']:.2f}%")

    return all_results


def _make_api_request(url, params):
    """Helper function to make API requests"""
    try:
        # Set up cookies
        cookies = {}
        if SESSION_COOKIE:
            # Parse the session cookie string
            cookie_parts = SESSION_COOKIE.split('=', 1)
            if len(cookie_parts) == 2:
                cookies[cookie_parts[0]] = cookie_parts[1]

        # Make the request with cookies
        response = requests.post(url, data=params, cookies=cookies, headers={"x-requested-with": "XMLHttpRequest"})

        if response.status_code != 200:
            print(f"Error: API request failed with status code {response.status_code}")
            return None

        return response.json()
    except (requests.RequestException, json.JSONDecodeError) as e:
        print(f"Error during API request: {str(e)}")
        return None


def _process_response_data(response_data):
    """Process API response data to extract product to availability mappings"""
    product_to_avails = {}

    if response_data.get("result") == "success":
        merges = response_data.get("merges", [])

        for merge in merges:
            for avail in merge.get("avails", []):
                if avail.get("product_id"):
                    if not avail.get("product_id") in product_to_avails.keys():
                        product_to_avails[avail.get("product_id")] = []

                    product_to_avails[avail.get("product_id")].append(avail)
    return product_to_avails


# Image comparison functions
def get_image_from_url(url, use_cache=True):
    """
    Download and process an image from a given URL

    Args:
        url (str): URL of the image to download
        use_cache (bool): Whether to use the image cache

    Returns:
        tuple: (cropped_image, marked_image, crop_coords)
    """
    global image_cache, cache_stats

    if not url:
        return None, None, None

    # Update URL if it's an S3 URL that needs replacement
    url = replace_s3_url(url)

    # Check if the image is in the cache
    if use_cache and url in image_cache:
        cache_stats['hits'] += 1
        cache_stats['total_requests'] += 1
        print(f"CACHE HIT: Using cached image for {url[:50]}...")
        return image_cache[url]

    cache_stats['misses'] += 1
    cache_stats['total_requests'] += 1
    print(f"CACHE MISS: Downloading image from {url[:50]}...")

    try:
        # Set up cookies
        cookies = {}
        if SESSION_COOKIE:
            # Parse the session cookie string
            cookie_parts = SESSION_COOKIE.split('=', 1)
            if len(cookie_parts) == 2:
                cookies[cookie_parts[0]] = cookie_parts[1]

        # Download image with cookies
        response = requests.get(url, stream=True, verify=False, cookies=cookies, timeout=10)
        if response.status_code != 200:
            print(f"Error: Failed to download image from URL: {url}")
            return None, None, None

        # Convert to PIL Image
        img = Image.open(BytesIO(response.content))

        # Convert to OpenCV format (BGR)
        cv_img = cv2.cvtColor(np.array(img), cv2.COLOR_RGB2BGR)

        # Crop image to focus on main object
        cropped_img, marked_img, crop_coords = crop_to_main_object(cv_img)

        # Store in cache if caching is enabled
        if use_cache:
            image_cache[url] = (cropped_img, marked_img, crop_coords)

        return cropped_img, marked_img, crop_coords
    except Exception as e:
        print(f"Error processing image from URL {url}: {str(e)}")
        return None, None, None


def crop_to_main_object(image):
    """Crop image to focus on the main object using multiple detection methods"""
    if image is None:
        return None, None, (0, 0, 0, 0)

    # Get original image dimensions
    img_height, img_width = image.shape[:2]

    # Make a copy of the image for drawing
    marked_image = image.copy()

    # Convert to grayscale
    gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)

    # Apply Gaussian blur to reduce noise
    blurred = cv2.GaussianBlur(gray, (5, 5), 0)

    # Method 1: Otsu's thresholding for binary object detection
    _, thresh_otsu = cv2.threshold(blurred, 0, 255, cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)
    contours_otsu, _ = cv2.findContours(thresh_otsu, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

    # Method 2: Adaptive thresholding for better handling of uneven lighting
    thresh_adaptive = cv2.adaptiveThreshold(blurred, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C,
                                            cv2.THRESH_BINARY_INV, 11, 2)
    contours_adaptive, _ = cv2.findContours(thresh_adaptive, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

    # Method 3: Canny edge detection for finding edges
    edges = cv2.Canny(blurred, 50, 150)
    contours_canny, _ = cv2.findContours(edges, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

    # Combine all contours
    all_contours = contours_otsu + contours_adaptive + contours_canny

    # Calculate the total image area
    total_area = img_width * img_height

    # Default crop coordinates (full image)
    x, y, w, h = 0, 0, img_width, img_height

    if all_contours:
        # Find significant contours (at least 2% of the image size)
        significant_contours = [c for c in all_contours if cv2.contourArea(c) > total_area * 0.02]

        if significant_contours:
            # If we have significant contours, find the bounding rectangle that includes all of them
            all_points = np.concatenate(significant_contours)
            x, y, w, h = cv2.boundingRect(all_points)

            # Add padding (30% of the width/height)
            pad_w = int(w * 0.30)
            pad_h = int(h * 0.30)
            x = max(0, x - pad_w)
            y = max(0, y - pad_h)
            w = min(img_width - x, w + 2 * pad_w)
            h = min(img_height - y, h + 2 * pad_h)

            # Always ensure we have at least 60% of the original image
            cropped_area_ratio = (w * h) / total_area
            if cropped_area_ratio < 0.6:
                # Calculate how much we need to expand to reach 60%
                area_needed = total_area * 0.6
                current_area = w * h
                expansion_factor = math.sqrt(area_needed / current_area)

                # Expand the rectangle
                center_x = x + w / 2
                center_y = y + h / 2
                new_w = min(img_width, int(w * expansion_factor))
                new_h = min(img_height, int(h * expansion_factor))

                # Recalculate x and y to keep the center the same
                x = max(0, int(center_x - new_w / 2))
                y = max(0, int(center_y - new_h / 2))

                # Ensure we don't exceed image boundaries
                w = min(img_width - x, new_w)
                h = min(img_height - y, new_h)

            # Draw the bounding rectangle on the marked image
            cv2.rectangle(marked_image, (x, y), (x + w, y + h), (0, 255, 0), 2)
        else:
            # If no significant contours found, use full image
            print("  No significant objects detected, using full image")
            cv2.rectangle(marked_image, (x, y), (x + w, y + h), (0, 0, 255), 2)
    else:
        # If no contours found, use full image
        print("  No objects detected, using full image")
        cv2.rectangle(marked_image, (x, y), (x + w, y + h), (0, 0, 255), 2)

    # Crop the image
    cropped_image = image[y:y + h, x:x + w]

    return cropped_image, marked_image, (x, y, w, h)


def resize_images(img1, img2, target_size=(512, 512)):
    """Resize two images to the same target size"""
    if img1 is None or img2 is None:
        return None, None

    resized_img1 = cv2.resize(img1, target_size)
    resized_img2 = cv2.resize(img2, target_size)
    return resized_img1, resized_img2


def calculate_ssim_score(img1, img2):
    """Calculate Structural Similarity Index between two images.

    Args:
        img1: First image
        img2: Second image

    Returns:
        SSIM score (higher is better, max 1.0)
    """
    # 确保图像尺寸相同
    if img1.shape[:2] != img2.shape[:2]:
        img2 = cv2.resize(img2, (img1.shape[1], img1.shape[0]))

    # 检查图像类型并转换为灰度（如果需要）
    if len(img1.shape) == 3 and img1.shape[2] == 3:
        gray1 = cv2.cvtColor(img1, cv2.COLOR_BGR2GRAY)
    else:
        gray1 = img1

    if len(img2.shape) == 3 and img2.shape[2] == 3:
        gray2 = cv2.cvtColor(img2, cv2.COLOR_BGR2GRAY)
    else:
        gray2 = img2

    # 计算SSIM
    C1 = (0.01 * 255) ** 2
    C2 = (0.03 * 255) ** 2

    # 使用高斯滤波计算均值和方差
    kernel = cv2.getGaussianKernel(11, 1.5)
    window = np.outer(kernel, kernel.transpose())

    mu1 = cv2.filter2D(gray1, -1, window)[5:-5, 5:-5]
    mu2 = cv2.filter2D(gray2, -1, window)[5:-5, 5:-5]
    mu1_sq = mu1 ** 2
    mu2_sq = mu2 ** 2
    mu1_mu2 = mu1 * mu2

    sigma1_sq = cv2.filter2D(gray1 ** 2, -1, window)[5:-5, 5:-5] - mu1_sq
    sigma2_sq = cv2.filter2D(gray2 ** 2, -1, window)[5:-5, 5:-5] - mu2_sq
    sigma12 = cv2.filter2D(gray1 * gray2, -1, window)[5:-5, 5:-5] - mu1_mu2

    ssim_map = ((2 * mu1_mu2 + C1) * (2 * sigma12 + C2)) / ((mu1_sq + mu2_sq + C1) * (sigma1_sq + sigma2_sq + C2))
    ssim_score = np.mean(ssim_map)

    return float(ssim_score)


def calculate_mse(img1, img2):
    """Calculate Mean Squared Error between two images.

    Args:
        img1: First image
        img2: Second image

    Returns:
        MSE score (lower is better)
    """
    # 确保图像尺寸相同
    if img1.shape[:2] != img2.shape[:2]:
        img2 = cv2.resize(img2, (img1.shape[1], img1.shape[0]))

    # 检查图像类型并转换为灰度（如果需要）
    if len(img1.shape) == 3 and img1.shape[2] == 3:
        gray1 = cv2.cvtColor(img1, cv2.COLOR_BGR2GRAY)
    else:
        gray1 = img1

    if len(img2.shape) == 3 and img2.shape[2] == 3:
        gray2 = cv2.cvtColor(img2, cv2.COLOR_BGR2GRAY)
    else:
        gray2 = img2

    # 计算MSE
    mse = np.mean((gray1 - gray2) ** 2)
    return mse


def calculate_psnr(img1, img2):
    """Calculate Peak Signal-to-Noise Ratio between two images.

    Args:
        img1: First image
        img2: Second image

    Returns:
        PSNR score (higher is better)
    """
    # 确保图像尺寸相同
    if img1.shape[:2] != img2.shape[:2]:
        img2 = cv2.resize(img2, (img1.shape[1], img1.shape[0]))

    # 检查图像类型并转换为灰度（如果需要）
    if len(img1.shape) == 3 and img1.shape[2] == 3:
        gray1 = cv2.cvtColor(img1, cv2.COLOR_BGR2GRAY)
    else:
        gray1 = img1

    if len(img2.shape) == 3 and img2.shape[2] == 3:
        gray2 = cv2.cvtColor(img2, cv2.COLOR_BGR2GRAY)
    else:
        gray2 = img2

    # 计算MSE
    mse = np.mean((gray1 - gray2) ** 2)
    if mse == 0:
        return 100.0

    # 计算PSNR
    max_pixel = 255.0
    psnr = 20 * np.log10(max_pixel / np.sqrt(mse))
    return psnr


def calculate_color_moments(img):
    """Calculate color moments (mean, standard deviation, skewness) for each channel"""
    if img is None:
        return np.zeros(9)

    # Split into channels
    channels = cv2.split(img)
    moments = []

    for channel in channels:
        # Calculate moments
        mean = np.mean(channel)
        std = np.std(channel)
        skewness = moment(channel.flatten(), moment=3)
        moments.extend([mean, std, skewness])

    return moments


def calculate_color_moments_similarity(img1, img2):
    """Calculate similarity between color moments of two images"""
    if img1 is None or img2 is None:
        return 0.0

    moments1 = calculate_color_moments(img1)
    moments2 = calculate_color_moments(img2)

    # Calculate Euclidean distance between moment vectors
    distance = np.linalg.norm(np.array(moments1) - np.array(moments2))
    # Convert distance to similarity score (0-1)
    similarity = 1 / (1 + distance)
    return similarity


def calculate_texture_similarity(img1, img2):
    """Calculate texture similarity using Local Binary Patterns (LBP)"""
    if img1 is None or img2 is None:
        return 0.0

    # 检查图像类型并转换为灰度（如果需要）
    if len(img1.shape) == 3 and img1.shape[2] == 3:
        gray1 = cv2.cvtColor(img1, cv2.COLOR_BGR2GRAY)
    else:
        gray1 = img1

    if len(img2.shape) == 3 and img2.shape[2] == 3:
        gray2 = cv2.cvtColor(img2, cv2.COLOR_BGR2GRAY)
    else:
        gray2 = img2

    # Calculate LBP
    radius = 3
    n_points = 8 * radius
    lbp1 = local_binary_pattern(gray1, n_points, radius, method='uniform')
    lbp2 = local_binary_pattern(gray2, n_points, radius, method='uniform')

    # Calculate histograms
    hist1, _ = np.histogram(lbp1, bins=256, range=(0, 256))
    hist2, _ = np.histogram(lbp2, bins=256, range=(0, 256))

    # Normalize histograms
    hist1 = hist1 / np.sum(hist1)
    hist2 = hist2 / np.sum(hist2)

    # Calculate similarity using correlation
    similarity = cv2.compareHist(hist1.astype(np.float32), hist2.astype(np.float32), cv2.HISTCMP_CORREL)
    return similarity


def calculate_feature_matching(img1, img2):
    """Calculate feature matching similarity using ORB features"""
    if img1 is None or img2 is None:
        return 0.0

    # Initialize ORB detector
    orb = cv2.ORB_create()

    # Find keypoints and descriptors
    kp1, des1 = orb.detectAndCompute(img1, None)
    kp2, des2 = orb.detectAndCompute(img2, None)

    if des1 is None or des2 is None:
        return 0.0

    # Create BFMatcher object
    bf = cv2.BFMatcher(cv2.NORM_HAMMING, crossCheck=True)

    # Match descriptors
    matches = bf.match(des1, des2)

    # Calculate similarity score
    if len(matches) > 0:
        # Get distances of matches
        distances = [m.distance for m in matches]
        # Calculate similarity (lower distance = higher similarity)
        similarity = 1 - (np.mean(distances) / 100)  # Normalize to 0-1 range
        similarity = max(0, min(1, similarity))  # Clamp to 0-1 range
    else:
        similarity = 0.0

    return similarity


def calculate_hsv_histogram_similarity(img1, img2):
    """Calculate similarity using HSV color histograms"""
    if img1 is None or img2 is None:
        return 0.0

    # Convert to HSV
    hsv1 = cv2.cvtColor(img1, cv2.COLOR_BGR2HSV)
    hsv2 = cv2.cvtColor(img2, cv2.COLOR_BGR2HSV)

    # Calculate histograms for each channel
    hist1_h = cv2.calcHist([hsv1], [0], None, [180], [0, 180])
    hist1_s = cv2.calcHist([hsv1], [1], None, [256], [0, 256])
    hist1_v = cv2.calcHist([hsv1], [2], None, [256], [0, 256])

    hist2_h = cv2.calcHist([hsv2], [0], None, [180], [0, 180])
    hist2_s = cv2.calcHist([hsv2], [1], None, [256], [0, 256])
    hist2_v = cv2.calcHist([hsv2], [2], None, [256], [0, 256])

    # Normalize histograms
    cv2.normalize(hist1_h, hist1_h, alpha=0, beta=1, norm_type=cv2.NORM_MINMAX)
    cv2.normalize(hist1_s, hist1_s, alpha=0, beta=1, norm_type=cv2.NORM_MINMAX)
    cv2.normalize(hist1_v, hist1_v, alpha=0, beta=1, norm_type=cv2.NORM_MINMAX)
    cv2.normalize(hist2_h, hist2_h, alpha=0, beta=1, norm_type=cv2.NORM_MINMAX)
    cv2.normalize(hist2_s, hist2_s, alpha=0, beta=1, norm_type=cv2.NORM_MINMAX)
    cv2.normalize(hist2_v, hist2_v, alpha=0, beta=1, norm_type=cv2.NORM_MINMAX)

    # Calculate similarities
    h_similarity = cv2.compareHist(hist1_h, hist2_h, cv2.HISTCMP_CORREL)
    s_similarity = cv2.compareHist(hist1_s, hist2_s, cv2.HISTCMP_CORREL)
    v_similarity = cv2.compareHist(hist1_v, hist2_v, cv2.HISTCMP_CORREL)

    # Return average similarity
    return (h_similarity + s_similarity + v_similarity) / 3


def calculate_lab_similarity(img1, img2):
    """Calculate similarity using LAB color space"""
    if img1 is None or img2 is None:
        return 0.0

    # Convert to LAB color space
    lab1 = cv2.cvtColor(img1, cv2.COLOR_BGR2LAB)
    lab2 = cv2.cvtColor(img2, cv2.COLOR_BGR2LAB)

    # Calculate mean and std for each channel
    lab1_mean = np.mean(lab1, axis=(0, 1))
    lab1_std = np.std(lab1, axis=(0, 1))
    lab2_mean = np.mean(lab2, axis=(0, 1))
    lab2_std = np.std(lab2, axis=(0, 1))

    # Convert to float to avoid numpy array issues
    lab1_mean = lab1_mean.astype(float)
    lab1_std = lab1_std.astype(float)
    lab2_mean = lab2_mean.astype(float)
    lab2_std = lab2_std.astype(float)

    # Calculate similarity using cosine distance
    mean_similarity = 1 - cosine(lab1_mean, lab2_mean)
    std_similarity = 1 - cosine(lab1_std, lab2_std)

    return float((mean_similarity + std_similarity) / 2)


def calculate_glcm_features(img):
    """Calculate Gray Level Co-occurrence Matrix (GLCM) features"""
    if img is None:
        return np.zeros(5)

    # 检查图像类型并转换为灰度（如果需要）
    if len(img.shape) == 3 and img.shape[2] == 3:
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    else:
        gray = img

    gray = gray.astype(np.uint8)

    # Calculate GLCM
    glcm = graycomatrix(gray, distances=[1], angles=[0], levels=256, symmetric=True, normed=True)

    # Calculate texture features
    contrast = graycoprops(glcm, 'contrast')[0, 0]
    dissimilarity = graycoprops(glcm, 'dissimilarity')[0, 0]
    homogeneity = graycoprops(glcm, 'homogeneity')[0, 0]
    energy = graycoprops(glcm, 'energy')[0, 0]
    correlation = graycoprops(glcm, 'correlation')[0, 0]

    return np.array([contrast, dissimilarity, homogeneity, energy, correlation])


def calculate_glcm_similarity(img1, img2):
    """Calculate similarity using GLCM features"""
    if img1 is None or img2 is None:
        return 0.0

    features1 = calculate_glcm_features(img1)
    features2 = calculate_glcm_features(img2)

    # Calculate similarity using cosine distance
    similarity = 1 - cosine(features1, features2)
    return similarity


def calculate_hu_moments(img):
    """Calculate Hu moments for shape comparison"""
    if img is None:
        return np.zeros(7)

    # 检查图像类型并转换为灰度（如果需要）
    if len(img.shape) == 3 and img.shape[2] == 3:
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    else:
        gray = img

    gray = gray.astype(np.uint8)

    # Calculate moments
    moments = cv2.moments(gray)
    hu_moments = cv2.HuMoments(moments)

    # Log scale to make values more comparable
    for i in range(7):
        hu_moments[i] = -1 * np.sign(hu_moments[i]) * np.log10(abs(hu_moments[i]) + 1e-10)

    return hu_moments.flatten()


def calculate_shape_similarity(img1, img2):
    """Calculate similarity using Hu moments"""
    if img1 is None or img2 is None:
        return 0.0

    moments1 = calculate_hu_moments(img1)
    moments2 = calculate_hu_moments(img2)

    # Calculate similarity using cosine distance
    similarity = 1 - cosine(moments1, moments2)
    return similarity


def calculate_gabor_features(img):
    """Calculate Gabor filter features"""
    if img is None:
        return np.zeros(2)

    # 检查图像类型并转换为灰度（如果需要）
    if len(img.shape) == 3 and img.shape[2] == 3:
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    else:
        gray = img

    gray = gray.astype(np.uint8)

    # Gabor filter parameters
    ksize = 31
    sigma = 8.0
    theta = 0
    lambd = 10.0
    gamma = 0.5
    psi = 0

    # Create Gabor filter
    kernel = cv2.getGaborKernel((ksize, ksize), sigma, theta, lambd, gamma, psi)

    # Apply filter
    filtered = cv2.filter2D(gray, cv2.CV_8UC3, kernel)

    # Calculate mean and std of filtered image
    mean = np.mean(filtered)
    std = np.std(filtered)

    return np.array([mean, std])


def calculate_gabor_similarity(img1, img2):
    """Calculate similarity using Gabor filter features"""
    if img1 is None or img2 is None:
        return 0.0

    features1 = calculate_gabor_features(img1)
    features2 = calculate_gabor_features(img2)

    # Calculate similarity using cosine distance
    similarity = 1 - cosine(features1, features2)
    return similarity


def p_hash(img):
    """Perceptual Hash algorithm"""
    if img is None:
        return "0" * 64

    # Resize to 32x32
    img = cv2.resize(img, (32, 32))

    # 检查图像类型并转换为灰度（如果需要）
    if len(img.shape) == 3 and img.shape[2] == 3:
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    else:
        gray = img

    # Apply DCT
    dct = cv2.dct(np.float32(gray))
    # Take top-left 8x8 (low frequency)
    dct_roi = dct[:8, :8]
    # Calculate average value (excluding DC component)
    avg = (dct_roi[0, 0] + np.mean(dct_roi)) / 2
    # Create hash string
    hash_str = ''
    for i in range(8):
        for j in range(8):
            if dct_roi[i, j] > avg:
                hash_str += '1'
            else:
                hash_str += '0'
    return hash_str


def a_hash(img):
    """Average Hash algorithm"""
    if img is None:
        return "0" * 64

    # Resize to 8x8
    img = cv2.resize(img, (8, 8))

    # 检查图像类型并转换为灰度（如果需要）
    if len(img.shape) == 3 and img.shape[2] == 3:
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    else:
        gray = img

    # Calculate average pixel value
    avg = gray.mean()
    # Create hash string (1 for pixels above average, 0 for below)
    hash_str = ''
    for i in range(8):
        for j in range(8):
            if gray[i, j] > avg:
                hash_str += '1'
            else:
                hash_str += '0'
    return hash_str


def d_hash(img):
    """Difference Hash algorithm"""
    if img is None:
        return "0" * 64

    # Resize to 9x8 (one more column than rows)
    img = cv2.resize(img, (9, 8))

    # 检查图像类型并转换为灰度（如果需要）
    if len(img.shape) == 3 and img.shape[2] == 3:
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    else:
        gray = img

    # Create hash string (1 if left pixel > right pixel, 0 otherwise)
    hash_str = ''
    for i in range(8):
        for j in range(8):
            if gray[i, j] > gray[i, j + 1]:
                hash_str += '1'
            else:
                hash_str += '0'
    return hash_str


def compare_hash(hash1, hash2):
    """Compare two hash strings and return the Hamming distance"""
    if len(hash1) != len(hash2):
        return -1

    # Count different bits
    distance = sum(c1 != c2 for c1, c2 in zip(hash1, hash2))
    return distance


def calculate_hash_similarity(img1, img2, method='a_hash'):
    """Calculate hash similarity between two images"""
    if img1 is None or img2 is None:
        return 0.0

    if method == 'a_hash':
        hash1 = a_hash(img1)
        hash2 = a_hash(img2)
    elif method == 'd_hash':
        hash1 = d_hash(img1)
        hash2 = d_hash(img2)
    else:
        raise ValueError(f"Unknown hash method: {method}")

    # Calculate Hamming distance
    distance = compare_hash(hash1, hash2)

    # Convert distance to similarity score (0-1)
    # For 64-bit hash, max distance is 64
    max_distance = 64
    similarity = 1.0 - (distance / max_distance)

    return similarity


def calculate_histogram_similarity(img1, img2):
    """Calculate histogram similarity between two images.

    Args:
        img1: First image
        img2: Second image

    Returns:
        Similarity score (higher is better, max 1.0)
    """
    # 确保图像尺寸相同
    if img1.shape[:2] != img2.shape[:2]:
        img2 = cv2.resize(img2, (img1.shape[1], img1.shape[0]))

    # 判断图像是灰度还是彩色
    if len(img1.shape) == 2 or (len(img1.shape) == 3 and img1.shape[2] == 1):
        # 灰度图像
        hist1 = cv2.calcHist([img1], [0], None, [256], [0, 256])
        hist2 = cv2.calcHist([img2], [0], None, [256], [0, 256])

        # 归一化直方图
        cv2.normalize(hist1, hist1, 0, 1, cv2.NORM_MINMAX)
        cv2.normalize(hist2, hist2, 0, 1, cv2.NORM_MINMAX)

        # 计算直方图相似度（使用巴氏距离）
        similarity = cv2.compareHist(hist1, hist2, cv2.HISTCMP_BHATTACHARYYA)
        # 巴氏距离越小表示相似度越高，将其转换为相似度分数
        similarity = 1 - similarity
    else:
        # 彩色图像 - 分别计算RGB三个通道
        similarity = 0
        for i in range(3):
            hist1 = cv2.calcHist([img1], [i], None, [256], [0, 256])
            hist2 = cv2.calcHist([img2], [i], None, [256], [0, 256])

            # 归一化直方图
            cv2.normalize(hist1, hist1, 0, 1, cv2.NORM_MINMAX)
            cv2.normalize(hist2, hist2, 0, 1, cv2.NORM_MINMAX)

            # 累加三个通道的相似度
            channel_similarity = 1 - cv2.compareHist(hist1, hist2, cv2.HISTCMP_BHATTACHARYYA)
            similarity += channel_similarity / 3.0

    return float(similarity)


def calculate_color_moments_similarity(img1, img2):
    """Calculate similarity between color moments of two images"""
    if img1 is None or img2 is None:
        return 0.0

    moments1 = calculate_color_moments(img1)
    moments2 = calculate_color_moments(img2)

    # Calculate Euclidean distance between moment vectors
    distance = np.linalg.norm(np.array(moments1) - np.array(moments2))
    # Convert distance to similarity score (0-1)
    similarity = 1 / (1 + distance)
    return similarity


def calculate_texture_similarity(img1, img2):
    """Calculate texture similarity using Local Binary Patterns (LBP)"""
    if img1 is None or img2 is None:
        return 0.0

    # 检查图像类型并转换为灰度（如果需要）
    if len(img1.shape) == 3 and img1.shape[2] == 3:
        gray1 = cv2.cvtColor(img1, cv2.COLOR_BGR2GRAY)
    else:
        gray1 = img1

    if len(img2.shape) == 3 and img2.shape[2] == 3:
        gray2 = cv2.cvtColor(img2, cv2.COLOR_BGR2GRAY)
    else:
        gray2 = img2

    # Calculate LBP
    radius = 3
    n_points = 8 * radius
    lbp1 = local_binary_pattern(gray1, n_points, radius, method='uniform')
    lbp2 = local_binary_pattern(gray2, n_points, radius, method='uniform')

    # Calculate histograms
    hist1, _ = np.histogram(lbp1, bins=256, range=(0, 256))
    hist2, _ = np.histogram(lbp2, bins=256, range=(0, 256))

    # Normalize histograms
    hist1 = hist1 / np.sum(hist1)
    hist2 = hist2 / np.sum(hist2)

    # Calculate similarity using correlation
    similarity = cv2.compareHist(hist1.astype(np.float32), hist2.astype(np.float32), cv2.HISTCMP_CORREL)
    return similarity


def calculate_feature_matching(img1, img2):
    """Calculate feature matching similarity using ORB features"""
    if img1 is None or img2 is None:
        return 0.0

    # Initialize ORB detector
    orb = cv2.ORB_create()

    # Find keypoints and descriptors
    kp1, des1 = orb.detectAndCompute(img1, None)
    kp2, des2 = orb.detectAndCompute(img2, None)

    if des1 is None or des2 is None:
        return 0.0

    # Create BFMatcher object
    bf = cv2.BFMatcher(cv2.NORM_HAMMING, crossCheck=True)

    # Match descriptors
    matches = bf.match(des1, des2)

    # Calculate similarity score
    if len(matches) > 0:
        # Get distances of matches
        distances = [m.distance for m in matches]
        # Calculate similarity (lower distance = higher similarity)
        similarity = 1 - (np.mean(distances) / 100)  # Normalize to 0-1 range
        similarity = max(0, min(1, similarity))  # Clamp to 0-1 range
    else:
        similarity = 0.0

    return similarity


def calculate_hsv_histogram_similarity(img1, img2):
    """Calculate similarity using HSV color histograms"""
    if img1 is None or img2 is None:
        return 0.0

    # Convert to HSV
    hsv1 = cv2.cvtColor(img1, cv2.COLOR_BGR2HSV)
    hsv2 = cv2.cvtColor(img2, cv2.COLOR_BGR2HSV)

    # Calculate histograms for each channel
    hist1_h = cv2.calcHist([hsv1], [0], None, [180], [0, 180])
    hist1_s = cv2.calcHist([hsv1], [1], None, [256], [0, 256])
    hist1_v = cv2.calcHist([hsv1], [2], None, [256], [0, 256])

    hist2_h = cv2.calcHist([hsv2], [0], None, [180], [0, 180])
    hist2_s = cv2.calcHist([hsv2], [1], None, [256], [0, 256])
    hist2_v = cv2.calcHist([hsv2], [2], None, [256], [0, 256])

    # Normalize histograms
    cv2.normalize(hist1_h, hist1_h, alpha=0, beta=1, norm_type=cv2.NORM_MINMAX)
    cv2.normalize(hist1_s, hist1_s, alpha=0, beta=1, norm_type=cv2.NORM_MINMAX)
    cv2.normalize(hist1_v, hist1_v, alpha=0, beta=1, norm_type=cv2.NORM_MINMAX)
    cv2.normalize(hist2_h, hist2_h, alpha=0, beta=1, norm_type=cv2.NORM_MINMAX)
    cv2.normalize(hist2_s, hist2_s, alpha=0, beta=1, norm_type=cv2.NORM_MINMAX)
    cv2.normalize(hist2_v, hist2_v, alpha=0, beta=1, norm_type=cv2.NORM_MINMAX)

    # Calculate similarities
    h_similarity = cv2.compareHist(hist1_h, hist2_h, cv2.HISTCMP_CORREL)
    s_similarity = cv2.compareHist(hist1_s, hist2_s, cv2.HISTCMP_CORREL)
    v_similarity = cv2.compareHist(hist1_v, hist2_v, cv2.HISTCMP_CORREL)

    # Return average similarity
    return (h_similarity + s_similarity + v_similarity) / 3


def calculate_lab_similarity(img1, img2):
    """Calculate similarity using LAB color space"""
    if img1 is None or img2 is None:
        return 0.0

    # Convert to LAB color space
    lab1 = cv2.cvtColor(img1, cv2.COLOR_BGR2LAB)
    lab2 = cv2.cvtColor(img2, cv2.COLOR_BGR2LAB)

    # Calculate mean and std for each channel
    lab1_mean = np.mean(lab1, axis=(0, 1))
    lab1_std = np.std(lab1, axis=(0, 1))
    lab2_mean = np.mean(lab2, axis=(0, 1))
    lab2_std = np.std(lab2, axis=(0, 1))

    # Convert to float to avoid numpy array issues
    lab1_mean = lab1_mean.astype(float)
    lab1_std = lab1_std.astype(float)
    lab2_mean = lab2_mean.astype(float)
    lab2_std = lab2_std.astype(float)

    # Calculate similarity using cosine distance
    mean_similarity = 1 - cosine(lab1_mean, lab2_mean)
    std_similarity = 1 - cosine(lab1_std, lab2_std)

    return float((mean_similarity + std_similarity) / 2)


def calculate_glcm_features(img):
    """Calculate Gray Level Co-occurrence Matrix (GLCM) features"""
    if img is None:
        return np.zeros(5)

    # 检查图像类型并转换为灰度（如果需要）
    if len(img.shape) == 3 and img.shape[2] == 3:
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    else:
        gray = img

    gray = gray.astype(np.uint8)

    # Calculate GLCM
    glcm = graycomatrix(gray, distances=[1], angles=[0], levels=256, symmetric=True, normed=True)

    # Calculate texture features
    contrast = graycoprops(glcm, 'contrast')[0, 0]
    dissimilarity = graycoprops(glcm, 'dissimilarity')[0, 0]
    homogeneity = graycoprops(glcm, 'homogeneity')[0, 0]
    energy = graycoprops(glcm, 'energy')[0, 0]
    correlation = graycoprops(glcm, 'correlation')[0, 0]

    return np.array([contrast, dissimilarity, homogeneity, energy, correlation])


def calculate_glcm_similarity(img1, img2):
    """Calculate similarity using GLCM features"""
    if img1 is None or img2 is None:
        return 0.0

    features1 = calculate_glcm_features(img1)
    features2 = calculate_glcm_features(img2)

    # Calculate similarity using cosine distance
    similarity = 1 - cosine(features1, features2)
    return similarity


def calculate_hu_moments(img):
    """Calculate Hu moments for shape comparison"""
    if img is None:
        return np.zeros(7)

    # 检查图像类型并转换为灰度（如果需要）
    if len(img.shape) == 3 and img.shape[2] == 3:
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    else:
        gray = img

    gray = gray.astype(np.uint8)

    # Calculate moments
    moments = cv2.moments(gray)
    hu_moments = cv2.HuMoments(moments)

    # Log scale to make values more comparable
    for i in range(7):
        hu_moments[i] = -1 * np.sign(hu_moments[i]) * np.log10(abs(hu_moments[i]) + 1e-10)

    return hu_moments.flatten()


def calculate_shape_similarity(img1, img2):
    """Calculate similarity using Hu moments"""
    if img1 is None or img2 is None:
        return 0.0

    moments1 = calculate_hu_moments(img1)
    moments2 = calculate_hu_moments(img2)

    # Calculate similarity using cosine distance
    similarity = 1 - cosine(moments1, moments2)
    return similarity


def calculate_gabor_features(img):
    """Calculate Gabor filter features"""
    if img is None:
        return np.zeros(2)

    # 检查图像类型并转换为灰度（如果需要）
    if len(img.shape) == 3 and img.shape[2] == 3:
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    else:
        gray = img

    gray = gray.astype(np.uint8)

    # Gabor filter parameters
    ksize = 31
    sigma = 8.0
    theta = 0
    lambd = 10.0
    gamma = 0.5
    psi = 0

    # Create Gabor filter
    kernel = cv2.getGaborKernel((ksize, ksize), sigma, theta, lambd, gamma, psi)

    # Apply filter
    filtered = cv2.filter2D(gray, cv2.CV_8UC3, kernel)

    # Calculate mean and std of filtered image
    mean = np.mean(filtered)
    std = np.std(filtered)

    return np.array([mean, std])


def calculate_gabor_similarity(img1, img2):
    """Calculate similarity using Gabor filter features"""
    if img1 is None or img2 is None:
        return 0.0

    features1 = calculate_gabor_features(img1)
    features2 = calculate_gabor_features(img2)

    # Calculate similarity using cosine distance
    similarity = 1 - cosine(features1, features2)
    return similarity


def p_hash(img):
    """Perceptual Hash algorithm"""
    if img is None:
        return "0" * 64

    # Resize to 32x32
    img = cv2.resize(img, (32, 32))

    # 检查图像类型并转换为灰度（如果需要）
    if len(img.shape) == 3 and img.shape[2] == 3:
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    else:
        gray = img

    # Apply DCT
    dct = cv2.dct(np.float32(gray))
    # Take top-left 8x8 (low frequency)
    dct_roi = dct[:8, :8]
    # Calculate average value (excluding DC component)
    avg = (dct_roi[0, 0] + np.mean(dct_roi)) / 2
    # Create hash string
    hash_str = ''
    for i in range(8):
        for j in range(8):
            if dct_roi[i, j] > avg:
                hash_str += '1'
            else:
                hash_str += '0'
    return hash_str


def a_hash(img):
    """Average Hash algorithm"""
    if img is None:
        return "0" * 64

    # Resize to 8x8
    img = cv2.resize(img, (8, 8))

    # 检查图像类型并转换为灰度（如果需要）
    if len(img.shape) == 3 and img.shape[2] == 3:
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    else:
        gray = img

    # Calculate average pixel value
    avg = gray.mean()
    # Create hash string (1 for pixels above average, 0 for below)
    hash_str = ''
    for i in range(8):
        for j in range(8):
            if gray[i, j] > avg:
                hash_str += '1'
            else:
                hash_str += '0'
    return hash_str


def d_hash(img):
    """Difference Hash algorithm"""
    if img is None:
        return "0" * 64

    # Resize to 9x8 (one more column than rows)
    img = cv2.resize(img, (9, 8))

    # 检查图像类型并转换为灰度（如果需要）
    if len(img.shape) == 3 and img.shape[2] == 3:
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    else:
        gray = img

    # Create hash string (1 if left pixel > right pixel, 0 otherwise)
    hash_str = ''
    for i in range(8):
        for j in range(8):
            if gray[i, j] > gray[i, j + 1]:
                hash_str += '1'
            else:
                hash_str += '0'
    return hash_str


def compare_hash(hash1, hash2):
    """Compare two hash strings and return the Hamming distance"""
    if len(hash1) != len(hash2):
        return -1

    # Count different bits
    distance = sum(c1 != c2 for c1, c2 in zip(hash1, hash2))
    return distance


def calculate_hash_similarity(img1, img2, method='a_hash'):
    """Calculate hash similarity between two images"""
    if img1 is None or img2 is None:
        return 0.0

    if method == 'a_hash':
        hash1 = a_hash(img1)
        hash2 = a_hash(img2)
    elif method == 'd_hash':
        hash1 = d_hash(img1)
        hash2 = d_hash(img2)
    else:
        raise ValueError(f"Unknown hash method: {method}")

    # Calculate Hamming distance
    distance = compare_hash(hash1, hash2)

    # Convert distance to similarity score (0-1)
    # For 64-bit hash, max distance is 64
    max_distance = 64
    similarity = 1.0 - (distance / max_distance)

    return similarity


def calculate_histogram_similarity(img1, img2):
    """RGB histogram similarity calculation"""
    if img1 is None or img2 is None:
        return 0.0

    # Resize images to a standard size
    img1 = cv2.resize(img1, (256, 256))
    img2 = cv2.resize(img2, (256, 256))

    # Split into RGB channels
    sub_img1 = cv2.split(img1)
    sub_img2 = cv2.split(img2)

    # Calculate similarity for each channel
    similarity = 0
    for ch1, ch2 in zip(sub_img1, sub_img2):
        hist1 = cv2.calcHist([ch1], [0], None, [256], [0.0, 255.0])
        hist2 = cv2.calcHist([ch2], [0], None, [256], [0.0, 255.0])

        # Normalize histograms
        cv2.normalize(hist1, hist1, 0, 1, cv2.NORM_MINMAX)
        cv2.normalize(hist2, hist2, 0, 1, cv2.NORM_MINMAX)

        # Compare histograms using correlation method
        similarity += cv2.compareHist(hist1, hist2, cv2.HISTCMP_CORREL)

    # Return average similarity across channels
    return similarity / 3.0


def load_fashion_clip():
    """
    Load the CLIP model for fashion similarity comparison.
    Note: Using standard CLIP model as it's more reliable than FashionCLIP for this task.
    Returns True if successful, False otherwise.
    """
    global fashion_clip_model, fashion_clip_processor

    try:
        from transformers import CLIPProcessor, CLIPModel
        import torch

        logger.info("Loading CLIP model...")

        # Check if we already have the model loaded
        if fashion_clip_model is not None and fashion_clip_processor is not None:
            logger.info("CLIP model already loaded.")
            return True

        # Verify torch is working properly
        print(f"PyTorch version: {torch.__version__}")
        print(f"CUDA available: {torch.cuda.is_available()}")

        # Use standard CLIP model which is more reliable
        model_name = "openai/clip-vit-base-patch32"

        # Add error handling for model loading
        try:
            fashion_clip_model = CLIPModel.from_pretrained(model_name)
            fashion_clip_processor = CLIPProcessor.from_pretrained(model_name)

            # Put model in evaluation mode
            fashion_clip_model.eval()

            # Use GPU if available
            if torch.cuda.is_available():
                fashion_clip_model = fashion_clip_model.to("cuda")
                print(f"Using GPU for CLIP model: {model_name}")
            else:
                print(f"Using CPU for CLIP model: {model_name}")

            # Test the model with a simple image to ensure it works
            test_img = Image.new('RGB', (224, 224), color='red')
            test_inputs = fashion_clip_processor(images=test_img, return_tensors="pt", padding=True)
            with torch.no_grad():
                test_outputs = fashion_clip_model.get_image_features(**test_inputs)
            if test_outputs is None:
                raise Exception("Model returned None for test image")

            print(f"CLIP model initialization successful. Embedding shape: {test_outputs.shape}")

            logger.info(f"CLIP model {model_name} loaded successfully.")
            return True
        except Exception as e:
            logger.error(f"Error during model initialization: {str(e)}")
            print(f"Model initialization error: {str(e)}")
            fashion_clip_model = None
            fashion_clip_processor = None
            return False
    except ImportError as e:
        logger.error(f"Failed to import required libraries: {str(e)}")
        print(f"Import error: {str(e)}")
        return False
    except Exception as e:
        logger.error(f"Failed to load CLIP model: {str(e)}")
        print(f"Error loading model: {str(e)}")
        return False


def get_fashion_clip_embedding(image):
    """
    Extract FashionCLIP embeddings for an image.

    Args:
        image: PIL Image or numpy array

    Returns:
        numpy array: Normalized embedding vector
    """
    global fashion_clip_model, fashion_clip_processor

    if fashion_clip_model is None or fashion_clip_processor is None:
        success = load_fashion_clip()
        if not success:
            print("  Failed to load CLIP model")
            return None

    try:
        # Convert numpy array to PIL Image if needed
        if isinstance(image, np.ndarray):
            try:
                # Ensure the array has valid values and shape for conversion
                if image.dtype != np.uint8:
                    image = (image * 255).astype(np.uint8)
                image = Image.fromarray(image)
            except Exception as e:
                print(f"  Error converting image array to PIL Image: {str(e)}")
                # Try creating a dummy image as fallback
                print("  Creating fallback image")
                image = Image.new('RGB', (224, 224), color='gray')

        # Print image info for debugging
        if isinstance(image, Image.Image):
            print(f"  Image shape: {image.size}, mode: {image.mode}")
        else:
            print(f"  Warning: Image is not a PIL Image or numpy array: {type(image)}")
            return None

        # Ensure image is in RGB mode
        if image.mode != "RGB":
            try:
                image = image.convert("RGB")
            except Exception as e:
                print(f"  Error converting image to RGB: {str(e)}")
                return None

        # Resize image to expected size (224x224 is standard for CLIP/ViT models)
        try:
            image = image.resize((224, 224))
        except Exception as e:
            print(f"  Error resizing image: {str(e)}")
            return None

        # Preprocess the image
        try:
            inputs = fashion_clip_processor(images=image, return_tensors="pt", padding=True)
        except Exception as e:
            print(f"  Error preprocessing image: {str(e)}")
            return None

        # Get image features (embeddings)
        try:
            with torch.no_grad():  # Add this to make sure we're not computing gradients
                outputs = fashion_clip_model.get_image_features(**inputs)

            # Normalize the embeddings
            norm = outputs.norm(p=2, dim=-1, keepdim=True)
            # Avoid division by zero
            norm = torch.where(norm == 0, torch.ones_like(norm), norm)
            embeddings = outputs / norm

            # Convert to numpy array
            result = embeddings.squeeze().detach().cpu().numpy()

            # Check for NaN values
            if np.isnan(result).any():
                print("  WARNING: NaN values detected in embedding!")
                # Replace NaN values with zeros
                result = np.nan_to_num(result)
                # Re-normalize if needed
                if np.linalg.norm(result) > 0:
                    result = result / np.linalg.norm(result)

            return result
        except Exception as e:
            print(f"  Error getting embeddings: {str(e)}")
            return None

    except Exception as e:
        logger.error(f"Error extracting FashionCLIP embedding: {str(e)}")
        print(f"  Error extracting embedding: {str(e)}")
        return None


def calculate_fashion_clip_similarity(img1, img2):
    """
    Calculate similarity between two images using FashionCLIP embeddings.

    Args:
        img1: First image (PIL Image or numpy array)
        img2: Second image (PIL Image or numpy array)

    Returns:
        float: Similarity score between 0 and 1 (higher means more similar)
              Returns None if embedding extraction fails
    """
    # Check if images are identical objects
    if img1 is img2:
        print("  Images are identical objects - returning 1.0")
        return 1.0

    # Ensure the CLIP model is loaded
    global fashion_clip_model, fashion_clip_processor
    if fashion_clip_model is None or fashion_clip_processor is None:
        success = load_fashion_clip()
        if not success:
            print("  Failed to load FashionCLIP model - returning default similarity 0.5")
            return 0.5  # Return neutral similarity on failure

    try:
        # Extract embeddings
        embed1 = get_fashion_clip_embedding(img1)
        embed2 = get_fashion_clip_embedding(img2)

        # Check if embeddings were extracted successfully
        if embed1 is None or embed2 is None:
            print("  Failed to get embeddings - returning default similarity 0.5")
            return 0.5  # Return neutral similarity on failure

        # Print shapes for debugging
        print(f"  Embedding shapes: {embed1.shape}, {embed2.shape}")

        # For debugging - check if embeddings are identical
        if np.array_equal(embed1, embed2):
            print("  WARNING: Embeddings are identical!")

        # Ensure no NaN values
        embed1 = np.nan_to_num(embed1)
        embed2 = np.nan_to_num(embed2)

        # Re-normalize if needed
        if np.linalg.norm(embed1) > 0:
            embed1 = embed1 / np.linalg.norm(embed1)
        if np.linalg.norm(embed2) > 0:
            embed2 = embed2 / np.linalg.norm(embed2)

        # Compute cosine similarity (1 - cosine distance)
        try:
            similarity = 1 - cosine(embed1, embed2)

            # Print a few values of the embeddings for debugging
            print(f"  Embedding values (first 3): img1={embed1[:3]}, img2={embed2[:3]}")
            print(f"  Computed similarity: {similarity}")

            # Deal with NaN similarity result
            if np.isnan(similarity):
                print("  WARNING: Similarity calculation resulted in NaN, using embedding dot product instead")
                # Fallback to dot product (valid for normalized vectors)
                similarity = float(np.dot(embed1, embed2))

            # Ensure reasonable range
            similarity = max(0.0, min(1.0, float(similarity)))

            return similarity
        except Exception as e:
            logger.error(f"Error calculating FashionCLIP similarity: {str(e)}")
            print(f"  Error in similarity calculation: {str(e)}")
            return 0.5  # Return a neutral similarity value on error

    except Exception as e:
        logger.error(f"Error in fashion_clip_similarity: {str(e)}")
        print(f"  Error in fashion_clip_similarity: {str(e)}")
        return 0.5  # Return a neutral similarity value on error


def compare_images(img1_url, img2_url, methods=None, source_pid='', match_pid='', use_cache=False):
    """
    Compare two images using multiple methods and return a dictionary of results.

    Args:
        img1_url: URL or local path to the first image
        img2_url: URL or local path to the second image
        methods: List of methods to use (default: all methods)
        source_pid: Product ID for the source image
        match_pid: Product ID for the match image
        use_cache: Whether to use cached results (if available)

    Returns:
        Dictionary with comparison results
    """
    global comparison_results

    if methods is None:
        methods = ['a_hash', 'd_hash', 'p_hash', 'histogram', 'ssim', 'mse', 'psnr',
                   'feature_matching', 'color_moments', 'hsv_similarity', 'lab_similarity',
                   'texture', 'glcm_similarity', 'shape_similarity', 'gabor_similarity',
                   'contour_overlap', 'feature_contour', 'fashion_clip']

    # Check if we have cached results
    cache_key = f"{hashlib.md5((img1_url + img2_url).encode()).hexdigest()}"
    cache_file = os.path.join(CACHE_DIR, f"comparison_{cache_key}.json")

    if use_cache and os.path.exists(cache_file):
        try:
            with open(cache_file, 'r') as f:
                cached_results = json.load(f)

            # Check if we have all the requested methods in the cache
            missing_methods = [m for m in methods if m not in cached_results]
            if not missing_methods:
                print(f"Using cached comparison results for {len(methods)} methods")
                # Store results for report generation
                comparison_key = f"{source_pid}_{match_pid}"
                comparison_results[comparison_key] = cached_results
                return cached_results
            else:
                print(f"Cache hit partial: missing {len(missing_methods)} methods")
                # We'll continue with the analysis but only compute missing methods
                methods = missing_methods
                results = cached_results
        except Exception as e:
            print(f"Error loading cache: {e}")
            results = {}
    else:
        results = {}

    # Add product IDs to results
    results['source_pid'] = source_pid
    results['match_pid'] = match_pid

    # Ensure we don't recompute methods
    methods = [m for m in methods if m not in results]

    try:
        # Load the images
        img1 = load_image(img1_url)
        img2 = load_image(img2_url)

        # Resize the images to have the same dimensions
        max_dim = 800
        img1 = resize_image(img1, max_dim)
        img2 = resize_image(img2, max_dim)

        # Convert the images to grayscale for some methods
        gray1 = cv2.cvtColor(img1, cv2.COLOR_BGR2GRAY)
        gray2 = cv2.cvtColor(img2, cv2.COLOR_BGR2GRAY)

        # Apply various comparison methods
        for method in methods:
            if method == 'a_hash':
                hash1 = a_hash(img1)
                hash2 = a_hash(img2)
                distance = compare_hash(hash1, hash2)
                max_distance = 64
                results['a_hash'] = 1.0 - (distance / max_distance)

            elif method == 'd_hash':
                hash1 = d_hash(img1)
                hash2 = d_hash(img2)
                distance = compare_hash(hash1, hash2)
                max_distance = 64
                results['d_hash'] = 1.0 - (distance / max_distance)

            elif method == 'p_hash':
                hash1 = p_hash(img1)
                hash2 = p_hash(img2)
                distance = compare_hash(hash1, hash2)
                max_distance = 64
                results['p_hash'] = 1.0 - (distance / max_distance)

            elif method == 'histogram':
                results['histogram'] = calculate_histogram_similarity(img1, img2)

            elif method == 'ssim':
                results['ssim'] = calculate_ssim_score(gray1, gray2)

            elif method == 'mse':
                results['mse'] = calculate_mse(img1, img2)

            elif method == 'psnr':
                results['psnr'] = calculate_psnr(img1, img2)

            elif method == 'feature_matching':
                # Calculate feature matching similarity
                keypoints1, descriptors1 = cv2.SIFT_create().detectAndCompute(gray1, None)
                keypoints2, descriptors2 = cv2.SIFT_create().detectAndCompute(gray2, None)

                # If not enough keypoints, return low similarity
                if descriptors1 is None or descriptors2 is None or len(keypoints1) < 2 or len(keypoints2) < 2:
                    results['feature_matching'] = 0.0
                    continue

                # Match features using FLANN
                FLANN_INDEX_KDTREE = 1
                index_params = dict(algorithm=FLANN_INDEX_KDTREE, trees=5)
                search_params = dict(checks=50)
                flann = cv2.FlannBasedMatcher(index_params, search_params)

                matches = flann.knnMatch(descriptors1, descriptors2, k=2)

                # Apply ratio test to get good matches
                good_matches = []
                for m, n in matches:
                    if m.distance < 0.75 * n.distance:
                        good_matches.append(m)

                # Calculate similarity based on match ratio
                total_keypoints = min(len(keypoints1), len(keypoints2))
                if total_keypoints > 0:
                    results['feature_matching'] = len(good_matches) / total_keypoints
                else:
                    results['feature_matching'] = 0.0

                # Create marked images for visualization
                marked_img1 = img1.copy()
                marked_img2 = img2.copy()

                # Draw keypoints on images
                for kp in keypoints1:
                    x, y = map(int, kp.pt)
                    cv2.circle(marked_img1, (x, y), 3, (0, 255, 0), -1)

                for kp in keypoints2:
                    x, y = map(int, kp.pt)
                    cv2.circle(marked_img2, (x, y), 3, (0, 255, 0), -1)

                # Save the marked images and store their paths
                if not os.path.exists(DEBUG_DIR):
                    os.makedirs(DEBUG_DIR)

                img1_path = os.path.join(DEBUG_DIR, f"{source_pid or 'img1'}_features.jpg")
                img2_path = os.path.join(DEBUG_DIR, f"{match_pid or 'img2'}_features.jpg")

                cv2.imwrite(img1_path, marked_img1)
                cv2.imwrite(img2_path, marked_img2)

                results['marked_image1'] = img1_path
                results['marked_image2'] = img2_path

            elif method == 'color_moments':
                results['color_moments'] = calculate_color_moments_similarity(img1, img2)

            elif method == 'hsv_similarity':
                results['hsv_similarity'] = calculate_hsv_histogram_similarity(img1, img2)

            elif method == 'lab_similarity':
                results['lab_similarity'] = calculate_lab_similarity(img1, img2)

            elif method == 'texture':
                results['texture'] = calculate_texture_similarity(gray1, gray2)

            elif method == 'glcm_similarity':
                results['glcm_similarity'] = calculate_glcm_similarity(gray1, gray2)

            elif method == 'shape_similarity':
                results['shape_similarity'] = calculate_shape_similarity(gray1, gray2)

            elif method == 'gabor_similarity':
                results['gabor_similarity'] = calculate_gabor_similarity(gray1, gray2)

            elif method == 'contour_overlap':
                score, debug_path = contour_overlap_similarity(img1, img2, source_pid, match_pid)
                results['contour_overlap'] = score
                results['contour_debug_path'] = debug_path

            elif method == 'feature_contour':
                score, debug_path = feature_contour_similarity(img1, img2, source_pid, match_pid)
                results['feature_contour'] = score
                results['feature_contour_debug_path'] = debug_path

            elif method == 'fashion_clip':
                # This method requires the fashion_clip library
                try:
                    print(f"Computing fashion_clip similarity...")
                    score = calculate_fashion_clip_similarity(img1, img2)
                    if score is None:
                        print(f"Warning: fashion_clip returned None, using default value 0.5")
                        score = 0.5
                    print(f"Fashion CLIP similarity score: {score}")
                    results['fashion_clip'] = score
                except Exception as e:
                    print(f"Error computing fashion clip similarity: {e}")
                    print(f"Traceback: {traceback.format_exc()}")
                    results['fashion_clip'] = 0.5  # Use neutral value on error

        # Compute an overall similarity score based on a weighted average of the individual scores
        weights = {
            'a_hash': 0.05,
            'd_hash': 0.05,
            'p_hash': 0.05,
            'histogram': 0.05,
            'ssim': 0.10,
            'mse': 0.05,
            'psnr': 0.05,
            'feature_matching': 0.10,
            'color_moments': 0.05,
            'hsv_similarity': 0.05,
            'lab_similarity': 0.05,
            'texture': 0.05,
            'glcm_similarity': 0.05,
            'shape_similarity': 0.05,
            'gabor_similarity': 0.05,
            'contour_overlap': 0.05,
            'feature_contour': 0.10,
            'fashion_clip': 0.10
        }

        weighted_sum = 0
        total_weight = 0

        for method, weight in weights.items():
            if method in results and isinstance(results[method], (int, float)):
                weighted_sum += results[method] * weight
                total_weight += weight

        if total_weight > 0:
            results['overall_score'] = weighted_sum / total_weight

        # Cache the results for future use
        if not os.path.exists(CACHE_DIR):
            os.makedirs(CACHE_DIR)

        with open(cache_file, 'w') as f:
            # Convert any numpy types to native Python types for JSON serialization
            clean_results = {}
            for key, value in results.items():
                if hasattr(value, 'dtype') and hasattr(value, 'tolist'):
                    clean_results[key] = float(value)
                else:
                    clean_results[key] = value

            json.dump(clean_results, f)

        # 计算各类方法的平均值
        # 1. 哈希方法平均值
        hash_methods = ['a_hash', 'd_hash', 'p_hash']
        hash_values = [results.get(method, 0) for method in hash_methods if method in results]
        results['hash_avg'] = sum(hash_values) / len(hash_values) if hash_values else 0

        # 2. 直方图平均值
        histogram_methods = ['histogram']
        histogram_values = [results.get(method, 0) for method in histogram_methods if method in results]
        results['histogram_avg'] = sum(histogram_values) / len(histogram_values) if histogram_values else 0

        # 3. 高级方法平均值
        advanced_methods = ['ssim', 'feature_matching', 'texture']
        advanced_values = [results.get(method, 0) for method in advanced_methods if method in results]
        results['advanced_avg'] = sum(advanced_values) / len(advanced_values) if advanced_values else 0

        # 4. 颜色空间平均值
        color_space_methods = ['hsv_similarity', 'lab_similarity', 'color_moments']

        # 收集存在的颜色空间值并打印调试信息
        color_space_values = []
        color_space_methods_found = []

        for method in color_space_methods:
            if method in results:
                value = results.get(method, 0)
                color_space_values.append(value)
                color_space_methods_found.append(method)
                print(f"  Found {method}: {value:.4f}")

        # 计算颜色空间平均值
        if color_space_values:
            # 确保HSV和LAB高值能够正确反映在平均值中
            if 'hsv_similarity' in results and 'lab_similarity' in results:
                hsv = results['hsv_similarity']
                lab = results['lab_similarity']

                # 如果两者都很高，确保平均值也很高
                if hsv > 0.95 and lab > 0.95:
                    # 仅使用HSV和LAB计算平均值，不使用color_moments
                    print(f"  Both HSV ({hsv:.4f}) and LAB ({lab:.4f}) are high")
                    results['color_space_avg'] = (hsv + lab) / 2
                else:
                    # 正常计算所有方法的平均值
                    results['color_space_avg'] = sum(color_space_values) / len(color_space_values)
            else:
                # 如果缺少HSV或LAB，使用现有值计算平均值
                results['color_space_avg'] = sum(color_space_values) / len(color_space_values)

            print(f"  Color Space methods found: {color_space_methods_found}")
            print(f"  Color Space values: {[f'{v:.4f}' for v in color_space_values]}")
            print(f"  Color Space average: {results['color_space_avg']:.4f}")
        else:
            results['color_space_avg'] = 0

        # 5. 纹理和形状平均值
        texture_shape_methods = ['glcm_similarity', 'shape_similarity', 'gabor_similarity', 'contour_overlap',
                                 'feature_contour']
        texture_shape_values = [results.get(method, 0) for method in texture_shape_methods if method in results]
        results['texture_shape_avg'] = sum(texture_shape_values) / len(
            texture_shape_values) if texture_shape_values else 0

        # 6. FashionCLIP 平均值 (单独一个)
        if 'fashion_clip' in results:
            results['fashion_clip_avg'] = results['fashion_clip']
        else:
            results['fashion_clip_avg'] = 0

        # 7. 科学计算整体得分 (基于6个维度，考虑到值的特性)
        # 以下方法值越大越好 - 直接使用
        positive_dimensions = [
            results.get('hash_avg', 0),  # 哈希方法 (0-1)
            results.get('histogram_avg', 0),  # 直方图 (0-1)
            results.get('color_space_avg', 0),  # 颜色空间 (0-1)
            results.get('texture_shape_avg', 0),  # 纹理和形状 (0-1)
            results.get('fashion_clip_avg', 0)  # FashionCLIP (0-1)
        ]

        # SSIM通常在[-1,1]范围内，需转换
        ssim_score = results.get('ssim', 0)
        if ssim_score > 1:  # 有些实现可能超过1，需要归一化
            ssim_score = min(1.0, ssim_score / 5.0)
        normalized_ssim = (ssim_score + 1) / 2  # 转换到[0,1]

        # MSE通常是越小越好
        mse_score = results.get('mse', 0)
        normalized_mse = 1.0 / (1.0 + mse_score) if mse_score > 0 else 1.0  # 转换MSE为[0,1]，越小的MSE产生越高的得分

        # 给不同维度分配权重
        weights = {
            'hash': 0.15,  # 哈希方法
            'histogram': 0.10,  # 直方图
            'ssim': 0.15,  # SSIM
            'mse': 0.10,  # MSE
            'color_space': 0.15,  # 颜色空间
            'texture_shape': 0.20,  # 纹理和形状
            'fashion_clip': 0.15  # FashionCLIP
        }

        # 计算加权平均得分
        weighted_score = (
                weights['hash'] * results.get('hash_avg', 0) +
                weights['histogram'] * results.get('histogram_avg', 0) +
                weights['ssim'] * normalized_ssim +
                weights['mse'] * normalized_mse +
                weights['color_space'] * results.get('color_space_avg', 0) +
                weights['texture_shape'] * results.get('texture_shape_avg', 0) +
                weights['fashion_clip'] * results.get('fashion_clip_avg', 0)
        )

        # 确保得分在[0,1]范围内
        results['overall_score'] = max(0.0, min(1.0, weighted_score))

        # Store results for report generation
        comparison_key = f"{source_pid}_{match_pid}"
        comparison_results[comparison_key] = results

        return results

    except Exception as e:
        print(f"Error comparing images: {str(e)}")
        return {'error': str(e)}


def compare_product_with_availabilities(product_url, avail_urls, methods=None):
    """
    Compare a product image with multiple availability images

    Args:
        product_url (str): URL of the product image
        avail_urls (list): List of availability image URLs
        methods (list, optional): List of comparison methods to use

    Returns:
        list: List of comparison results sorted by overall similarity (highest first)
    """
    results = []

    for avail_url in avail_urls:
        result = compare_images(product_url, avail_url, methods)
        results.append(result)

    # Sort results by overall score (descending)
    results.sort(key=lambda x: x.get('overall_score', 0), reverse=True)

    return results


def clear_comparison_results():
    """Clear the stored comparison results"""
    global comparison_results
    comparison_results = {}
    print("Comparison results cleared.")


def clear_image_cache():
    """Clear the image cache to free memory"""
    global image_cache, cache_stats
    image_cache = {}
    cache_stats = {
        'hits': 0,
        'misses': 0,
        'total_requests': 0
    }
    print("Image cache cleared.")


def get_cache_stats():
    """Get statistics about the image cache"""
    global image_cache, cache_stats
    cache_size = len(image_cache)
    memory_usage = 0

    # Estimate memory usage (rough approximation)
    for url, (img, marked_img, _) in image_cache.items():
        if img is not None:
            memory_usage += img.nbytes
        if marked_img is not None:
            memory_usage += marked_img.nbytes

    # Convert to MB
    memory_usage_mb = memory_usage / (1024 * 1024)

    hit_rate = 0
    if cache_stats['total_requests'] > 0:
        hit_rate = cache_stats['hits'] / cache_stats['total_requests'] * 100

    return {
        'cache_size': cache_size,
        'memory_usage_mb': memory_usage_mb,
        'hits': cache_stats['hits'],
        'misses': cache_stats['misses'],
        'total_requests': cache_stats['total_requests'],
        'hit_rate': hit_rate
    }


def preload_images(image_urls):
    """
    Preload and cache multiple images at once

    Args:
        image_urls (list): List of image URLs to load

    Returns:
        int: Number of successfully loaded images
    """
    if not image_urls:
        return 0

    success_count = 0

    print(f"Preloading {len(image_urls)} images...")
    for url in image_urls:
        try:
            if url in image_cache:
                print(f"CACHE HIT: 图片已在缓存中 {url[:50]}...")
                success_count += 1
                continue

            # Load and cache the image
            img, marked_img, crop_coords = get_image_from_url(url, use_cache=True)
            if img is not None:
                success_count += 1
        except Exception as e:
            print(f"Error preloading image {url}: {str(e)}")

    # Print cache stats
    print("\nImage preloading complete")
    cache_stats = get_cache_stats()
    print(f"Cache stats after preloading:")
    print(f"  Cache size: {cache_stats['cache_size']} images")
    print(f"  Memory usage: {cache_stats['memory_usage_mb']:.2f} MB")
    print(f"  Hits: {cache_stats['hits']}, Misses: {cache_stats['misses']}, Total: {cache_stats['total_requests']}")
    print(f"  Hit rate: {cache_stats['hit_rate']:.2f}%")

    return success_count


def histogram_similarity(img1, img2):
    """Calculate histogram similarity between two images.

    Args:
        img1: First image
        img2: Second image

    Returns:
        Similarity score (0-1)
    """
    # 确保图像尺寸相同
    if img1.shape[:2] != img2.shape[:2]:
        img2 = cv2.resize(img2, (img1.shape[1], img1.shape[0]))

    # 检查图像类型并转换为灰度（如果需要）
    if len(img1.shape) == 3 and img1.shape[2] == 3:
        gray1 = cv2.cvtColor(img1, cv2.COLOR_BGR2GRAY)
    else:
        gray1 = img1

    if len(img2.shape) == 3 and img2.shape[2] == 3:
        gray2 = cv2.cvtColor(img2, cv2.COLOR_BGR2GRAY)
    else:
        gray2 = img2

    # 计算直方图
    hist1 = cv2.calcHist([gray1], [0], None, [256], [0, 256])
    hist2 = cv2.calcHist([gray2], [0], None, [256], [0, 256])

    # 归一化直方图
    cv2.normalize(hist1, hist1, 0, 1, cv2.NORM_MINMAX)
    cv2.normalize(hist2, hist2, 0, 1, cv2.NORM_MINMAX)

    # 计算相似度
    score = cv2.compareHist(hist1, hist2, cv2.HISTCMP_CORREL)
    return score


if __name__ == "__main__":
    # Example 2: Fetch single page with custom offset
    result2 = scrape_merge_data(params={
        "stage": 0,
        "offset": 50,  # Start from the first item
        "amount": 5,  # Get 10 items
        "category": "c",
        "fromweb": 1
    })

    # Print cache stats before processing
    print("\nCache stats before processing:")
    print(get_cache_stats())

    # Extract all unique product IDs
    all_product_ids = list(result2.keys())
    print(f"\nFound {len(all_product_ids)} unique product IDs")

    # Preload all product covers in one batch
    print("\nPreloading all product covers...")
    start_time = time.time()
    product_covers = get_product_cover_url(all_product_ids)

    # 预加载所有图片到缓存中 - 包括产品图片和所有可用性图片
    print("\n开始预加载产品图片到缓存...")
    all_image_urls = []

    # 添加产品封面图片
    product_image_urls = list(product_covers.values())
    all_image_urls.extend(product_image_urls)

    # 添加所有可用性图片
    for product_id, availabilities in result2.items():
        for avail in availabilities:
            if 'cover' in avail and avail['cover']:
                all_image_urls.append(replace_s3_url(avail['cover']))

    # 预加载所有图片
    print(f"预加载总计 {len(all_image_urls)} 张图片")
    preload_images(all_image_urls)

    end_time = time.time()
    print(f"Preloaded all images in {end_time - start_time:.2f} seconds")

    # Process products and availabilities
    for product_id, avail_ids in result2.items():
        print(f"\nProcessing Product ID: {product_id} with {len(avail_ids)} availabilities")

        # Process all availability images for this product
        for i, avail in enumerate(avail_ids):
            # Compare the product cover with availability image
            print(f"  Comparison {i + 1}/{len(avail_ids)} for Product ID: {product_id}, Avail ID: {avail['id']}")

            # This will use the cached product image since we've already preloaded it
            comparison_result = compare_images(replace_s3_url(product_covers.get(product_id)),
                                               replace_s3_url(avail['cover']),
                                               source_pid=product_id, match_pid=avail['id'])

            # Show a brief summary of results
            overall_score = comparison_result.get('overall_score', 0)
            print(f"  Overall similarity score: {overall_score:.4f}")

        # Print cache stats after processing this product
        cache_stats = get_cache_stats()
        print(f"Cache stats after processing product {product_id}:")
        print(f"  Cache size: {cache_stats['cache_size']} images")
        print(f"  Memory usage: {cache_stats['memory_usage_mb']:.2f} MB")
        print(f"  Hits: {cache_stats['hits']}, Misses: {cache_stats['misses']}")
        print(f"  Hit rate: {cache_stats['hit_rate']:.2f}%")

    # Generate HTML report
    report_path = generate_html_report()
    print(f"\nHTML report generated: {report_path}")

    # Clear the cache to free memory
    clear_image_cache()