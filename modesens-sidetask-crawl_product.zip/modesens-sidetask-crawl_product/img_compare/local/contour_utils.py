import os
import time
import tempfile
import cv2
import numpy as np
import re

from img_compare.cache import DEBUG_DIR

__all__ = [
    "contour_overlap_similarity",
    "feature_contour_similarity",
    "calculate_contour_overlap_similarity",
    "calculate_feature_based_contour_similarity"
]

def calculate_contour_overlap_similarity(img1, img2):
    """
    Calculate similarity between two images based on contour overlap.
    """
    if img1 is None or img2 is None:
        return 0.0
    
    # Ensure same dimensions
    if img1.shape != img2.shape:
        h, w = max(img1.shape[0], img2.shape[0]), max(img1.shape[1], img2.shape[1])
        img1 = cv2.resize(img1, (w, h))
        img2 = cv2.resize(img2, (w, h))
    else:
        h, w = img1.shape[:2]
    
    # Convert to grayscale
    gray1 = cv2.cvtColor(img1, cv2.COLOR_BGR2GRAY)
    gray2 = cv2.cvtColor(img2, cv2.COLOR_BGR2GRAY)
    
    # Gaussian blur to reduce noise
    blurred1 = cv2.GaussianBlur(gray1, (5, 5), 0)
    blurred2 = cv2.GaussianBlur(gray2, (5, 5), 0)
    
    # Create masks for contours
    mask1 = np.zeros(gray1.shape, dtype=np.uint8)
    mask2 = np.zeros(gray2.shape, dtype=np.uint8)
    
    # Use multiple methods to extract contours
    methods = [
        lambda img: cv2.threshold(img, 0, 255, cv2.THRESH_BINARY_INV + cv2.THRESH_OTSU)[1],
        lambda img: cv2.adaptiveThreshold(img, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, 
                                       cv2.THRESH_BINARY_INV, 11, 2),
        lambda img: cv2.Canny(img, 50, 150),
    ]
    
    # Apply methods to both images
    for method in methods:
        # Apply to image 1
        thresh1 = method(blurred1)
        contours1, _ = cv2.findContours(thresh1, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        if contours1:
            min_area = 0.01 * (h * w)
            significant_contours = [c for c in contours1 if cv2.contourArea(c) > min_area]
            if significant_contours:
                cv2.drawContours(mask1, significant_contours, -1, 255, -1)
        
        # Apply to image 2
        thresh2 = method(blurred2)
        contours2, _ = cv2.findContours(thresh2, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        if contours2:
            min_area = 0.01 * (h * w)
            significant_contours = [c for c in contours2 if cv2.contourArea(c) > min_area]
            if significant_contours:
                cv2.drawContours(mask2, significant_contours, -1, 255, -1)
    
    # If no contours found, try color segmentation
    if np.count_nonzero(mask1) == 0 or np.count_nonzero(mask2) == 0:
        pixels1 = img1.reshape((-1, 3))
        pixels1 = np.float32(pixels1)
        criteria = (cv2.TERM_CRITERIA_EPS + cv2.TERM_CRITERIA_MAX_ITER, 10, 1.0)
        K = 3  # 3 main colors
        _, labels1, centers1 = cv2.kmeans(pixels1, K, None, criteria, 10, cv2.KMEANS_RANDOM_CENTERS)
        
        cluster_sizes1 = np.bincount(labels1.flatten())
        foreground_cluster = np.argsort(cluster_sizes1)[-2] if len(cluster_sizes1) > 1 else 0
        
        segmentation1 = labels1.reshape(img1.shape[:2])
        mask1 = np.zeros_like(segmentation1, dtype=np.uint8)
        mask1[segmentation1 == foreground_cluster] = 255
        
        # Do the same for image 2
        pixels2 = img2.reshape((-1, 3))
        pixels2 = np.float32(pixels2)
        _, labels2, centers2 = cv2.kmeans(pixels2, K, None, criteria, 10, cv2.KMEANS_RANDOM_CENTERS)
        cluster_sizes2 = np.bincount(labels2.flatten())
        foreground_cluster = np.argsort(cluster_sizes2)[-2] if len(cluster_sizes2) > 1 else 0
        segmentation2 = labels2.reshape(img2.shape[:2])
        mask2 = np.zeros_like(segmentation2, dtype=np.uint8)
        mask2[segmentation2 == foreground_cluster] = 255
    
    # Calculate IoU
    intersection = np.logical_and(mask1, mask2)
    union = np.logical_or(mask1, mask2)
    
    intersection_area = np.count_nonzero(intersection)
    union_area = np.count_nonzero(union)
    
    if union_area == 0:
        return 0.0
    
    iou = intersection_area / union_area
    
    # Visualization
    vis_img = np.zeros((h, w, 3), dtype=np.uint8)
    vis_img[mask1 > 0, 0] = 255  # Blue for image 1
    vis_img[mask2 > 0, 1] = 255  # Green for image 2
    
    img_id = int(time.time() * 1000) % 10000
    debug_path = os.path.join(tempfile.gettempdir(), f"contour_overlap_debug_{img_id}.jpg")
    cv2.imwrite(debug_path, vis_img)
    
    return iou, debug_path


def calculate_feature_based_contour_similarity(img1, img2):
    """
    Calculate similarity based on feature point matching and transformation.
    """
    if img1 is None or img2 is None:
        return 0.0, None
    
    # Resize images to manageable size
    max_dim = 512
    img1 = cv2.resize(img1, (max_dim, max_dim))
    img2 = cv2.resize(img2, (max_dim, max_dim))
    
    # Convert to grayscale
    gray1 = cv2.cvtColor(img1, cv2.COLOR_BGR2GRAY)
    gray2 = cv2.cvtColor(img2, cv2.COLOR_BGR2GRAY)
    
    # Try SIFT or fall back to ORB
    try:
        detector = cv2.SIFT_create()
    except:
        try:
            detector = cv2.xfeatures2d.SIFT_create()
        except:
            detector = cv2.ORB_create(nfeatures=1000)
    
    # Detect key points
    keypoints1, descriptors1 = detector.detectAndCompute(gray1, None)
    keypoints2, descriptors2 = detector.detectAndCompute(gray2, None)
    
    if len(keypoints1) < 4 or len(keypoints2) < 4:
        return 0.1, None
    
    # Create contour masks
    mask1 = np.zeros_like(gray1)
    mask2 = np.zeros_like(gray2)
    
    # Extract contours using thresholding
    thresh1 = cv2.adaptiveThreshold(gray1, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, 
                                cv2.THRESH_BINARY_INV, 21, 10)
    thresh2 = cv2.adaptiveThreshold(gray2, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, 
                                cv2.THRESH_BINARY_INV, 21, 10)
    
    contours1, _ = cv2.findContours(thresh1, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    contours2, _ = cv2.findContours(thresh2, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    
    # Draw significant contours on masks
    area_threshold = 0.01 * max_dim * max_dim
    for contour in contours1:
        if cv2.contourArea(contour) > area_threshold:
            cv2.drawContours(mask1, [contour], -1, 255, -1)
    for contour in contours2:
        if cv2.contourArea(contour) > area_threshold:
            cv2.drawContours(mask2, [contour], -1, 255, -1)
    
    # Feature matching setup
    if isinstance(descriptors1, np.ndarray) and descriptors1.dtype == np.float32:
        bf = cv2.BFMatcher(cv2.NORM_L2, crossCheck=False)
        matcher = cv2.FlannBasedMatcher(dict(algorithm=1, trees=5), dict(checks=50))
    else:
        bf = cv2.BFMatcher(cv2.NORM_HAMMING, crossCheck=False)
        matcher = bf
    
    # Try different matching techniques
    try:
        matches = matcher.knnMatch(descriptors1, descriptors2, k=2)
        good_matches = []
        for m, n in matches:
            if m.distance < 0.75 * n.distance:
                good_matches.append(m)
    except:
        matches = bf.match(descriptors1, descriptors2)
        matches = sorted(matches, key=lambda x: x.distance)
        good_matches = matches[:int(len(matches) * 0.3)]
    
    if len(good_matches) < 4:
        return 0.2, None
    
    # Create debug image showing matches
    debug_matches = cv2.drawMatches(img1, keypoints1, img2, keypoints2, good_matches, None,
                               flags=cv2.DrawMatchesFlags_NOT_DRAW_SINGLE_POINTS)
    
    # Get coordinates of matching points
    src_pts = np.float32([keypoints1[m.queryIdx].pt for m in good_matches]).reshape(-1, 1, 2)
    dst_pts = np.float32([keypoints2[m.trainIdx].pt for m in good_matches]).reshape(-1, 1, 2)
    
    # Try different transformations
    transform_matrix = None
    try:
        matrix, mask_h = cv2.findHomography(src_pts, dst_pts, cv2.RANSAC, 5.0)
        if np.sum(mask_h) >= 4:
            transform_matrix = matrix
    except:
        pass
    
    if transform_matrix is None:
        try:
            matrix, _ = cv2.estimateAffinePartial2D(src_pts, dst_pts, method=cv2.RANSAC, ransacReprojThreshold=3)
            if matrix is not None:
                transform_matrix = matrix
        except:
            pass
    
    if transform_matrix is None:
        try:
            matrix, _ = cv2.estimateAffine2D(src_pts, dst_pts, method=cv2.RANSAC, ransacReprojThreshold=3)
            if matrix is not None:
                transform_matrix = matrix
        except:
            pass
    
    if transform_matrix is None:
        return 0.3, None
    
    # Apply transformation
    if transform_matrix.shape[0] == 3 and transform_matrix.shape[1] == 3:  # homography
        transformed_mask1 = cv2.warpPerspective(mask1, transform_matrix, (max_dim, max_dim))
    else:  # affine
        transformed_mask1 = cv2.warpAffine(mask1, transform_matrix, (max_dim, max_dim))
    
    # Calculate IoU
    intersection = np.logical_and(transformed_mask1, mask2)
    union = np.logical_or(transformed_mask1, mask2)
    
    intersection_area = np.count_nonzero(intersection)
    union_area = np.count_nonzero(union)
    
    iou = intersection_area / union_area if union_area > 0 else 0.0
    
    # Create visualization
    vis_img = np.zeros((max_dim, max_dim, 3), dtype=np.uint8)
    overlap_img = np.zeros_like(vis_img)
    overlap_img[transformed_mask1 > 0] = [0, 0, 255]  # Red for transformed mask1
    overlap_img[mask2 > 0] = [0, 255, 0]  # Green for mask2
    overlap_img[intersection > 0] = [0, 255, 255]  # Yellow for overlap
    
    # Combine debug images
    row1 = np.hstack([
        cv2.addWeighted(img1, 0.7, np.zeros_like(img1), 0.3, 0),
        cv2.addWeighted(img2, 0.7, np.zeros_like(img2), 0.3, 0)
    ])
    
    row2 = np.hstack([debug_matches, overlap_img])
    
    # Ensure rows have same width
    if row1.shape[1] != row2.shape[1]:
        max_width = max(row1.shape[1], row2.shape[1])
        if row1.shape[1] < max_width:
            pad = np.zeros((row1.shape[0], max_width - row1.shape[1], 3), dtype=np.uint8)
            row1 = np.hstack([row1, pad])
        else:
            pad = np.zeros((row2.shape[0], max_width - row2.shape[1], 3), dtype=np.uint8)
            row2 = np.hstack([row2, pad])
    
    final_debug = np.vstack([row1, row2])
    
    # Resize for display
    scale_factor = min(1.0, 1200 / final_debug.shape[1])
    final_debug = cv2.resize(final_debug, (0, 0), fx=scale_factor, fy=scale_factor)
    
    # Save debug image
    img_id = int(time.time() * 1000) % 10000
    debug_path = os.path.join(tempfile.gettempdir(), f"feature_contour_debug_{img_id}.jpg")
    cv2.imwrite(debug_path, final_debug)
    
    # Enhance score based on match quality
    match_quality = min(1.0, len(good_matches) / 50)
    enhanced_iou = 0.3 + (0.7 * iou * match_quality)
    
    return enhanced_iou, debug_path


def contour_overlap_similarity(img1, img2, source_pid='', match_pid=''):
    """Calculate contour overlap similarity (IoU) and return debug image path."""
    # Create debug directory if needed
    if not os.path.exists(DEBUG_DIR):
        os.makedirs(DEBUG_DIR)
    
    # Ensure same dimensions
    if img1.shape != img2.shape:
        h = max(img1.shape[0], img2.shape[0])
        w = max(img1.shape[1], img2.shape[1])
        img1 = cv2.resize(img1, (w, h))
        img2 = cv2.resize(img2, (w, h))
    
    # Convert to grayscale
    gray1 = cv2.cvtColor(img1, cv2.COLOR_BGR2GRAY)
    gray2 = cv2.cvtColor(img2, cv2.COLOR_BGR2GRAY)
    
    # Apply blur
    blurred1 = cv2.GaussianBlur(gray1, (5, 5), 0)
    blurred2 = cv2.GaussianBlur(gray2, (5, 5), 0)
    
    # Edge detection
    edges1 = cv2.Canny(blurred1, 50, 150)
    edges2 = cv2.Canny(blurred2, 50, 150)
    
    # Dilate edges
    kernel = np.ones((3, 3), np.uint8)
    dilated1 = cv2.dilate(edges1, kernel, iterations=1)
    dilated2 = cv2.dilate(edges2, kernel, iterations=1)
    
    # Find contours
    contours1, _ = cv2.findContours(dilated1, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    contours2, _ = cv2.findContours(dilated2, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    
    # Filter small contours
    min_contour_area = 100
    contours1 = [c for c in contours1 if cv2.contourArea(c) > min_contour_area]
    contours2 = [c for c in contours2 if cv2.contourArea(c) > min_contour_area]
    
    # Create masks
    mask1 = np.zeros_like(gray1)
    mask2 = np.zeros_like(gray2)
    
    cv2.drawContours(mask1, contours1, -1, 255, 1)
    cv2.drawContours(mask2, contours2, -1, 255, 1)
    
    # Calculate IoU
    intersection = cv2.bitwise_and(mask1, mask2)
    union = cv2.bitwise_or(mask1, mask2)
    
    intersection_area = np.count_nonzero(intersection)
    union_area = np.count_nonzero(union)
    
    iou = intersection_area / union_area if union_area > 0 else 0
    
    # Create visualization
    overlay1 = img1.copy()
    overlay2 = img2.copy()
    
    cv2.drawContours(overlay1, contours1, -1, (255, 0, 0), 2)
    cv2.drawContours(overlay2, contours2, -1, (0, 255, 0), 2)
    
    # Combine for final visualization
    vis_width = img1.shape[1] * 2
    vis_height = img1.shape[0]
    vis = np.zeros((vis_height, vis_width, 3), dtype=np.uint8)
    vis[:, :img1.shape[1]] = overlay1
    vis[:, img1.shape[1]:] = overlay2
    
    # Create overlap visualization
    overlap_vis = np.zeros((img1.shape[0], img1.shape[1], 3), dtype=np.uint8)
    overlap_vis[mask1 == 255] = [255, 0, 0]  # Blue
    overlap_vis[mask2 == 255] = [0, 255, 0]  # Green
    overlap_vis[intersection == 255] = [0, 255, 255]  # Yellow
    
    final_vis = np.zeros((vis_height * 2, vis_width, 3), dtype=np.uint8)
    final_vis[:vis_height, :] = vis
    overlap_vis_resized = cv2.resize(overlap_vis, (vis_width, vis_height))
    final_vis[vis_height:, :] = overlap_vis_resized
    
    # Add text with score
    cv2.putText(final_vis, f"IoU: {iou:.4f}", (10, 30),
                cv2.FONT_HERSHEY_SIMPLEX, 1, (255, 255, 255), 2)
    
    # Save debug image
    debug_path = os.path.join(DEBUG_DIR, f"contour_overlap_{source_pid}_{match_pid}_{time.time()}.jpg")
    cv2.imwrite(debug_path, final_vis)
    
    return iou, debug_path


def feature_contour_similarity(img1, img2, source_pid='', match_pid=''):
    """
    Computes similarity based on feature points and their surrounding contours.
    This combines feature point detection with contour analysis to create a hybrid approach.
    """
    # Create debug directory if needed
    if not os.path.exists(DEBUG_DIR):
        os.makedirs(DEBUG_DIR)
    
    # Convert to grayscale
    if len(img1.shape) == 3:
        gray1 = cv2.cvtColor(img1, cv2.COLOR_BGR2GRAY)
    else:
        gray1 = img1
        
    if len(img2.shape) == 3:
        gray2 = cv2.cvtColor(img2, cv2.COLOR_BGR2GRAY)
    else:
        gray2 = img2
    
    # Step 1: Detect key features using SIFT
    try:
        sift = cv2.SIFT_create()
        keypoints1, descriptors1 = sift.detectAndCompute(gray1, None)
        keypoints2, descriptors2 = sift.detectAndCompute(gray2, None)
    except:
        # If SIFT isn't available, try ORB
        try:
            orb = cv2.ORB_create()
            keypoints1, descriptors1 = orb.detectAndCompute(gray1, None)
            keypoints2, descriptors2 = orb.detectAndCompute(gray2, None)
        except:
            # If neither work, return low similarity
            return 0.1, ""
    
    # If no keypoints are found, return low similarity
    if descriptors1 is None or descriptors2 is None or len(keypoints1) < 2 or len(keypoints2) < 2:
        return 0.1, ""
    
    # Fallback implementation instead of circular import
    # Implement a simplified version that computes feature matching
    try:
        # Match features using FLANN
        if descriptors1.dtype != np.float32:
            # Convert to float32 for FLANN
            descriptors1 = np.float32(descriptors1)
            descriptors2 = np.float32(descriptors2)
            
        FLANN_INDEX_KDTREE = 1
        index_params = dict(algorithm=FLANN_INDEX_KDTREE, trees=5)
        search_params = dict(checks=50)
        matcher = cv2.FlannBasedMatcher(index_params, search_params)
        
        # Try KNN match
        try:
            matches = matcher.knnMatch(descriptors1, descriptors2, k=2)
            good_matches = []
            for m, n in matches:
                if m.distance < 0.75 * n.distance:
                    good_matches.append(m)
        except:
            # Fall back to BFMatcher
            bf = cv2.BFMatcher()
            matches = bf.match(descriptors1, descriptors2)
            # Sort by distance
            matches = sorted(matches, key=lambda x: x.distance)
            # Take top 30%
            good_matches = matches[:int(len(matches) * 0.3)]
        
        # Calculate similarity based on match count
        score = len(good_matches) / min(len(keypoints1), len(keypoints2))
        score = min(1.0, score)
        
        # Create a debug image
        match_img = cv2.drawMatches(img1, keypoints1, img2, keypoints2, good_matches[:30], None,
                                   flags=cv2.DrawMatchesFlags_NOT_DRAW_SINGLE_POINTS)
        
        # Save debug image
        debug_path = os.path.join(DEBUG_DIR, f"feature_contour_{source_pid}_{match_pid}_{time.time()}.jpg")
        cv2.imwrite(debug_path, match_img)
        
        return score, debug_path
    except Exception as e:
        print(f"Error in feature contour similarity: {e}")
        return 0.2, "" 