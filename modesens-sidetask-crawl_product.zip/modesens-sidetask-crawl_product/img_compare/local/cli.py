import time
from img_compare.scraper import scrape_merge_data, get_product_cover_url
from img_compare.cache import get_cache_stats, preload_images, clear_image_cache
from img_compare.io_utils import replace_s3_url
from img_compare.main import compare_images
from img_compare.report import generate_html_report


def main():
    # Example API scrape
    result2 = scrape_merge_data(
        url="http://44.220.20.247/product/mergeexam/",
        params={"stage": 0, "offset": 50, "amount": 5, "category": "c", "fromweb": 1},
        fetch_all=False
    )

    # Print initial cache stats
    print("\nCache stats before processing:")
    print(get_cache_stats())

    # Get product cover URLs
    all_product_ids = list(result2.keys())
    print(f"\nFound {len(all_product_ids)} unique product IDs")
    print("\nPreloading product cover images...")
    start_time = time.time()
    product_covers = get_product_cover_url(all_product_ids)
    # Collect all image URLs (product covers + avail covers)
    all_image_urls = []
    all_image_urls.extend(product_covers.values())
    for pid, avails in result2.items():
        for avail in avails:
            cover = avail.get('cover')
            if cover:
                all_image_urls.append(replace_s3_url(cover))
    preload_images(all_image_urls)
    print(f"Preloaded images in {time.time() - start_time:.2f} seconds")

    # Compare each product with its availabilities
    for product_id, avails in result2.items():
        print(f"\nProcessing Product ID: {product_id} ({len(avails)} availabilities)")
        for i, avail in enumerate(avails, start=1):
            img1_url = replace_s3_url(product_covers.get(product_id, ''))
            img2_url = replace_s3_url(avail.get('cover', ''))
            print(f"  Comparison {i}/{len(avails)}: {img1_url} vs {img2_url}")
            result = compare_images(img1_url, img2_url, source_pid=product_id, match_pid=avail.get('id'))
            score = result.get('overall_score', 0)
            print(f"    Overall similarity: {score:.4f}")
        # Print per-product cache stats
        stats = get_cache_stats()
        print(f"Cache stats after product {product_id}: {stats}")

    # Generate HTML report
    report_path = generate_html_report()
    print(f"\nHTML report generated: {report_path}")

    # Clear cache to free memory
    clear_image_cache()


if __name__ == "__main__":
    main() 