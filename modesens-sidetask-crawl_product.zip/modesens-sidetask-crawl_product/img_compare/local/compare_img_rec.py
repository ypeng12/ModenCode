
import os
import mysql.connector
import tempfile
import time
import json
import webbrowser


DB = {
    'ENGINE': 'django.db.backends.mysql',
    'NAME': 'lsmerge',
    'USER': os.getenv(f'EXAM_DB_USER', 'lsmergeprod1'),
    'PASSWORD': os.getenv(f'EXAM_DB_PASSWORD', 'Zt%L7&d9`5&}Q+1'),
    'HOST': os.getenv(f'LSMERGE_DB_HOST', 'lsmerge.cnocxcr96apd.us-east-1.rds.amazonaws.com'),
    'PORT': os.getenv(f'DB_PORT', '3306'),
    'CONN_MAX_AGE': 60,
    'OPTIONS': {'charset': 'utf8mb4'}
}


def query_db(sql):
    try:
        # Connect to database using configuration
        connection = mysql.connector.connect(
            host=DB['HOST'],
            user=DB['USER'],
            password=DB['PASSWORD'],
            database=DB['NAME'],
            port=int(DB['PORT'])
        )

        # Create cursor
        cursor = connection.cursor(dictionary=True)

        query = sql

        # Execute query to get cover URL from product table using IN clause
        cursor.execute(query)

        # Fetch result
        result = cursor.fetchall()

        # Close cursor and connection
        cursor.close()
        connection.close()

        return result
    except Exception as e:
        print(f"Error retrieving product cover from database: {str(e)}")




def gen_html(rec_list):
    table = """
    <table>
    <thead><tr>
        <td>main</td>
        <td>compare</td>
        <td>score</td>
        </tr>
    </thead>
    """
    for rec in rec_list:

        line = f"""
        <tr>
        <td><img src="{rec["main_url"]}"><span>{rec["main_pid"]}</span></td>
        <td><img src="{rec["compare_url"]}"><span>{rec["compare_pid"]}</span></td>
        <td><span>{rec["score"]}</span></td>
        </tr>
        """
        table += line

    table += "</table>"

    html_content = f"""
    <html>
    <body>
    {table}
    </body>
    </html>    
    """

    output_path = None
    # Save the HTML report
    if not output_path:
        output_path = os.path.join(tempfile.gettempdir(), f"image_comparison_report_{int(time.time())}.html")
    with open(output_path, 'w') as f:
        f.write(html_content)
    try:
        webbrowser.open('file://' + os.path.abspath(output_path))
        print(f"Report generated and opened: {output_path}")
    except Exception:
        print(f"Report saved at: {output_path}")
    return output_path



if __name__ == '__main__':
    sql = "select * from product_productimgcomparerec  where score > 0.95  and created_datetime > DATE_SUB(CURRENT_DATE, INTERVAL 4 DAY) order by  created_datetime desc limit 100 offset 400"
    query = query_db(sql)
    gen_html(query)