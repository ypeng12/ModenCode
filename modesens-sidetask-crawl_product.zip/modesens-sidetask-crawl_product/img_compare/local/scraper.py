import requests
import json
import mysql.connector
import logging
from img_compare.main import DB

logger = logging.getLogger(__name__)


def get_product_cover_url(product_ids):
    # Return empty if no product IDs
    if not product_ids:
        return {}
    """
    Retrieve product cover URLs for given product IDs from the database.
    Returns a dict mapping product_id -> cover_url.
    """
    try:
        # Connect to database
        connection = mysql.connector.connect(
            host=DB['HOST'],
            user=DB['USER'],
            password=DB['PASSWORD'],
            database=DB['NAME'],
            port=int(DB['PORT'])
        )
        cursor = connection.cursor(dictionary=True)
        ids = ','.join(str(pid) for pid in product_ids)
        query = f"SELECT id, cover FROM product_product WHERE id IN ({ids})"
        cursor.execute(query)
        rows = cursor.fetchall()
        cursor.close()
        connection.close()
        return {r['id']: r['cover'] for r in rows}
    except Exception as e:
        logger.error(f"Error retrieving product cover: {e}")
        return {}


def _make_api_request(url, params, session_cookie=None):
    """
    Internal helper to POST to the merge exam API with cookies.
    """
    try:
        # Full cookies from the curl command
        cookies = {
            "_gcl_au": "1.1.1176166190.1741107989",
            "_ga": "GA1.1.15093203.1741107989",
            "_fbp": "fb.3.1741107988896.478831146273732937",
            "tip_isOK": "true",
            "_ga_DJWKGXM3TP": "GS1.1.1741107988.1.1.1741107997.51.0.1636888614",
            "otoken": "kWe5wGBlvEK4AjBnj18r9JV67zpRxD",
            "lsuid": "20",
            "i18n_country": "us",
            "i18n_locale": "en",
            "sessionid": "w7h9tqv860ughaoxnj4v2mz5op3br1na",
            "gender": "f",
            "modelinkmodal": "1",
            "recentprds": "109172012,111211382,95911129,95063906,97179743,110705994,110705993,111219837,111219893,96508015,109986591",
            "recentdesigners": "MOSCHINO,ON RUNNING,NIKE,JIMMY CHOO,MAISON MARGIELA,AMINA MUADDI,BERNARDO FOOTWEAR",
            "murls": "",
            "assistedcheckout": "3",
            "showgiftcard": "1"
        }
        
        # Add or override with session_cookie if provided
        if session_cookie:
            name, val = session_cookie.split('=', 1)
            cookies[name] = val
            
        # Required headers from curl
        headers = {
            "Accept": "*/*",
            "Accept-Language": "en-GB,en-US;q=0.9,en;q=0.8",
            "Connection": "keep-alive",
            "Content-Type": "application/x-www-form-urlencoded",
            "Origin": "http://44.220.20.247",
            "Referer": "http://44.220.20.247/product/mergeexam/",
            "User-Agent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko)",
            "X-CSRFToken": "null",
            "X-Requested-With": "XMLHttpRequest" 
        }
        
        # Add CSRF token to params if not already present
        if 'csrfmiddlewaretoken' not in params:
            params['csrfmiddlewaretoken'] = "vmIXbvrzwwQqQ0dOjNODhuiO46b87rdoOFdF36rpHAMTmRljlzloVtpIgVtdF86K"
            
        response = requests.post(url, data=params, cookies=cookies, headers=headers, verify=False)
        if response.status_code != 200:
            logger.error(f"API request failed: {response.status_code}")
            return None
        return response.json()
    except Exception as e:
        logger.error(f"Error during API request: {e}")
        return None


def _process_response_data(response_data):
    """
    Process the JSON response to extract product-to-avail mappings.
    """
    result = {}
    if not response_data:
        return result
    if response_data.get('result') == 'success':
        for merge in response_data.get('merges', []):
            for avail in merge.get('avails', []):
                pid = avail.get('product_id')
                if pid:
                    result.setdefault(pid, []).append(avail)
    return result


def scrape_merge_data(url, params=None, fetch_all=False, page_size=10, max_pages=100, session_cookie=None):
    """
    Fetch merge exam data, single page or all pages if fetch_all.
    Returns a dict mapping product_id to list of avails.
    """
    if params is None:
        params = {"offset": 0, "amount": page_size, "fromweb": 1}
    if not fetch_all:
        resp = _make_api_request(url, params, session_cookie)
        return _process_response_data(resp) if resp else {}
    all_data = {}
    for page in range(max_pages):
        params['offset'] = page * page_size
        resp = _make_api_request(url, params, session_cookie)
        if not resp:
            break
        data = _process_response_data(resp)
        all_data.update(data)
        if len(resp.get('merges', [])) < page_size:
            break
    return all_data 