import os
from datetime import datetime
from typing import Dict, Any
import concurrent.futures
import logging

from flask import Flask, request, jsonify
app = Flask(__name__)

logger = logging.getLogger(__name__)

from lambdas.compare import compare_images, load_image


def check_auth_token(app):
    auth_token = request.headers.get('Authorization', "")
    if not auth_token:
        auth_token = request.headers.get('authorization', "")

    if not auth_token:
        return jsonify({"message": "No auth token"}), 400

    if auth_token != os.getenv("AUTH_TOKEN", "test_for_img_compare"):
        return jsonify({"message": "Invalid auth token"}), 401


@app.get("/health")
def get():
    ret = check_auth_token(app)
    if ret:
        return ret

    return jsonify({"message": f"Hello, World! {datetime.now().isoformat()}"}), 200


def process_comparison(main_img: Any, to_compare_item: Dict[str, str], main_id: str, resp_detail: bool,
                       display_time: bool) -> Dict[str, Any]:
    """
    Process a single image comparison.

    Args:
        main_img: The pre-loaded main image
        to_compare_item: Dictionary containing the comparison image URL and ID
        main_id: ID of the main image
        resp_detail: Whether to include detailed results

    Returns:
        Dictionary containing the comparison results
    """
    try:
        result = compare_images(main_img, to_compare_item["url"], source_pid=main_id, match_pid=to_compare_item["id"],
                                display_time=display_time)
        logger.debug("Compare result", extra={"main_id": main_id, "to": to_compare_item, "result": result})

        ret = {"score": result.get("overall_score", 0)}
        if resp_detail:
            ret["detail"] = result
        return {to_compare_item["id"]: ret}
    except Exception as e:
        logger.error("Error comparing images", extra={"main_id": main_id, "to": to_compare_item, "error": str(e)},
                     exc_info=True)
        return {to_compare_item["id"]: {"error": str(e)}}


@app.post("/compare")
def compare():
    """
    params:
        main:object
        to_compare:list[object]

    object:
        url:str
        id:str

    returns:
        threshold:float
        ret:
            id:str
            score:float
    """

    ret = check_auth_token(app)
    if ret:
        return ret

    resp_detail = False
    display_time = False
    if request.args.get("detail", "").upper() == "TRUE":
        resp_detail = True
    if request.args.get("display_time", "").upper() == "TRUE":
        display_time = True

    body = request.get_json()
    if not body:
        return {"message": "No body provided, expected JSON object with main and to_compare keys"}, 400

    main = body.get("main")
    to_compare = body.get("to_compare")

    if not main or not to_compare:
        return {"message": "Invalid body, expected JSON object with main and to_compare keys"}, 400

    if not isinstance(main, dict) or not isinstance(to_compare, list):
        return {"message": "Invalid body, main must be a dict and to_compare must be a list"}, 400

    if not main.get("url") or not main.get("id"):
        return {"message": "Invalid body, main must have url and id keys"}, 400

    if not isinstance(to_compare, list):
        return {"message": "Invalid body, to_compare must be a list"}, 400

    for item in to_compare:
        if not isinstance(item, dict) or not item.get("url") or not item.get("id"):
            return {"message": "Invalid body, to_compare must be a list of dicts with url and id keys"}, 400

    logger.debug("Received to_compare", extra={"main": main, "to_compare": to_compare})

    # Download main image once
    try:
        main_img = load_image(main["url"])
        if main_img is None:
            return {"message": f"Failed to load main image from URL: {main['url']}"}, 400
    except Exception as e:
        logger.error("Error loading main image", extra={"main": main, "error": str(e)}, exc_info=True)
        return {"message": f"Error loading main image: {str(e)}"}, 400

    # Use ThreadPoolExecutor for parallel processing
    ret = {}
    with concurrent.futures.ThreadPoolExecutor(max_workers=min(32, len(to_compare))) as executor:
        # Create future tasks for each comparison
        future_to_item = {
            executor.submit(
                process_comparison,
                main_img,
                to_compare_item,
                main["id"],
                resp_detail,
                display_time,
            ): to_compare_item["id"]
            for to_compare_item in to_compare
        }

        # Process results as they complete
        for future in concurrent.futures.as_completed(future_to_item):
            item_id = future_to_item[future]
            try:
                result = future.result()
                ret.update(result)
            except Exception as e:
                logger.error(f"Error processing comparison for item {item_id}", extra={"error": str(e)}, exc_info=True)
                ret[item_id] = {"error": str(e)}

    if isinstance(ret, dict):
        ret = jsonify(ret)

    return ret, 200


if __name__ == "__main__":
    app.run()
