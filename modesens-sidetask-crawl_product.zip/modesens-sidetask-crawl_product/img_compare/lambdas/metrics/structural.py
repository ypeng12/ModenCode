import cv2
import numpy as np


def calculate_ssim_score(img1, img2):
    """Calculate Structural Similarity Index between two images.

    Args:
        img1: First image
        img2: Second image

    Returns:
        SSIM score (higher is better, max 1.0)
    """
    # 确保图像尺寸相同
    if img1.shape[:2] != img2.shape[:2]:
        img2 = cv2.resize(img2, (img1.shape[1], img1.shape[0]))

    # 检查图像类型并转换为灰度（如果需要）
    if len(img1.shape) == 3 and img1.shape[2] == 3:
        gray1 = cv2.cvtColor(img1, cv2.COLOR_BGR2GRAY)
    else:
        gray1 = img1

    if len(img2.shape) == 3 and img2.shape[2] == 3:
        gray2 = cv2.cvtColor(img2, cv2.COLOR_BGR2GRAY)
    else:
        gray2 = img2

    # 使用OpenCV的SSIM计算
    ssim_score = cv2.matchTemplate(gray1, gray2, cv2.TM_CCOEFF_NORMED)[0][0]
    return float(ssim_score)
