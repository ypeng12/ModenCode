import cv2
import numpy as np
from scipy.spatial.distance import cosine
from skimage.feature import local_binary_pattern
from skimage.feature import graycomatrix, graycoprops

__all__ = [
    "calculate_texture_similarity",
    "calculate_glcm_similarity",
    "calculate_gabor_similarity",
]


def calculate_texture_similarity(img1, img2):
    """Calculate texture similarity using Local Binary Patterns (LBP)"""
    if img1 is None or img2 is None:
        return 0.0

    # Resize images if they are too large (e.g., > 512px in any dimension)
    max_size = 512
    if img1.shape[0] > max_size or img1.shape[1] > max_size:
        scale = max_size / max(img1.shape[0], img1.shape[1])
        new_size = (int(img1.shape[1] * scale), int(img1.shape[0] * scale))
        img1 = cv2.resize(img1, new_size)
    if img2.shape[0] > max_size or img2.shape[1] > max_size:
        scale = max_size / max(img2.shape[0], img2.shape[1])
        new_size = (int(img2.shape[1] * scale), int(img2.shape[0] * scale))
        img2 = cv2.resize(img2, new_size)

    # Convert to grayscale if needed
    if len(img1.shape) == 3 and img1.shape[2] == 3:
        gray1 = cv2.cvtColor(img1, cv2.COLOR_BGR2GRAY)
    else:
        gray1 = img1

    if len(img2.shape) == 3 and img2.shape[2] == 3:
        gray2 = cv2.cvtColor(img2, cv2.COLOR_BGR2GRAY)
    else:
        gray2 = img2

    # 使用多个尺度的LBP特征
    similarities = []
    for radius in [1, 2, 3]:
        n_points = 8 * radius
        lbp1 = local_binary_pattern(gray1, n_points, radius, method='uniform')
        lbp2 = local_binary_pattern(gray2, n_points, radius, method='uniform')

        # Convert LBP values to integers
        lbp1 = lbp1.astype(np.int64)
        lbp2 = lbp2.astype(np.int64)

        # Calculate histograms with reduced bins
        n_bins = 59  # Number of bins for uniform LBP
        hist1 = np.bincount(lbp1.ravel(), minlength=n_bins)
        hist2 = np.bincount(lbp2.ravel(), minlength=n_bins)

        # Normalize histograms
        hist1 = hist1 / np.sum(hist1)
        hist2 = hist2 / np.sum(hist2)

        # 使用巴氏距离而不是相关性
        similarity = 1 - cv2.compareHist(hist1.astype(np.float32), hist2.astype(np.float32), cv2.HISTCMP_BHATTACHARYYA)
        similarities.append(similarity)

    # 返回多个尺度的平均相似度
    return float(np.mean(similarities))


def calculate_feature_matching(img1, img2):
    """Calculate feature matching similarity using ORB features"""
    if img1 is None or img2 is None:
        return 0.0

    # Initialize ORB detector
    orb = cv2.ORB_create()

    # Find keypoints and descriptors
    kp1, des1 = orb.detectAndCompute(img1, None)
    kp2, des2 = orb.detectAndCompute(img2, None)

    if des1 is None or des2 is None:
        return 0.0

    # Create BFMatcher object
    bf = cv2.BFMatcher(cv2.NORM_HAMMING, crossCheck=True)

    # Match descriptors
    matches = bf.match(des1, des2)

    # Calculate similarity score
    if len(matches) > 0:
        # Get distances of matches
        distances = [m.distance for m in matches]
        # Calculate similarity (lower distance = higher similarity)
        similarity = 1 - (np.mean(distances) / 100)  # Normalize to 0-1 range
        similarity = max(0, min(1, similarity))  # Clamp to 0-1 range
    else:
        similarity = 0.0

    return similarity


def calculate_glcm_features(img):
    """Calculate Gray Level Co-occurrence Matrix (GLCM) features"""
    if img is None:
        return np.zeros(5)

    try:
        # 检查图像类型并转换为灰度（如果需要）
        if len(img.shape) == 3 and img.shape[2] == 3:
            gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
        else:
            gray = img

        gray = gray.astype(np.uint8)

        # 使用多个距离和角度计算GLCM
        distances = [1, 2, 3]
        angles = [0, np.pi/4, np.pi/2, 3*np.pi/4]
        features = []

        for d in distances:
            for angle in angles:
                glcm = graycomatrix(gray, distances=[d], angles=[angle], levels=256, symmetric=True, normed=True)
                
                # Calculate texture features
                contrast = graycoprops(glcm, 'contrast')[0, 0]
                dissimilarity = graycoprops(glcm, 'dissimilarity')[0, 0]
                homogeneity = graycoprops(glcm, 'homogeneity')[0, 0]
                energy = graycoprops(glcm, 'energy')[0, 0]
                correlation = graycoprops(glcm, 'correlation')[0, 0]
                
                # 归一化特征值
                contrast = contrast / (256 * 256)  # 归一化对比度
                dissimilarity = dissimilarity / 256  # 归一化差异度
                homogeneity = homogeneity  # 已经在[0,1]范围内
                energy = energy  # 已经在[0,1]范围内
                correlation = (correlation + 1) / 2  # 将[-1,1]映射到[0,1]
                
                features.extend([contrast, dissimilarity, homogeneity, energy, correlation])

        return np.array(features)
    except Exception as e:
        print(f"Error in GLCM features calculation: {str(e)}")
        return np.zeros(5 * len(distances) * len(angles))


def calculate_glcm_similarity(img1, img2):
    """Calculate similarity using GLCM features"""
    if img1 is None or img2 is None:
        return 0.0

    try:
        features1 = calculate_glcm_features(img1)
        features2 = calculate_glcm_features(img2)

        # 检查是否有无效值
        if np.any(np.isnan(features1)) or np.any(np.isnan(features2)):
            return 0.0

        # 分别计算每个距离和角度的相似度
        n_features_per_combination = 5  # 每个距离和角度组合有5个特征
        n_combinations = len(features1) // n_features_per_combination
        similarities = []

        for i in range(n_combinations):
            start_idx = i * n_features_per_combination
            end_idx = start_idx + n_features_per_combination
            
            # 获取当前组合的特征
            f1 = features1[start_idx:end_idx]
            f2 = features2[start_idx:end_idx]
            
            # 计算欧氏距离
            distance = np.linalg.norm(f1 - f2)
            
            # 使用改进的指数衰减函数
            similarity = np.exp(-distance / 2.0)  # 调整衰减速率
            similarities.append(similarity)

        # 计算加权平均相似度
        # 给较近距离和较小角度的组合更大的权重
        weights = []
        for d in [1, 2, 3]:
            for angle in [0, np.pi/4, np.pi/2, 3*np.pi/4]:
                # 距离越近权重越大，角度越小权重越大
                weight = (1.0 / d) * (1.0 / (1 + abs(angle)))
                weights.append(weight)
        
        # 归一化权重
        weights = np.array(weights)
        weights = weights / np.sum(weights)
        
        # 计算加权平均相似度
        similarity = np.average(similarities, weights=weights)
        
        return float(max(0.0, min(1.0, similarity)))
    except Exception as e:
        print(f"Error in GLCM similarity calculation: {str(e)}")
        return 0.0


def calculate_gabor_features(img):
    """Calculate Gabor filter features"""
    if img is None:
        return np.zeros(8)  # 增加特征维度

    # 检查图像类型并转换为灰度（如果需要）
    if len(img.shape) == 3 and img.shape[2] == 3:
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    else:
        gray = img

    gray = gray.astype(np.uint8)

    # 使用多个Gabor滤波器
    features = []
    ksize = 31
    sigma = 8.0
    lambd = 10.0
    gamma = 0.5
    psi = 0

    # 使用4个不同方向的Gabor滤波器
    for theta in [0, np.pi/4, np.pi/2, 3*np.pi/4]:
        kernel = cv2.getGaborKernel((ksize, ksize), sigma, theta, lambd, gamma, psi)
        filtered = cv2.filter2D(gray, cv2.CV_8UC3, kernel)
        
        # 计算每个滤波结果的均值和标准差
        mean = np.mean(filtered)
        std = np.std(filtered)
        features.extend([mean, std])

    return np.array(features)


def calculate_gabor_similarity(img1, img2):
    """Calculate similarity using Gabor filter features"""
    if img1 is None or img2 is None:
        return 0.0

    features1 = calculate_gabor_features(img1)
    features2 = calculate_gabor_features(img2)

    # 使用欧氏距离而不是余弦距离
    distance = np.linalg.norm(features1 - features2)
    
    # 使用指数衰减函数将距离转换为相似度
    similarity = np.exp(-distance / 100.0)  # 除以100.0来调整衰减速率
    
    return float(similarity)

