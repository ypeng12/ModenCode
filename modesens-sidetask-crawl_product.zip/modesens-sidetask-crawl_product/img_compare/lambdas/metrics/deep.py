import logging
from PIL import Image
import numpy as np
import torch
from scipy.spatial.distance import cosine

logger = logging.getLogger(__name__)

fashion_clip_model = None
fashion_clip_processor = None


def load_fashion_clip():
    """
    Load the CLIP model for fashion similarity comparison.
    Note: Using standard CLIP model as it's more reliable than FashionCLIP for this task.
    Returns True if successful, False otherwise.
    """
    global fashion_clip_model, fashion_clip_processor

    try:
        from transformers import CLIPProcessor, CLIPModel
        import torch

        logger.info("Loading CLIP model...")

        # Check if we already have the model loaded
        if fashion_clip_model is not None and fashion_clip_processor is not None:
            logger.info("CLIP model already loaded.")
            return True

        # Verify torch is working properly
        print(f"PyTorch version: {torch.__version__}")
        print(f"CUDA available: {torch.cuda.is_available()}")

        # Use standard CLIP model which is more reliable
        model_name = "openai/clip-vit-base-patch32"

        # Add error handling for model loading
        try:
            fashion_clip_model = CLIPModel.from_pretrained(model_name)
            fashion_clip_processor = CLIPProcessor.from_pretrained(model_name)

            # Put model in evaluation mode
            fashion_clip_model.eval()

            # Use GPU if available
            if torch.cuda.is_available():
                fashion_clip_model = fashion_clip_model.to("cuda")
                print(f"Using GPU for CLIP model: {model_name}")
            else:
                print(f"Using CPU for CLIP model: {model_name}")

            # Test the model with a simple image to ensure it works
            test_img = Image.new('RGB', (224, 224), color='red')
            test_inputs = fashion_clip_processor(images=test_img, return_tensors="pt", padding=True)
            with torch.no_grad():
                test_outputs = fashion_clip_model.get_image_features(**test_inputs)
            if test_outputs is None:
                raise Exception("Model returned None for test image")

            print(f"CLIP model initialization successful. Embedding shape: {test_outputs.shape}")

            logger.info(f"CLIP model {model_name} loaded successfully.")
            return True
        except Exception as e:
            logger.error(f"Error during model initialization: {str(e)}")
            print(f"Model initialization error: {str(e)}")
            fashion_clip_model = None
            fashion_clip_processor = None
            return False
    except ImportError as e:
        logger.error(f"Failed to import required libraries: {str(e)}")
        print(f"Import error: {str(e)}")
        return False
    except Exception as e:
        logger.error(f"Failed to load CLIP model: {str(e)}")
        print(f"Error loading model: {str(e)}")
        return False


def get_fashion_clip_embedding(image):
    """
    Extract FashionCLIP embeddings for an image.

    Args:
        image: PIL Image or numpy array

    Returns:
        numpy array: Normalized embedding vector
    """
    global fashion_clip_model, fashion_clip_processor

    if fashion_clip_model is None or fashion_clip_processor is None:
        success = load_fashion_clip()
        if not success:
            print("  Failed to load CLIP model")
            return None

    try:
        # Convert numpy array to PIL Image if needed
        if isinstance(image, np.ndarray):
            try:
                # Ensure the array has valid values and shape for conversion
                if image.dtype != np.uint8:
                    image = (image * 255).astype(np.uint8)
                image = Image.fromarray(image)
            except Exception as e:
                print(f"  Error converting image array to PIL Image: {str(e)}")
                # Try creating a dummy image as fallback
                print("  Creating fallback image")
                image = Image.new('RGB', (224, 224), color='gray')

        # Print image info for debugging
        if isinstance(image, Image.Image):
            print(f"  Image shape: {image.size}, mode: {image.mode}")
        else:
            print(f"  Warning: Image is not a PIL Image or numpy array: {type(image)}")
            return None

        # Ensure image is in RGB mode
        if image.mode != "RGB":
            try:
                image = image.convert("RGB")
            except Exception as e:
                print(f"  Error converting image to RGB: {str(e)}")
                return None

        # Resize image to expected size (224x224 is standard for CLIP/ViT models)
        try:
            image = image.resize((224, 224))
        except Exception as e:
            print(f"  Error resizing image: {str(e)}")
            return None

        # Preprocess the image
        try:
            inputs = fashion_clip_processor(images=image, return_tensors="pt", padding=True)
        except Exception as e:
            print(f"  Error preprocessing image: {str(e)}")
            return None

        # Get image features (embeddings)
        try:
            with torch.no_grad():  # Add this to make sure we're not computing gradients
                outputs = fashion_clip_model.get_image_features(**inputs)

            # Normalize the embeddings
            norm = outputs.norm(p=2, dim=-1, keepdim=True)
            # Avoid division by zero
            norm = torch.where(norm == 0, torch.ones_like(norm), norm)
            embeddings = outputs / norm

            # Convert to numpy array
            result = embeddings.squeeze().detach().cpu().numpy()

            # Check for NaN values
            if np.isnan(result).any():
                print("  WARNING: NaN values detected in embedding!")
                # Replace NaN values with zeros
                result = np.nan_to_num(result)
                # Re-normalize if needed
                if np.linalg.norm(result) > 0:
                    result = result / np.linalg.norm(result)

            return result
        except Exception as e:
            print(f"  Error getting embeddings: {str(e)}")
            return None

    except Exception as e:
        logger.error(f"Error extracting FashionCLIP embedding: {str(e)}")
        print(f"  Error extracting embedding: {str(e)}")
        return None


def calculate_fashion_clip_similarity(img1, img2):
    """
    Calculate similarity between two images using FashionCLIP embeddings.

    Args:
        img1: First image (PIL Image or numpy array)
        img2: Second image (PIL Image or numpy array)

    Returns:
        float: Similarity score between 0 and 1 (higher means more similar)
              Returns None if embedding extraction fails
    """
    # Check if images are identical objects
    if img1 is img2:
        print("  Images are identical objects - returning 1.0")
        return 1.0

    # Ensure the CLIP model is loaded
    global fashion_clip_model, fashion_clip_processor
    if fashion_clip_model is None or fashion_clip_processor is None:
        success = load_fashion_clip()
        if not success:
            print("  Failed to load FashionCLIP model - returning default similarity 0.5")
            return 0.5  # Return neutral similarity on failure

    try:
        # Extract embeddings
        embed1 = get_fashion_clip_embedding(img1)
        embed2 = get_fashion_clip_embedding(img2)

        # Check if embeddings were extracted successfully
        if embed1 is None or embed2 is None:
            print("  Failed to get embeddings - returning default similarity 0.5")
            return 0.5  # Return neutral similarity on failure

        # Print shapes for debugging
        print(f"  Embedding shapes: {embed1.shape}, {embed2.shape}")

        # For debugging - check if embeddings are identical
        if np.array_equal(embed1, embed2):
            print("  WARNING: Embeddings are identical!")

        # Ensure no NaN values
        embed1 = np.nan_to_num(embed1)
        embed2 = np.nan_to_num(embed2)

        # Re-normalize if needed
        if np.linalg.norm(embed1) > 0:
            embed1 = embed1 / np.linalg.norm(embed1)
        if np.linalg.norm(embed2) > 0:
            embed2 = embed2 / np.linalg.norm(embed2)

        # Compute cosine similarity (1 - cosine distance)
        try:
            similarity = 1 - cosine(embed1, embed2)

            # Print a few values of the embeddings for debugging
            print(f"  Embedding values (first 3): img1={embed1[:3]}, img2={embed2[:3]}")
            print(f"  Computed similarity: {similarity}")

            # Deal with NaN similarity result
            if np.isnan(similarity):
                print("  WARNING: Similarity calculation resulted in NaN, using embedding dot product instead")
                # Fallback to dot product (valid for normalized vectors)
                similarity = float(np.dot(embed1, embed2))

            # Ensure reasonable range
            similarity = max(0.0, min(1.0, float(similarity)))

            return similarity
        except Exception as e:
            logger.error(f"Error calculating FashionCLIP similarity: {str(e)}")
            print(f"  Error in similarity calculation: {str(e)}")
            return 0.5  # Return a neutral similarity value on error

    except Exception as e:
        logger.error(f"Error in fashion_clip_similarity: {str(e)}")
        print(f"  Error in fashion_clip_similarity: {str(e)}")
        return 0.5  # Return a neutral similarity value on error
