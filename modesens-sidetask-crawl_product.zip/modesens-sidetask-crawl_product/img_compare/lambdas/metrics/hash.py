import cv2
import numpy as np

__all__ = [
    "a_hash",
    "d_hash",
    "p_hash",
    "compare_hash",
    "calculate_hash_similarity",
]


def a_hash(img):
    """Average Hash algorithm"""
    if img is None:
        return "0" * 64

    # Resize to 8x8
    img = cv2.resize(img, (8, 8))

    # 检查图像类型并转换为灰度（如果需要）
    if len(img.shape) == 3 and img.shape[2] == 3:
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    else:
        gray = img

    # Calculate average pixel value
    avg = gray.mean()
    # Create hash string (1 for pixels above average, 0 for below)
    hash_str = ''
    for i in range(8):
        for j in range(8):
            if gray[i, j] > avg:
                hash_str += '1'
            else:
                hash_str += '0'
    return hash_str


def d_hash(img):
    """Difference Hash algorithm"""
    if img is None:
        return "0" * 64

    # Resize to 9x8 (one more column than rows)
    img = cv2.resize(img, (9, 8))

    # 检查图像类型并转换为灰度（如果需要）
    if len(img.shape) == 3 and img.shape[2] == 3:
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    else:
        gray = img

    # Create hash string (1 if left pixel > right pixel, 0 otherwise)
    hash_str = ''
    for i in range(8):
        for j in range(8):
            if gray[i, j] > gray[i, j + 1]:
                hash_str += '1'
            else:
                hash_str += '0'
    return hash_str


def p_hash(img):
    """Perceptual Hash algorithm"""
    if img is None:
        return "0" * 64

    # Resize to 32x32
    img = cv2.resize(img, (32, 32))

    # 检查图像类型并转换为灰度（如果需要）
    if len(img.shape) == 3 and img.shape[2] == 3:
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    else:
        gray = img

    # Apply DCT
    dct = cv2.dct(np.float32(gray))
    # Take top-left 8x8 (low frequency)
    dct_roi = dct[:8, :8]
    # Calculate average value (excluding DC component)
    avg = (dct_roi[0, 0] + np.mean(dct_roi)) / 2
    # Create hash string
    hash_str = ''
    for i in range(8):
        for j in range(8):
            if dct_roi[i, j] > avg:
                hash_str += '1'
            else:
                hash_str += '0'
    return hash_str


def compare_hash(hash1, hash2):
    """Compare two hash strings and return the Hamming distance"""
    if len(hash1) != len(hash2):
        return -1

    # Count different bits
    distance = sum(c1 != c2 for c1, c2 in zip(hash1, hash2))
    return distance


def calculate_hash_similarity(img1, img2, method='a_hash'):
    """Calculate hash similarity between two images"""
    if img1 is None or img2 is None:
        return 0.0

    if method == 'a_hash':
        hash1 = a_hash(img1)
        hash2 = a_hash(img2)
    elif method == 'd_hash':
        hash1 = d_hash(img1)
        hash2 = d_hash(img2)
    else:
        raise ValueError(f"Unknown hash method: {method}")

    # Calculate Hamming distance
    distance = compare_hash(hash1, hash2)

    # Convert distance to similarity score (0-1)
    # For 64-bit hash, max distance is 64
    max_distance = 64
    similarity = 1.0 - (distance / max_distance)

    return similarity