import cv2
import numpy as np
from scipy.spatial.distance import cosine
from scipy.stats import moment

__all__ = [
    "calculate_histogram_similarity",
    "calculate_color_moments",
    "calculate_color_moments_similarity",
    "calculate_hsv_histogram_similarity",
    "calculate_lab_similarity",
]


def calculate_histogram_similarity(img1, img2):
    """Calculate histogram similarity between two images.

    Args:
        img1: First image
        img2: Second image

    Returns:
        Similarity score (higher is better, max 1.0)
    """
    try:
        # 确保图像尺寸相同
        if img1.shape[:2] != img2.shape[:2]:
            img2 = cv2.resize(img2, (img1.shape[1], img1.shape[0]))

        # 判断图像是灰度还是彩色
        if len(img1.shape) == 2 or (len(img1.shape) == 3 and img1.shape[2] == 1):
            # 灰度图像
            hist1 = cv2.calcHist([img1], [0], None, [256], [0, 256])
            hist2 = cv2.calcHist([img2], [0], None, [256], [0, 256])

            # 归一化直方图
            cv2.normalize(hist1, hist1, 0, 1, cv2.NORM_MINMAX)
            cv2.normalize(hist2, hist2, 0, 1, cv2.NORM_MINMAX)

            # 计算直方图相似度（使用巴氏距离）
            similarity = cv2.compareHist(hist1, hist2, cv2.HISTCMP_BHATTACHARYYA)
            # 巴氏距离越小表示相似度越高，将其转换为相似度分数
            similarity = 1 - similarity
        else:
            # 彩色图像 - 分别计算RGB三个通道
            similarity = 0
            for i in range(3):
                hist1 = cv2.calcHist([img1], [i], None, [256], [0, 256])
                hist2 = cv2.calcHist([img2], [i], None, [256], [0, 256])

                # 归一化直方图
                cv2.normalize(hist1, hist1, 0, 1, cv2.NORM_MINMAX)
                cv2.normalize(hist2, hist2, 0, 1, cv2.NORM_MINMAX)

                # 累加三个通道的相似度
                channel_similarity = 1 - cv2.compareHist(hist1, hist2, cv2.HISTCMP_BHATTACHARYYA)
                similarity += channel_similarity / 3.0

        return float(max(0.0, min(1.0, similarity)))
    except Exception as e:
        print(f"Error in histogram similarity calculation: {str(e)}")
        return 0.0


# ---------------- colour moments ----------------

def calculate_color_moments(img):
    """Calculate color moments (mean, standard deviation, skewness) for each channel"""
    if img is None:
        return np.zeros(9)

    try:
        # Split into channels
        channels = cv2.split(img)
        moments = []

        for channel in channels:
            # 确保数据类型正确
            channel = channel.astype(np.float32)
            
            # 计算均值
            mean = np.mean(channel)
            
            # 计算标准差
            std = np.std(channel)
            
            # 计算偏度（skewness）
            # 使用更稳定的方法计算偏度
            centered = channel - mean
            std3 = std ** 3
            if std3 > 1e-10:  # 避免除以接近零的值
                skewness = np.mean(centered ** 3) / std3
            else:
                skewness = 0.0

            # 归一化处理
            mean = mean / 255.0  # 归一化到 [0,1] 范围
            std = std / 255.0    # 归一化到 [0,1] 范围
            skewness = np.clip(skewness, -10, 10) / 10.0  # 限制偏度范围并归一化

            moments.extend([mean, std, skewness])

        return np.array(moments, dtype=np.float32)
    except Exception as e:
        print(f"Error in color moments calculation: {str(e)}")
        return np.zeros(9)


def calculate_color_moments_similarity(img1, img2):
    """Calculate similarity between color moments of two images"""
    try:
        if img1 is None or img2 is None:
            return 0.0

        moments1 = calculate_color_moments(img1)
        moments2 = calculate_color_moments(img2)

        # 检查是否有无效值
        if np.any(np.isnan(moments1)) or np.any(np.isnan(moments2)):
            return 0.0

        # 使用更稳定的比较方式
        if np.allclose(moments1, moments2, rtol=1e-5, atol=1e-8):
            return 1.0

        # 分别计算每个通道的相似度
        channel_similarities = []
        for i in range(3):  # 对每个颜色通道
            channel_moments1 = moments1[i*3:(i+1)*3]
            channel_moments2 = moments2[i*3:(i+1)*3]
            
            # 计算该通道的欧氏距离
            distance = np.linalg.norm(channel_moments1 - channel_moments2)
            
            # 使用指数衰减函数计算该通道的相似度
            channel_similarity = np.exp(-distance)
            channel_similarities.append(channel_similarity)

        # 计算加权平均相似度
        # 给绿色通道更大的权重，因为人眼对绿色更敏感
        weights = [0.3, 0.4, 0.3]  # BGR通道的权重
        similarity = np.average(channel_similarities, weights=weights)
        
        return float(max(0.0, min(1.0, similarity)))
    except Exception as e:
        print(f"Error in color moments similarity calculation: {str(e)}")
        return 0.0


# ---------------- HSV histogram ----------------

def calculate_hsv_histogram_similarity(img1, img2):
    """Calculate similarity using HSV color histograms"""
    try:
        if img1 is None or img2 is None:
            return 0.0

        # Convert to HSV
        hsv1 = cv2.cvtColor(img1, cv2.COLOR_BGR2HSV)
        hsv2 = cv2.cvtColor(img2, cv2.COLOR_BGR2HSV)

        # 使用更细粒度的直方图
        h_bins = 30  # 减少H通道的bin数，因为H通道是循环的
        s_bins = 32
        v_bins = 32

        # Calculate histograms for each channel
        hist1_h = cv2.calcHist([hsv1], [0], None, [h_bins], [0, 180])
        hist1_s = cv2.calcHist([hsv1], [1], None, [s_bins], [0, 256])
        hist1_v = cv2.calcHist([hsv1], [2], None, [v_bins], [0, 256])

        hist2_h = cv2.calcHist([hsv2], [0], None, [h_bins], [0, 180])
        hist2_s = cv2.calcHist([hsv2], [1], None, [s_bins], [0, 256])
        hist2_v = cv2.calcHist([hsv2], [2], None, [v_bins], [0, 256])

        # 检查直方图是否为空
        if np.sum(hist1_h) == 0 or np.sum(hist2_h) == 0:
            return 0.0

        # Normalize histograms
        cv2.normalize(hist1_h, hist1_h, alpha=0, beta=1, norm_type=cv2.NORM_MINMAX)
        cv2.normalize(hist1_s, hist1_s, alpha=0, beta=1, norm_type=cv2.NORM_MINMAX)
        cv2.normalize(hist1_v, hist1_v, alpha=0, beta=1, norm_type=cv2.NORM_MINMAX)
        cv2.normalize(hist2_h, hist2_h, alpha=0, beta=1, norm_type=cv2.NORM_MINMAX)
        cv2.normalize(hist2_s, hist2_s, alpha=0, beta=1, norm_type=cv2.NORM_MINMAX)
        cv2.normalize(hist2_v, hist2_v, alpha=0, beta=1, norm_type=cv2.NORM_MINMAX)

        # 使用巴氏距离而不是相关性
        h_similarity = 1 - cv2.compareHist(hist1_h, hist2_h, cv2.HISTCMP_BHATTACHARYYA)
        s_similarity = 1 - cv2.compareHist(hist1_s, hist2_s, cv2.HISTCMP_BHATTACHARYYA)
        v_similarity = 1 - cv2.compareHist(hist1_v, hist2_v, cv2.HISTCMP_BHATTACHARYYA)

        # 加权平均，给饱和度更大的权重
        similarity = 0.2 * h_similarity + 0.4 * s_similarity + 0.4 * v_similarity
        return float(max(0.0, min(1.0, similarity)))
    except Exception as e:
        print(f"Error in HSV similarity calculation: {str(e)}")
        return 0.0


def calculate_lab_similarity(img1, img2):
    """Calculate similarity using LAB color space"""
    try:
        if img1 is None or img2 is None:
            return 0.0

        # Convert to LAB color space
        lab1 = cv2.cvtColor(img1, cv2.COLOR_BGR2LAB)
        lab2 = cv2.cvtColor(img2, cv2.COLOR_BGR2LAB)

        # 计算每个通道的直方图
        hist1_l = cv2.calcHist([lab1], [0], None, [32], [0, 256])
        hist1_a = cv2.calcHist([lab1], [1], None, [32], [0, 256])
        hist1_b = cv2.calcHist([lab1], [2], None, [32], [0, 256])

        hist2_l = cv2.calcHist([lab2], [0], None, [32], [0, 256])
        hist2_a = cv2.calcHist([lab2], [1], None, [32], [0, 256])
        hist2_b = cv2.calcHist([lab2], [2], None, [32], [0, 256])

        # 检查直方图是否为空
        if np.sum(hist1_l) == 0 or np.sum(hist2_l) == 0:
            return 0.0

        # Normalize histograms
        cv2.normalize(hist1_l, hist1_l, alpha=0, beta=1, norm_type=cv2.NORM_MINMAX)
        cv2.normalize(hist1_a, hist1_a, alpha=0, beta=1, norm_type=cv2.NORM_MINMAX)
        cv2.normalize(hist1_b, hist1_b, alpha=0, beta=1, norm_type=cv2.NORM_MINMAX)
        cv2.normalize(hist2_l, hist2_l, alpha=0, beta=1, norm_type=cv2.NORM_MINMAX)
        cv2.normalize(hist2_a, hist2_a, alpha=0, beta=1, norm_type=cv2.NORM_MINMAX)
        cv2.normalize(hist2_b, hist2_b, alpha=0, beta=1, norm_type=cv2.NORM_MINMAX)

        # 使用巴氏距离
        l_similarity = 1 - cv2.compareHist(hist1_l, hist2_l, cv2.HISTCMP_BHATTACHARYYA)
        a_similarity = 1 - cv2.compareHist(hist1_a, hist2_a, cv2.HISTCMP_BHATTACHARYYA)
        b_similarity = 1 - cv2.compareHist(hist1_b, hist2_b, cv2.HISTCMP_BHATTACHARYYA)

        # 加权平均，给a和b通道更大的权重
        similarity = 0.2 * l_similarity + 0.4 * a_similarity + 0.4 * b_similarity
        return float(max(0.0, min(1.0, similarity)))
    except Exception as e:
        print(f"Error in LAB similarity calculation: {str(e)}")
        return 0.0
