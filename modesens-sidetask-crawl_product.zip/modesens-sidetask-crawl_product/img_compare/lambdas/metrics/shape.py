import cv2
import numpy as np
from scipy.spatial.distance import cosine

__all__ = [
    "calculate_hu_moments",
    "calculate_shape_similarity",
    "calculate_mse",
    "calculate_psnr",
]


def calculate_hu_moments(img):
    """Calculate Hu moments for shape comparison"""
    if img is None:
        return np.zeros(7)

    # 检查图像类型并转换为灰度（如果需要）
    if len(img.shape) == 3 and img.shape[2] == 3:
        gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    else:
        gray = img

    gray = gray.astype(np.uint8)

    # Calculate moments
    moments = cv2.moments(gray)
    hu_moments = cv2.HuMoments(moments)

    # 使用更稳定的归一化方法
    for i in range(7):
        if abs(hu_moments[i]) > 1e-10:
            hu_moments[i] = -1 * np.sign(hu_moments[i]) * np.log10(abs(hu_moments[i]))
        else:
            hu_moments[i] = 0

    return hu_moments.flatten()


def calculate_shape_similarity(img1, img2):
    """Calculate similarity using Hu moments"""
    if img1 is None or img2 is None:
        return 0.0

    moments1 = calculate_hu_moments(img1)
    moments2 = calculate_hu_moments(img2)

    # 使用欧氏距离而不是余弦距离
    distance = np.linalg.norm(moments1 - moments2)
    
    # 使用指数衰减函数将距离转换为相似度
    similarity = np.exp(-distance)
    
    return float(similarity)


def calculate_mse(img1, img2):
    """Calculate Mean Squared Error between two images.

    Args:
        img1: First image
        img2: Second image

    Returns:
        MSE score (lower is better)
    """
    # 确保图像尺寸相同
    if img1.shape[:2] != img2.shape[:2]:
        img2 = cv2.resize(img2, (img1.shape[1], img1.shape[0]))

    # 检查图像类型并转换为灰度（如果需要）
    if len(img1.shape) == 3 and img1.shape[2] == 3:
        gray1 = cv2.cvtColor(img1, cv2.COLOR_BGR2GRAY)
    else:
        gray1 = img1

    if len(img2.shape) == 3 and img2.shape[2] == 3:
        gray2 = cv2.cvtColor(img2, cv2.COLOR_BGR2GRAY)
    else:
        gray2 = img2

    # 计算MSE
    mse = np.mean((gray1 - gray2) ** 2)
    return mse


def calculate_psnr(img1, img2):
    """Calculate Peak Signal-to-Noise Ratio between two images.

    Args:
        img1: First image
        img2: Second image

    Returns:
        PSNR score (higher is better)
    """
    # 确保图像尺寸相同
    if img1.shape[:2] != img2.shape[:2]:
        img2 = cv2.resize(img2, (img1.shape[1], img1.shape[0]))

    # 检查图像类型并转换为灰度（如果需要）
    if len(img1.shape) == 3 and img1.shape[2] == 3:
        gray1 = cv2.cvtColor(img1, cv2.COLOR_BGR2GRAY)
    else:
        gray1 = img1

    if len(img2.shape) == 3 and img2.shape[2] == 3:
        gray2 = cv2.cvtColor(img2, cv2.COLOR_BGR2GRAY)
    else:
        gray2 = img2

    # 计算MSE
    mse = np.mean((gray1 - gray2) ** 2)
    if mse == 0:
        return 100.0

    # 计算PSNR
    max_pixel = 255.0
    psnr = 20 * np.log10(max_pixel / np.sqrt(mse))
    return psnr

