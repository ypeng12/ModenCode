import json

import cv2
import re
import urllib3
import math
import requests
import time
from PIL import Image
from io import BytesIO
import numpy as np
# from rembg import remove
from concurrent.futures import ThreadPoolExecutor, as_completed

from aws_lambda_powertools import Logger

from lambdas import metrics


urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)


logger = Logger()


def resize_image(img, max_dimension=800):
    """Resize image keeping aspect ratio up to max_dimension."""
    if img is None:
        return None
    h, w = img.shape[:2]
    factor = min(max_dimension / w, max_dimension / h)
    if factor >= 1.0:
        return img
    new_size = (int(w * factor), int(h * factor))
    return cv2.resize(img, new_size)


def replace_s3_url(url: str) -> str:
    """Shorten S3 URLs by removing prefix and keeping key."""
    if not url:
        return url
    if url.startswith('https://s3.amazonaws.com/'):
        last = url.split('/')[-1]
        if '-' in last and re.match(r'.*\d{6,}$', last):
            key = last.split('-')[-1]
            return url.replace(last, key)
    return url


def load_image(url_or_path):
    """
    Load an image from URL or local path into an OpenCV BGR numpy array.
    """
    start_time = time.time()
    try:
        if isinstance(url_or_path, str) and url_or_path.startswith('http'):
            resp = requests.get(url_or_path, verify=False, timeout=5, headers={'User-Agent': 'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/136.0.0.0 Safari/537.36'})
            if resp.status_code != 200:
                return None
            img = Image.open(BytesIO(resp.content))
            img = np.array(img)
            if img.ndim == 3 and img.shape[2] == 3:
                img = cv2.cvtColor(img, cv2.COLOR_RGB2BGR)
            elapsed = time.time() - start_time
            logger.debug(f"Image download and processing took {elapsed:.2f} seconds", extra={'url': url_or_path})
            return img
        # local file
        img = cv2.imread(url_or_path)
        elapsed = time.time() - start_time
        logger.debug(f"Local image loading took {elapsed:.2f} seconds", extra={'path': url_or_path})
        return img
    except Exception as e:
        elapsed = time.time() - start_time
        logger.warn(f'Could not load image from URL or local path. error:{str(e)}', extra={'url': url_or_path, 'time_taken': elapsed})
        return None


def _compare_hash_methods(img1, img2, method):
    """Compare images using hash-based methods."""
    try:
        if method == 'a_hash':
            hash1 = metrics.a_hash(img1)
            hash2 = metrics.a_hash(img2)
        elif method == 'd_hash':
            hash1 = metrics.d_hash(img1)
            hash2 = metrics.d_hash(img2)
        elif method == 'p_hash':
            hash1 = metrics.p_hash(img1)
            hash2 = metrics.p_hash(img2)
        
        distance = metrics.compare_hash(hash1, hash2)
        max_distance = 64
        return method, 1.0 - (distance / max_distance)
    except Exception as e:
        return method, None


def _compare_feature_matching(gray1, gray2):
    """Compare images using feature matching."""
    try:
        keypoints1, descriptors1 = cv2.SIFT_create().detectAndCompute(gray1, None)
        keypoints2, descriptors2 = cv2.SIFT_create().detectAndCompute(gray2, None)

        if descriptors1 is None or descriptors2 is None or len(keypoints1) < 2 or len(keypoints2) < 2:
            return 'feature_matching', 0.0

        FLANN_INDEX_KDTREE = 1
        index_params = dict(algorithm=FLANN_INDEX_KDTREE, trees=5)
        search_params = dict(checks=50)
        flann = cv2.FlannBasedMatcher(index_params, search_params)

        matches = flann.knnMatch(descriptors1, descriptors2, k=2)
        good_matches = [m for m, n in matches if m.distance < 0.75 * n.distance]

        # Normalize the score to ensure it's between 0 and 1
        # We use the maximum possible number of matches as the denominator
        max_possible_matches = min(len(keypoints1), len(keypoints2))
        score = len(good_matches) / max_possible_matches if max_possible_matches > 0 else 0.0
        
        return 'feature_matching', min(1.0, score)  # Ensure score doesn't exceed 1.0
    except Exception as e:
        return 'feature_matching', None


def _compare_metrics(img1, img2, gray1, gray2, method):
    """Compare images using various metrics."""
    try:
        if method == 'histogram':
            return method, metrics.calculate_histogram_similarity(img1, img2)
        elif method == 'ssim':
            return method, metrics.calculate_ssim_score(gray1, gray2)
        elif method == 'mse':
            return method, metrics.calculate_mse(img1, img2)
        elif method == 'psnr':
            return method, metrics.calculate_psnr(img1, img2)
        elif method == 'color_moments':
            return method, metrics.calculate_color_moments_similarity(img1, img2)
        elif method == 'hsv_similarity':
            return method, metrics.calculate_hsv_histogram_similarity(img1, img2)
        elif method == 'lab_similarity':
            return method, metrics.calculate_lab_similarity(img1, img2)
        elif method == 'texture':
            return method, metrics.calculate_texture_similarity(gray1, gray2)
        elif method == 'glcm_similarity':
            return method, metrics.calculate_glcm_similarity(gray1, gray2)
        elif method == 'shape_similarity':
            return method, metrics.calculate_shape_similarity(gray1, gray2)
        elif method == 'gabor_similarity':
            return method, metrics.calculate_gabor_similarity(gray1, gray2)
        elif method == 'contour_overlap':
            return method, metrics.contour_overlap_similarity(img1, img2, '', '')
        elif method == 'feature_contour':
            return method, metrics.feature_contour_similarity(img1, img2, '', '')
        elif method == 'fashion_clip':
            return method, 0.5
    except Exception as e:
        return method, None

method_map = {
    "color": ['histogram', 'hsv_similarity', 'lab_similarity', 'color_moments'],
    "texture": ['texture', 'glcm_similarity', 'gabor_similarity'],
    "contour": ['shape_similarity', 'contour_overlap', 'feature_contour'],
    "hash": ['a_hash', 'd_hash', 'p_hash'],
    "overall": ['ssim', 'mse', 'psnr'],
    "advance": ['feature_matching']
}

feature_map = {method: category for category, methods in method_map.items() for method in methods}

def compare_images(img1_or_url, img2_url, methods=None, source_pid='', match_pid='', display_time=False):
    """
    Compare two images using multiple methods in parallel and return a dictionary of results.
    """
    total_start_time = time.time()

    if methods is None:
        methods = []
        [methods.extend(x) for x in method_map.values()]

    results = {}
    results['source_pid'] = source_pid
    results['match_pid'] = match_pid

    try:
        # Load the images
        img1 = img1_or_url if not isinstance(img1_or_url, str) else load_image(img1_or_url)
        img2 = load_image(img2_url)

        if img1 is None or img2 is None:
            return {'error': 'Failed to load one or both images'}

        # Resize the images to have the same dimensions
        max_dim = 800
        img1 = resize_image(img1, max_dim)
        # img1 = remove(img1)     # remove background color
        img2 = resize_image(img2, max_dim)
        # img2 = remove(img2)     # remove background color

        # Convert the images to grayscale for some methods
        gray1 = cv2.cvtColor(img1, cv2.COLOR_BGR2GRAY)
        gray2 = cv2.cvtColor(img2, cv2.COLOR_BGR2GRAY)

        # Create a thread pool for parallel processing
        with ThreadPoolExecutor(max_workers=min(len(methods), 8)) as executor:
            futures = []

            # Submit hash-based methods
            for method in ['a_hash', 'd_hash', 'p_hash']:
                if method in methods:
                    futures.append(executor.submit(_compare_hash_methods, img1, img2, method))

            # Submit feature matching
            if 'feature_matching' in methods:
                futures.append(executor.submit(_compare_feature_matching, gray1, gray2))

            # Submit other metrics
            for method in methods:
                if method not in ['a_hash', 'd_hash', 'p_hash', 'feature_matching']:
                    futures.append(executor.submit(_compare_metrics, img1, img2, gray1, gray2, method))

            # Collect results
            for future in as_completed(futures):
                method, result = future.result()
                method_type = feature_map.get(method)
                if method_type not in results:
                    results[method_type] = {}

                if result is not None:
                    results[method_type][method] = result
                    if display_time:
                        method_elapsed = time.time() - total_start_time
                        results[method_type][f'{method}_time'] = method_elapsed
                else:
                    results[method_type][f'{method}_error'] = 'Method failed'

        # 归一化处理各个指标
        normalized_results = {}
        
        # 处理 SSIM (值域 [-1, 1] -> [0, 1])
        if 'ssim' in results.get('overall', {}):
            ssim_score = results['overall']['ssim']
            # 处理可能超过1的情况
            ssim_score = min(1.0, max(-1.0, ssim_score))
            normalized_results['ssim'] = (ssim_score + 1) / 2  # 转换到 [0, 1]
        
        # 处理 MSE (值域 [0, ∞) -> [0, 1])
        if 'mse' in results.get('overall', {}):
            mse_score = results['overall']['mse']
            # 使用改进的归一化方法
            # 对于完全相同的图像，MSE = 0，应该得到1.0
            # 对于差异很大的图像，MSE会很大，应该接近0
            # 使用更陡峭的衰减函数
            normalized_results['mse'] = 1.0 / (1.0 + mse_score / 100.0)  # 调整分母来改变衰减速率
        
        # 处理 PSNR (值域 [0, ∞) -> [0, 1])
        if 'psnr' in results.get('overall', {}):
            psnr_score = results['overall']['psnr']
            normalized_results['psnr'] = min(1.0, psnr_score / 50.0)  # 假设50dB为最大值
        
        # 处理颜色相关指标
        color_metrics = {
            'histogram': lambda x: max(0.0, min(1.0, x)),
            'hsv_similarity': lambda x: max(0.0, min(1.0, x)),
            'lab_similarity': lambda x: max(0.0, min(1.0, x)),
            'color_moments': lambda x: x  # 保持原始值，因为已经在函数内部处理过了
        }
        
        for metric, normalize_func in color_metrics.items():
            if metric in results.get('color', {}):
                score = results['color'][metric]
                if not math.isnan(score):
                    normalized_results[metric] = normalize_func(score)

        # 更新结果字典
        for category in results:
            if isinstance(results[category], dict):
                for metric, score in normalized_results.items():
                    if metric in results[category]:
                        results[category][metric] = score

        # 计算各个维度的平均值
        # 1. 哈希方法平均值
        hash_methods = method_map["hash"]
        hash_values = [results["hash"].get(method, 0) for method in hash_methods if method in results["hash"] and not math.isnan(results["hash"].get(method, 0))]
        results['hash_avg'] = sum(hash_values) / len(hash_values) if hash_values else 0

        texture_methods = method_map["texture"]
        texture_values = [results["texture"].get(method, 0) for method in texture_methods if method in results["texture"] and not math.isnan(results["texture"].get(method, 0))]
        results['texture_avg'] = sum(texture_values) / len(texture_values) if texture_values else 0

        contour_methods = method_map["contour"]
        contour_values = [results["contour"].get(method, 0) for method in contour_methods if method in results["contour"] and not math.isnan(results["contour"].get(method, 0))]
        results['contour_avg'] = sum(contour_values) / len(contour_values) if contour_values else 0

        color_methods = method_map["color"]
        color_values = [results["color"].get(method, 0) for method in color_methods if method in results["color"] and not math.isnan(results["color"].get(method, 0))]
        results['color_avg'] = sum(color_values) / len(color_values) if color_values else 0

        overall_methods = method_map["overall"]
        overall_values = [results["overall"].get(method, 0) for method in overall_methods if method in results["overall"] and not math.isnan(results["overall"].get(method, 0))]
        results["overall_avg"] = sum(overall_values) / len(overall_values) if overall_values else 0

        advance_methods = method_map["advance"]
        advance_values = [results["advance"].get(method, 0) for method in advance_methods if method in results["advance"] and not math.isnan(results["advance"].get(method, 0))]
        results["advance_avg"] = sum(advance_values) / len(advance_values) if advance_values else 0

        # 给不同维度分配权重
        weights = {
            'hash': 0.10,         # 哈希方法 - 基础结构比较
            'texture': 0.25,      # 纹理 - 重要特征
            'contour': 0.25,      # 轮廓 - 重要特征
            'color': 0.25,        # 颜色 - 重要特征
            'overall': 0.10,      # 整体 - 综合指标
            'advance': 0.05       # 高级特征 - 补充特征
        }

        # 计算加权平均得分
        weighted_score = 0.0
        total_weight = 0.0

        for dimension, weight in weights.items():
            avg_score = max(0.0, min(1.0, results.get(f'{dimension}_avg', 0))) # max value is 1
            if not math.isnan(avg_score):
                weighted_score += weight * avg_score
                total_weight += weight

        # 确保得分在[0,1]范围内，并处理权重总和不为1的情况
        results['overall_score'] = max(0.0, min(1.0, weighted_score / total_weight if total_weight > 0 else 0.0))

        total_elapsed = time.time() - total_start_time
        if display_time:
            results['total_time'] = total_elapsed
        logger.debug(f"Total comparison took {total_elapsed:.2f} seconds", 
                   extra={'source_pid': source_pid, 'match_pid': match_pid})
        return results

    except Exception as e:
        total_elapsed = time.time() - total_start_time
        logger.error(f"Error comparing images: {str(e)}", 
                    extra={'error': str(e), 'time_taken': total_elapsed}, exc_info=True)
        return {'error': str(e), 'time_taken': total_elapsed}

if __name__ == '__main__':
   ret = compare_images("https://cdn.modesens.com/availability/eleventy-reversible-gilet-blue-102100810?w=400",
                          "https://cdn.modesens.com/availability/eleventy-mens-sand-padded-sleeveless-linen-gilet-107953576?w=400",
                         display_time=False, match_pid=123, source_pid=456,)
   print(json.dumps(ret, indent=4))