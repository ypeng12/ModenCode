import requests
from urllib.request import urlopen
from xml.etree.ElementTree import parse

# Define the URL and the headers
url = "http://data.zz.baidu.com/urls?site=https://modesens.cn&token=wquEFwohPCV84VAv"
headers = {'Content-Type': 'text/plain'}

# Read the content of urls.txt
# with open('urls.txt', 'rb') as file:
    # file_content = file.read()

var_url = urlopen('https://modesens.cn/sitemap.xml')
xmldoc = parse(var_url)
print(xmldoc)
root = xmldoc.getroot()
print(root)
# print(list(root.iter()))
url_list = []
for item in root:
    for loc in item:
        if loc.tag.endswith('loc'):
            feedpath = loc.text
            print(feedpath)
            url_list.append(feedpath)
            break

offset = 20
amount = 10

file_content = "\n".join(url_list[offset:offset+amount])

print(file_content)

# Make the POST request
response = requests.post(url, headers=headers, data=file_content)

# Print the response
print(response.text)
