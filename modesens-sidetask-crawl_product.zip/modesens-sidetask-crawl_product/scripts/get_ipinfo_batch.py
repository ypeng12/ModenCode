import requests
from bs4 import BeautifulSoup
import time
import json

# 你提供的IP列表
ip_list =newest_ips = [
    "190.92.211.111",
    "68.84.102.163",
    "101.44.163.213",
    "49.187.143.116",
    "78.173.42.249",
    "166.108.239.205",
    "116.71.177.170",
    "39.59.3.254",
    "124.77.96.16",
    "101.255.167.146",
    "111.68.52.191",
    "188.239.15.7",
    "101.173.203.72",
    "119.170.242.77",
    "58.96.255.4",
    "139.135.38.237",
    "77.37.65.114",
    "77.95.45.130",
    "52.167.144.159",
    "54.223.33.119",
    "82.34.11.64",
    "66.249.77.160",
    "188.239.13.127",
    "47.128.17.146",
    "66.249.75.3",
    "101.179.16.249",
    "189.162.193.121",
    "223.104.80.113",
    "109.235.36.206",
    "66.249.77.201",
    "93.202.98.179",
    "43.134.63.65",
    "77.222.27.86",
    "116.179.37.42",
    "52.81.3.53",
    "146.120.231.99",
    "47.128.25.255",
    "47.128.58.212",
    "166.108.203.158",
    "116.179.37.19",
    "54.236.1.13",
    "119.8.172.24",
    "219.77.172.163",
    "103.85.36.174",
    "180.75.237.242",
    "47.128.28.153",
    "188.253.209.33",
    "66.249.77.164",
    "47.128.54.150",
    "47.128.20.117"
]


def get_ip_info(ip_address):
    """
    Get IP information from ipinfo.io for a single IP address
    """
    # 设置请求头，模拟浏览器访问
    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
    }

    url = f"https://ipinfo.io/{ip_address}"

    try:
        # 发送请求
        response = requests.get(url, headers=headers)
        response.raise_for_status()  # 检查请求是否成功

        # 使用BeautifulSoup解析HTML
        soup = BeautifulSoup(response.text, 'html.parser')

        # 找到summary表格
        summary_table = soup.find('div', id='block-summary').find('table')

        # 初始化数据字典
        ip_data = {
            'ip': ip_address
        }

        # 解析表格中的所有行
        for row in summary_table.find_all('tr'):
            columns = row.find_all('td')
            if len(columns) == 2:
                field = columns[0].text.strip()
                value = columns[1].text.strip()

                # 清理字段名称
                field = field.replace('\n', ' ').strip()

                # 存储数据
                ip_data[field] = value

        return ip_data

    except Exception as e:
        print(f"Error processing IP {ip_address}: {str(e)}")
        return {'ip': ip_address, 'error': str(e)}


def main():
    range_set = set()
    for ip in ip_list:
        ip_info = get_ip_info(ip)
        if ip_info.get("ASN type") == "Hosting":
            test_txt = " ".join(ip_info.values())
            test_txt = test_txt.lower()
            whitelist = False
            for allow in ["google", "bing", "microsoft", "msnbot", "pinterest"]:
                whitelist = whitelist or allow in test_txt

            if whitelist:
                continue
            range_set.add(ip_info.get("Range"))
            print(
                f'ip:{ip_info.get("ip")}, range:{ip_info.get("Range")}, ASN:{ip_info.get("ASN")}, Company:{ip_info.get("Company")}, Abuse contact:{ip_info.get("Abuse contact")}')

        time.sleep(1.5)  # 添加延迟，避免请求过快

    if range_set:
        print("\nfinally range set:")
        print("\n".join([x for x in range_set]))

if __name__ == "__main__":
    main()