
### build 

```sam build ```

### deploy
``` sam deploy ```