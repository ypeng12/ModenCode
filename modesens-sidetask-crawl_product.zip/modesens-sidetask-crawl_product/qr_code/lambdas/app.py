
from aws_lambda_powertools import Logger, Tracer, Metrics


logger = Logger()
tracer = Tracer()
metrics = Metrics(namespace="Powertools", service="qr_code")


url_map = {
    'ios': 'https://itunes.apple.com/app/id976201094?utm_source=landingpage&utm_medium=qr&utm_campaign=KUS_campaign',
    'android': 'https://play.google.com/store/apps/details?id=com.modesens.androidapp&utm_source=landingpage&utm_medium=qr&utm_campaign=KUS_campaign&pli=1',
    'default': 'https://modesens.com/?utm_source=landingpage&utm_medium=qr&utm_campaign=KUS_campaign'
}

url_map_campaign20250620 = {
    'ios': 'https://itunes.apple.com/app/id976201094?utm_source=Klaviyo&utm_medium=email&utm_campaign=2025-06-20_editorial_KUS',
    'android': 'https://play.google.com/store/apps/details?id=com.modesens.androidapp&pli=1&utm_source=Klaviyo&utm_medium=email&utm_campaign=2025-06-20_editorial_KUS',
    'default': 'https://itunes.apple.com/app/id976201094?utm_source=Klaviyo&utm_medium=email&utm_campaign=2025-06-20_editorial_KUS'
}

url_map_homepage = {
    'ios': 'https://itunes.apple.com/app/id976201094?utm_source=homepage&utm_medium=button&utm_campaign=KUS_campaign',
    'android': 'https://play.google.com/store/apps/details?id=com.modesens.androidapp&pli=1&utm_source=homepage&utm_medium=button&utm_campaign=KUS_campaign',
    'default': 'https://itunes.apple.com/app/id976201094?utm_source=homepage&utm_medium=button&utm_campaign=KUS_campaign'
}

sys_map= {
    'ios': ['iphone', 'ipad', 'ipod'],
    'android': ['android', 'harmony', 'xiaomi', 'redmi', 'Hyper', 'Magic', 'Color', 'Origin', 'Flyme', 'MyOS', 'ZUI', 'COOL', 'amigo'],
}


path_map = {
    '/campaign20250620': url_map_campaign20250620,
    '/qr_code': url_map,
    '/homepage': url_map_homepage,
}

def ua_match(event, redirect_map):
    default_url = redirect_map['default']
    user_agent = ""

    header = event.get('headers', {})
    if header and isinstance(header, dict):
        user_agent = header.get('User-Agent', '').lower()

    if user_agent:
        for k, v in sys_map.items():
            for vv in v:
                if vv.lower() in user_agent:
                    default_url = redirect_map.get(k, default_url)

    return {
        "statusCode": 302,
        "headers": {
            "Location": default_url,
            "Cache-Control": "no-cache",
        },
        "body": "",
    }


@logger.inject_lambda_context()
@tracer.capture_lambda_handler(capture_response=False)
@metrics.log_metrics(capture_cold_start_metric=True)
def lambda_handler(event, context):
    for k, v in path_map.items():
        if k in event.get('path', '').lower():
            return ua_match(event, v)

    return ua_match(event, url_map)     # default



