import argparse
from idlelib.iomenu import errors
from sqlite3 import IntegrityError

import psycopg2
import re
from datetime import datetime
from psycopg2.errors import DuplicateSchema, InternalError_
import calendar

# （可以清理2024年之前的，并且由于clicks事件有冗余上报，所以通过改Bug能降低数据爆炸速度）modesens,events,133
# （Store BI的订单表，可以清理24年之前的）dws,dws_tob_store_merchant_details_inc,27
# （Store BI的订单表，可以清理24年之前的）dws,dws_tob_store_merchant_details_trend_compare_inc,13
# （数仓中间层表，可以清理24年之前的）dws,dws_tob_store_merchant_active_inc,11
# （LogAgent埋点表，可以清理2024年之前的）modesens,banner_events,7
# 不建议清理：
# （ga的埋点日志，建议先不要做清理，24年11月开始落表）ga,ga_events,37
# （GA埋点日志的解析表，建议不做清理，24年11月开始落表）dws,dws_ga_events_process_inc,21
# （Mysql同步过来的，不能做清理）ods,ods_lsdb_product_productcountry,16
# （Mysql同步过来的，不能做清理）ods,ods_lsdb_product_availabilitycountry,16
# （Store BI库存表，不能做清理）dws,dws_tob_store_stock_products_details_inc,11
# （Mysql同步过来的，不能做清理）ods,ods_lsdb_product_product,10
# （中间表，需要预留出来这个空间）tmp,tmp_dws_tob_stock_products_step3,9
# （Mysql同步过来的，不能做清理）ods,ods_msrw_tracking_merchantorder,9
# （ga的Users表，建议先不要做清理）ga,ga_pseudonymous_user_info,8
# （中间表，需要预留出来这个空间）tmp,tmp_dws_tob_stock_products_step2,7
TABLE_MAPPING = {           # database  = modesense
    "modesens.events": {   # must be in the format of schema.table
        "date_column": {
            "name": "ts",
            "type": "timestamp",     # timestamp, string_YYYY-MM-DD, 
        }, 
        "partition_cols": "EXTRACT(year FROM ts) as year, EXTRACT(month FROM ts) as month",
        "partition": ["year", "month"], # partition by year and month or by year
        "s3_path": "s3://modesens-redshift-data-archive/modesens.events",
        "first_date": "2020-01-01" # format: YYYY-MM-DD
    }
}


def check_table_mapping():
    for table_name, table_info in TABLE_MAPPING.items():
        if table_info['date_column']['type'] not in ["timestamp", "string_YYYY-MM-DD"]:
            raise ValueError(f"Date column type {table_info['date_column']['type']} is not supported")
        if table_info['partition'] != ["year", "month"] and table_info['partition'] != ["year"] and table_info['partition'] != ["year", "month", "day"]:
            raise ValueError(f"Partition {table_info['partition']} is not supported")
        if not table_info['s3_path']:
            raise ValueError(f"S3 path for table {table_name} is not set")
        if not table_info['first_date']:
            raise ValueError(f"First date for table {table_name} is not set")
        if not table_info['partition_cols']:
            raise ValueError(f"Partition cols for table {table_name} is not set")

        if not re.match(r'^\d{4}-\d{2}-\d{2}$', table_info['first_date']):
            raise ValueError(f"First date for table {table_name} is not in the format of YYYY-MM-DD")

REDSHIFT_CONFIG = { 
    "host": "modesensprodmodesens.cguzdfmzuzng.us-east-1.redshift.amazonaws.com",
    "port": 5439,
    "user": "redshift",
    "password": "CwKZMuHvAFKgoP123G",
    "database": "modesens",
    "iam_role": "arn:aws:iam::474636214203:role/RedshiftSpectrumRole",
    "spectrum_db": "spectrum_db",
    "spectrum_schema": "spectrum_schema",
}


def table_name_to_spectrum_table_name(table_name: str):
    return table_name.replace(".", "__")

def get_redshift_connection(use_transaction: bool = True):
    config = {
        "host": REDSHIFT_CONFIG["host"],
        "port": REDSHIFT_CONFIG["port"],
        "user": REDSHIFT_CONFIG["user"],
        "password": REDSHIFT_CONFIG["password"],
        "database": REDSHIFT_CONFIG["database"],
    }
    connection = psycopg2.connect(**config)
    if not use_transaction:
        connection.autocommit = True
    return connection


def execute_sql_out_of_transaction(sql: str):
    conn = get_redshift_connection(use_transaction=False)
    conn.cursor().execute(sql)

def execute_sql(sql: str):
    with get_redshift_connection() as conn:
        with conn.cursor() as cursor:
            cursor.execute(sql)
            conn.commit()

def fetch_query(sql: str):
    with get_redshift_connection() as conn:
        with conn.cursor() as cursor:
            cursor.execute(sql)
            return cursor.fetchall()    

def get_source_table_DDL(table_name: str):
    sql = f"""
    SELECT table_schema, table_name, column_name, data_type, character_maximum_length, numeric_precision, numeric_scale, datetime_precision, interval_precision, is_nullable
    FROM information_schema.columns
    WHERE table_schema = '{table_name.split('.')[0]}'
    AND table_name = '{table_name.split('.')[1]}'
    """

    with get_redshift_connection() as conn:
        with conn.cursor() as cursor:
            cursor.execute(sql)
            data = cursor.fetchall()

    
    # Build DDL statement from column metadata
    columns = []
    for row in data:
        column_name = row[2]
        data_type = row[3]
        
        # Handle special data types that need length/precision/scale
        if data_type == 'character varying' and row[4]:
            data_type = f"varchar({row[4]})"
        elif data_type in ('numeric', 'decimal') and row[5] is not None:
            if row[6] is not None:
                data_type = f"{data_type}({row[5]},{row[6]})"
            else:
                data_type = f"{data_type}({row[5]})"
        elif data_type in ('timestamp', 'time') and row[7] is not None:
            data_type = f"{data_type}({row[7]})"
        elif data_type == 'interval' and row[8] is not None:
            data_type = f"{data_type}({row[8]})"
            
        # Add nullable constraint
        nullable = "" if row[9] == 'YES' else "NOT NULL"
        
        columns.append(f"{column_name} {data_type} {nullable}")
    
    ddl = ",\n    ".join(columns)

    return ddl


def first_step(table_name: str):
    s3_path = TABLE_MAPPING[table_name]['s3_path']
    partition = TABLE_MAPPING[table_name]['partition']

    sql = f"""
    -- 将IAM角色附加到Redshift集群
    CREATE EXTERNAL SCHEMA {REDSHIFT_CONFIG['spectrum_schema']}
    FROM DATA CATALOG
    DATABASE '{REDSHIFT_CONFIG['spectrum_db']}'
    IAM_ROLE '{REDSHIFT_CONFIG['iam_role']}'
    CREATE EXTERNAL DATABASE IF NOT EXISTS;
    """
    try:
        execute_sql(sql)
    except DuplicateSchema:
        print(f"Schema {REDSHIFT_CONFIG['spectrum_schema']} already exists")

    ddl = get_source_table_DDL(table_name)

    sql = f"""
    -- 在Redshift Spectrum中创建外部表
    CREATE EXTERNAL TABLE {REDSHIFT_CONFIG['spectrum_schema']}.{table_name_to_spectrum_table_name(table_name)} (
    {ddl}
    )
    PARTITIONED BY ({', '.join([f"{p} int" for p in partition])})
    STORED AS PARQUET
    LOCATION '{s3_path}';
    """
    try:
        execute_sql_out_of_transaction(sql)
    except Exception as e:
        if "Table already exists" in str(e):
            print(f"Table {table_name_to_spectrum_table_name(table_name)} already exists")
        else:
            raise e

class DateHelper:

    def date_slice(self):
        pass

    def dir_name(self):
        pass

class StringDateHelper(DateHelper):
    def __init__(self, table_name: str, max_date: str, end_date: str):
        self.max_date_exists = True
        if max_date is None:
            max_date = TABLE_MAPPING[table_name]['first_date']
            self.max_date_exists = False

        if len(end_date) == 4: # YYYY
            self._by_year = True
            self.end_date = datetime.strptime(end_date, '%Y')
            self.end_date = self.end_date.replace(month=12, day=31)
        elif len(end_date) == 7: # YYYY-MM
            self._by_year = False
            self.end_date = datetime.strptime(end_date, '%Y-%m')
            self.end_date = self.end_date.replace(day=calendar.monthrange(self.end_date.year, self.end_date.month)[1])
        else:
            raise ValueError(f"End date {end_date} must be in the format of YYYY or YYYY-MM")

        self.start_date = datetime.strptime(max_date, '%Y-%m-%d')

        if self.max_date_exists:
            if self._by_year:
                self.start_date = self.start_date.replace(year=self.start_date.year + 1)
            else:
                if self.start_date.month == 12:
                    self.start_date = self.start_date.replace(year=self.start_date.year + 1, month=1, day=1)
                else:
                    self.start_date = self.start_date.replace(month=self.start_date.month + 1, day=1)
        
    def date_slice(self):
        if self._by_year:
            while self.start_date <= self.end_date:
                yield [self.start_date.strftime('%Y-%m-%d'), self.start_date.replace(month=12, day=31).strftime('%Y-%m-%d'), self.start_date.strftime('%Y')]
                self.start_date = self.start_date.replace(year=self.start_date.year + 1)
        else:
            while self.start_date <= self.end_date:
                yield [self.start_date.strftime('%Y-%m-%d'), self.start_date.replace(day=calendar.monthrange(self.start_date.year, self.start_date.month)[1]).strftime('%Y-%m-%d'), self.start_date.strftime('%Y-%m')]
                if self.start_date.month == 12:
                    self.start_date = self.start_date.replace(year=self.start_date.year + 1, month=1, day=1)
                else:
                    self.start_date = self.start_date.replace(month=self.start_date.month + 1, day=1)
            

class TimestampDateHelper(DateHelper):
    def __init__(self, table_name: str, max_date: datetime, end_date: str):
        self.max_date_exists = True
        if max_date is None:
            max_date = TABLE_MAPPING[table_name]['first_date']
            self.max_date_exists = False

        if len(end_date) == 4: # YYYY
            self._by_year = True
            self.end_date = datetime.strptime(end_date, '%Y')
            self.end_date = self.end_date.replace(month=12, day=31)
        elif len(end_date) == 7: # YYYY-MM
            self._by_year = False
            self.end_date = datetime.strptime(end_date, '%Y-%m')
            self.end_date = self.end_date.replace(day=calendar.monthrange(self.end_date.year, self.end_date.month)[1])
        else:
            raise ValueError(f"End date {end_date} must be in the format of YYYY or YYYY-MM")

        if isinstance(max_date, datetime):
            self.start_date = max_date
        else:
            self.start_date = datetime.strptime(max_date, '%Y-%m-%d')

        if self.max_date_exists:
            if self._by_year:
                self.start_date = self.start_date.replace(year=self.start_date.year + 1)
            else:
                if self.start_date.month == 12:
                    self.start_date = self.start_date.replace(year=self.start_date.year + 1, month=1, day=1)
                else:
                    self.start_date = self.start_date.replace(month=self.start_date.month + 1, day=1)
        
    def date_slice(self):
        if self._by_year:
            while self.start_date <= self.end_date:
                yield [self.start_date.strftime('%Y-%m-%d 00:00:00.000'), self.start_date.replace(month=12, day=31).strftime('%Y-%m-%d 23:59:59.999'), self.start_date.strftime('%Y')]
                self.start_date = self.start_date.replace(year=self.start_date.year + 1)
        else:
            while self.start_date <= self.end_date:
                yield [self.start_date.strftime('%Y-%m-%d 00:00:00.000'), self.start_date.replace(day=calendar.monthrange(self.start_date.year, self.start_date.month)[1]).strftime('%Y-%m-%d 23:59:59.999'), self.start_date.strftime('%Y-%m')]
                if self.start_date.month == 12:
                    self.start_date = self.start_date.replace(year=self.start_date.year + 1, month=1, day=1)
                else:
                    self.start_date = self.start_date.replace(month=self.start_date.month + 1, day=1)


def every_step(table_name: str, end_date: str):
    partition_cols = TABLE_MAPPING[table_name]['partition_cols']
    s3_path = TABLE_MAPPING[table_name]['s3_path']
    partition = TABLE_MAPPING[table_name]['partition']
    date_column = TABLE_MAPPING[table_name]['date_column']['name']
    date_column_type = TABLE_MAPPING[table_name]['date_column']['type']

    sql = f"""
    -- find the max date of the table
    SELECT MAX({date_column}) FROM {REDSHIFT_CONFIG['spectrum_schema']}.{table_name_to_spectrum_table_name(table_name)};
    """
    max_date = fetch_query(sql)[0][0]

    if date_column_type == "string_YYYY-MM-DD": 
        date_helper = StringDateHelper(table_name,max_date, end_date)
    elif date_column_type == "timestamp":
        date_helper = TimestampDateHelper(table_name,max_date, end_date)
    else:
        raise ValueError(f"Date column type {date_column_type} is not supported")


    date_slice = list(date_helper.date_slice())

    for start_date, end_date, dir_name in date_slice:
        print("\ndate range:",start_date, end_date)
        if start_date == end_date:
            continue
        

        sql = f"""
        -- 将历史数据卸载到S3
        UNLOAD ('SELECT *, {partition_cols} FROM   {table_name} WHERE {date_column} > ''{start_date}'' and  {date_column} <= ''{end_date}''')
        TO '{s3_path}/{dir_name}/'
        IAM_ROLE '{REDSHIFT_CONFIG['iam_role']}'
        PARQUET
        PARTITION BY ({', '.join([f"{p}" for p in partition])})
        ALLOWOVERWRITE
        PARALLEL OFF;
        """
        execute_sql(sql)
        print("UNLOAD to ", f'{s3_path}/{dir_name}/')

        if len(dir_name) == 4:  # YYYY
            partition_name = f"year={dir_name}"
        elif len(dir_name) == 7:  # YYYY-MM 
            partition_name = f"year={dir_name[:4]}, month={dir_name[5:]}"
        else:
            raise ValueError(f"Dir name {dir_name} is not supported")

        sql = f"""
        ALTER TABLE {REDSHIFT_CONFIG['spectrum_schema']}.{table_name_to_spectrum_table_name(table_name)}
        DROP PARTITION ({partition_name})
        """
        try:
            execute_sql_out_of_transaction(sql)
        except InternalError_ as e:
            if "not found" in str(e):
                pass
            else:
                raise e

        sql = f"""
        -- 添加分区信息
        ALTER TABLE {REDSHIFT_CONFIG['spectrum_schema']}.{table_name_to_spectrum_table_name(table_name)}
        ADD PARTITION ({partition_name})
        LOCATION '{s3_path}/{dir_name}/';
        """
        execute_sql_out_of_transaction(sql)
        print(f"ADD PARTITION ({partition_name})")

        sql = f"""
        -- 比较原始数据和外部表数据
        SELECT
        (SELECT COUNT(*) FROM {table_name} WHERE {date_column} > '{start_date}' AND {date_column} <= '{end_date}' ) AS original_count,
        (SELECT COUNT(*) FROM {REDSHIFT_CONFIG['spectrum_schema']}.{table_name_to_spectrum_table_name(table_name)} WHERE {" AND ".join(partition_name.split(","))}) AS external_count;
        """
        original_count, external_count = fetch_query(sql)[0]
        print(f"compare original_count:{original_count}, external_count :{external_count}")

        if original_count == external_count:
            if original_count > 0:
                sql = f"""DELETE FROM {table_name} WHERE {date_column} > '{start_date}' AND {date_column} <= '{end_date}';"""
                print("Deleting... ", sql)
                execute_sql_out_of_transaction(sql)
        else:
            print(f"original_count: {original_count}, external_count: {external_count}, please check the data")   
            break


def clear_disk_space(table_name: str):
    sql = f"""
    -- 执行VACUUM回收空间
    VACUUM {table_name};
    """
    execute_sql_out_of_transaction(sql)


def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--table", type=str, required=True)
    parser.add_argument("--end_date", type=str, required=True) # include the time  YYYY or YYYY-MM
    parser.add_argument("--clear_disk_space", type=bool, default=False)
    return parser.parse_args()


def check_args(args: argparse.Namespace):
    if args.table not in TABLE_MAPPING:
        raise ValueError(f"Table {args.table} not found in TABLE_MAPPING")
    
    if TABLE_MAPPING[args.table]['partition'] == ["year"]:
        # format: YYYY
        if not re.match(r'^\d{4}$', args.end_date):
            raise ValueError(f"End date {args.end_date} must be in the format of YYYY")
    if TABLE_MAPPING[args.table]['partition'] == ["year", "month"]:
        # format: YYYY-MM
        if not re.match(r'^\d{4}-\d{2}$', args.end_date):
            raise ValueError(f"End date {args.end_date} must be in the format of YYYY-MM")

        month = int(args.end_date[5:])
        if month > 12 or month < 1:
            raise ValueError(f"Month {month} must be between 1 and 12") 

if __name__ == "__main__":
    """如果中途出错，请手工处理，如果重复执行，会导致source表上一周期的记录未删除！"""
    args = parse_args()
    check_table_mapping()
    check_args(args)
    first_step(args.table)
    every_step(args.table, args.end_date)
    if args.clear_disk_space:
        clear_disk_space(args.table)

"""
SELECT
    schemaname,
    tablename,
    values,
    location
FROM
    svv_external_partitions
WHERE
    schemaname = 'spectrum_schema'  -- 可选筛选
    AND tablename = 'modesens__events';  -- 可选筛选
"""