import unittest
from unittest.mock import patch, MagicMock
from datetime import datetime
import calendar
from copy import deepcopy

from psycopg2 import OperationalError

from main import (
    check_table_mapping,
    StringDateHelper,
    TimestampDateHelper,
    execute_sql,
    fetch_query,
    get_source_table_DDL,
    first_step,
    every_step,
    clear_disk_space,
    parse_args,
    check_args,
    TABLE_MAPPING,
    REDSHIFT_CONFIG
)

class TestTableMapping(unittest.TestCase):
    def test_valid_table_mapping(self):
        # Test with valid table mapping
        try:
            check_table_mapping()
        except ValueError as e:
            self.fail(f"check_table_mapping() raised ValueError unexpectedly: {e}")

    def test_invalid_date_column_type(self):
        # Test with invalid date column type
        invalid_mapping = deepcopy(TABLE_MAPPING)
        invalid_mapping["modesense.events"]["date_column"]["type"] = "invalid_type"
        
        with patch('main.TABLE_MAPPING', invalid_mapping):
            with self.assertRaises(ValueError):
                check_table_mapping()

    def test_invalid_partition(self):
        # Test with invalid partition
        invalid_mapping = deepcopy(TABLE_MAPPING)
        invalid_mapping["modesense.events"]["partition"] = ["invalid"]
        
        with patch('main.TABLE_MAPPING', invalid_mapping):
            with self.assertRaises(ValueError):
                check_table_mapping()

class TestDateHelpers(unittest.TestCase):
    def test_string_date_helper_by_year(self):
        helper = StringDateHelper("", "2022-01-01", "2023")
        dates = list(helper.date_slice())
        
        self.assertEqual(len(dates), 2)  # 2022 and 2023
        self.assertEqual(dates[0][0], "2022-01-01")
        self.assertEqual(dates[0][1], "2022-12-31")
        self.assertEqual(dates[0][2], "2022")

    def test_string_date_helper_by_month(self):
        helper = StringDateHelper("", "2022-01-01", "2022-03")
        dates = list(helper.date_slice())
        
        self.assertEqual(len(dates), 3)  # Jan, Feb, Mar 2022
        self.assertEqual(dates[0][0], "2022-01-01")
        self.assertEqual(dates[0][1], "2022-01-31")
        self.assertEqual(dates[0][2], "2022-01")

    def test_timestamp_date_helper_by_year(self):
        helper = TimestampDateHelper("", "2022-01-01", "2023")
        dates = list(helper.date_slice())
        
        self.assertEqual(len(dates), 2)
        self.assertEqual(dates[0][0], "2022-01-01 00:00:00.000")
        self.assertEqual(dates[0][1], "2022-12-31 23:59:59.999")
        self.assertEqual(dates[0][2], "2022")

class TestSQLFunctions(unittest.TestCase):
    @patch('main.get_redshift_connection')
    def test_execute_sql(self, mock_conn):
        mock_cursor = MagicMock()
        mock_conn.return_value.__enter__.return_value.cursor.return_value.__enter__.return_value = mock_cursor
        
        execute_sql("SELECT 1")
        mock_cursor.execute.assert_called_once_with("SELECT 1")

    @patch('main.get_redshift_connection')
    def test_fetch_query(self, mock_conn):
        mock_cursor = MagicMock()
        mock_cursor.fetchall.return_value = [(1,), (2,)]
        mock_conn.return_value.__enter__.return_value.cursor.return_value.__enter__.return_value = mock_cursor
        
        result = fetch_query("SELECT * FROM test")
        self.assertEqual(result, [(1,), (2,)])

    @patch('main.get_redshift_connection')
    def test_get_source_table_DDL(self, mock_conn):
        mock_cursor = MagicMock()
        mock_cursor.fetchall.return_value = [
            ('schema', 'table', 'column1', 'integer', None, None, None, None, None, 'YES'),
            ('schema', 'table', 'column2', 'character varying', 100, None, None, None, None, 'NO')
        ]
        mock_conn.return_value.__enter__.return_value.cursor.return_value.__enter__.return_value = mock_cursor
        
        ddl = get_source_table_DDL("schema.table")
        self.assertIn("column1 integer NULL", ddl)
        self.assertIn("column2 varchar(100) NOT NULL", ddl)

class TestMainWorkflow(unittest.TestCase):
    @patch('main.execute_sql')
    def test_first_step(self, mock_execute_sql):
        try:
            first_step("modesense.events")
        except OperationalError as e:
            pass
        self.assertTrue(mock_execute_sql.called)

    @patch('main.execute_sql')
    @patch('main.fetch_query')
    def test_every_step(self, mock_fetch_query, mock_execute_sql):
        # First call returns the max date
        # Second call returns the comparison counts (original_count, external_count)
        # Use a list that can be consumed multiple times, not an iterator
        mock_fetch_query.side_effect = lambda *args: [("2022-01-01",)] if "MAX" in args[0] else [(1, 1)]
        
        every_step("modesense.events", "2022-03")
        
        self.assertTrue(mock_execute_sql.called)
        self.assertTrue(mock_fetch_query.called)
        # We expect at least 2 calls to fetch_query
        self.assertGreaterEqual(mock_fetch_query.call_count, 2)

    @patch('main.execute_sql')
    def test_clear_disk_space(self, mock_execute_sql):
        clear_disk_space("modesense.events")
        mock_execute_sql.assert_called_once()

class TestArgumentParsing(unittest.TestCase):
    def test_parse_args(self):
        with patch('sys.argv', ['script.py', '--table', 'modesense.events', '--end_date', '2022']):
            args = parse_args()
            self.assertEqual(args.table, 'modesense.events')
            self.assertEqual(args.end_date, '2022')

    def test_check_args_valid(self):
        args = MagicMock()
        args.table = "modesense.events"
        args.end_date = "2022-12"
        
        try:
            check_args(args)
        except ValueError as e:
            self.fail(f"check_args() raised ValueError unexpectedly: {e}")

    def test_check_args_invalid_table(self):
        args = MagicMock()
        args.table = "invalid.table"
        args.end_date = "2022"
        
        with self.assertRaises(ValueError):
            check_args(args)

    def test_check_args_invalid_date_format(self):
        args = MagicMock()
        args.table = "modesense.events"
        args.end_date = "2022-13"  # Invalid month
        
        with self.assertRaises(ValueError):
            check_args(args)

if __name__ == '__main__':
    unittest.main() 