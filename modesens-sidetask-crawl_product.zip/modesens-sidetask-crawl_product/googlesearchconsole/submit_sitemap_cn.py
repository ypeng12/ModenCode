from google.oauth2 import service_account
from googleapiclient.discovery import build

# from oauth import authorize_creds, execute_request
from urllib.request import urlopen
from xml.etree.ElementTree import parse

creds = 'client_secrets.json' #path to the credentials file.
# webmasters_service = authorize_creds(creds)

site = 'https://modesens.cn'
# sitemap_list = ['/sitemap/sitemap/sitemap-prd-456.xml.gz']

# Define the SCOPES
SCOPES = ['https://www.googleapis.com/auth/webmasters']

def main():
    # Authenticate and build the service
    credentials = service_account.Credentials.from_service_account_file(creds, scopes=SCOPES)
    service = build('webmasters', 'v3', credentials=credentials)

    # List sites
    # site_list = service.sites().list().execute()
    # print(site_list)
    # # Print the sites
    # for site in site_list['siteEntry']:
    #     print(site['siteUrl'])
    # return

    var_url = urlopen('https://modesens.cn/sitemap.xml')
    xmldoc = parse(var_url)
    print(xmldoc)
    root = xmldoc.getroot()
    print(root)
    # print(list(root.iter()))
    for item in root:
        for loc in item:
            if loc.tag.endswith('loc'):
                feedpath = loc.text
                print(feedpath)
                service.sitemaps().submit(siteUrl=site, feedpath=feedpath).execute()
                break


if __name__ == '__main__':
    main()

# print (f'Uploading sitemaps to {site}')
# for sitemap in sitemap_list:
#     feedpath = site + sitemap
#     print(feedpath)
#     webmasters_service.sitemaps().submit(siteUrl=site, feedpath=feedpath).execute()
