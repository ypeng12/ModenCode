
blog_parser = None
parseProdLink = None