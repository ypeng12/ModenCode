from collections import OrderedDict
from . import MerchantConfig, MerchantParser
import json
import re

class Parser(MerchantParser):

    def _extract_defaultvariant(self, html):
        m = re.search(r'const\s+defaultVariant\s*=\s*({.*?});', html, re.S)
        if m:
            try:
                return json.loads(m.group(1))
            except Exception:
                try:
                    return json.loads(m.group(1).replace("'", '"'))
                except Exception:
                    pass
        return {}

    def _sku(self, res, item, **kwargs):
        html = res.get()
        # 1. 先用 window.__product_id__ 正则
        m = re.search(r'window\.__product_id__\s*=\s*"?(?P<sku>\d+)"?;', html)
        if m:
            item['sku'] = m.group('sku')
            return
        # 2. fallback: defaultVariant
        vdata = self._extract_defaultvariant(html)
        if 'sku' in vdata:
            item['sku'] = str(vdata['sku'])
            return
        # 3. fallback: productsObj
        data = self._extract_productsobj(html)
        if data:
            item['sku'] = str(list(data.keys())[0])
        else:
            item['sku'] = 'UNKNOWN'

    def _name(self, res, item, **kwargs):
        html = res.get()
        vdata = self._extract_defaultvariant(html)
        if 'title' in vdata:
            item['name'] = vdata.get('title', '').strip() or 'No name'
            return
        # fallback: productsObj
        data = self._extract_productsobj(html)
        sku = item.get('sku', '')
        product_data = data.get(sku) or (data[list(data.keys())[0]] if data else {})
        item['name'] = product_data.get('item_name', '').strip() or 'No name'

    def _designer(self, res, item, **kwargs):
        html = res.get()
        vdata = self._extract_defaultvariant(html)
        # defaultVariant 没有品牌，用 productsObj
        data = self._extract_productsobj(html)
        sku = item.get('sku', '')
        product_data = data.get(sku) or (data[list(data.keys())[0]] if data else {})
        item['designer'] = product_data.get('item_brand', '').strip() or 'UNKNOWN'

    def _prices(self, res, item, **kwargs):
        html = res.get()
        vdata = self._extract_defaultvariant(html)
        # 优先 defaultVariant price
        if vdata.get("price") and vdata["price"].get("price") and "amount" in vdata["price"]["price"]:
            try:
                item['saleprice'] = float(vdata["price"]["price"]["amount"])
            except Exception:
                item['saleprice'] = 0.0
        else:
            item['saleprice'] = 0.0
        if vdata.get("price") and vdata["price"].get("rrp") and "amount" in vdata["price"]["rrp"]:
            try:
                item['listprice'] = float(vdata["price"]["rrp"]["amount"])
            except Exception:
                item['listprice'] = 0.0
        else:
            item['listprice'] = 0.0
        # fallback: productsObj
        if item['listprice'] == 0.0 or item['saleprice'] == 0.0:
            data = self._extract_productsobj(html)
            sku = item.get('sku', '')
            product_data = data.get(sku) or (data[list(data.keys())[0]] if data else {})
            try:
                item['listprice'] = item['listprice'] or float(product_data.get('price', 0.0)) or 0.0
                item['saleprice'] = item['saleprice'] or float(product_data.get('value', 0.0)) or 0.0
            except Exception:
                pass

    def _extract_productsobj(self, html):
        m = re.search(r'<script[^>]+data-track="productVisit"[^>]*>([\s\S]*?)</script>', html, re.S)
        if m:
            script = m.group(1)
            m2 = re.search(r'productsObj\s*=\s*({.*?})\s*;', script, re.S)
            if m2:
                try:
                    return json.loads(m2.group(1))
                except Exception:
                    try:
                        return json.loads(m2.group(1).replace("'", '"'))
                    except Exception:
                        pass
        m = re.search(r'productsObj\s*=\s*({.*?})\s*;', html, re.S)
        if m:
            try:
                return json.loads(m.group(1))
            except Exception:
                try:
                    return json.loads(m.group(1).replace("'", '"'))
                except Exception:
                    pass
        return {}

    def _images(self, res, item, **kwargs):
        html = res.get()
        vdata = self._extract_defaultvariant(html)
        images = []
        if 'images' in vdata and isinstance(vdata['images'], list):
            for img in vdata['images']:
                if 'original' in img:
                    images.append(img['original'])
        item['images'] = images
        item['cover'] = images[0] if images else ''
        

    def _description(self, res, item, **kwargs):
        html = res.get()
        m = re.search(r'const\s+defaultVariant\s*=\s*({.*?});', html, re.S)
        if m:
            try:
                data = json.loads(m.group(1))
                content_list = data.get('content', [])
                for c in content_list:
                    if c.get('key') == 'synopsis':
                        value = c.get('value', {}).get('richContentListValue', [])
                        if value and value[0].get('content'):
                            raw_html = value[0]['content'][0].get('content', '')
                            clean = re.sub(r'<[^>]+>', '', raw_html).strip()
                            item['description'] = re.sub(r'\s+', ' ', clean)
                            return
            except:
                pass
        item['description'] = ''


_parser = Parser()

class Config(MerchantConfig):
    name = 'lookfantastic'
    merchant = 'Lookfantastic'

    path = dict(
        plist=dict(),
        product=OrderedDict([
            ('sku', ('//html', _parser._sku)),
            ('name', ('//html', _parser._name)),
            ('designer', ('//html', _parser._designer)),
            ('description', ('//html', _parser._description)),
            ('prices', ('//html', _parser._prices)),
            ('sizes', ('//html', _parser._sizes)),
            ('color', ('//html', _parser._color)),
        ])
    )

    countries = dict(
        US=dict(language='EN', currency='USD')
    )
