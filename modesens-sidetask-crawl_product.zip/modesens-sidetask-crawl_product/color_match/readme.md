sam build

sam deploy
