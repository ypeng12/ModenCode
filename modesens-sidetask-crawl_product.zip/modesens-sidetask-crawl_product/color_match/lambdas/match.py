import json
from datetime import datetime

from lambdas.ai_helper import AIHelper
from lambdas.redis_helper import MatchCache
from lambdas.db_helper import ColorAIMatch, Session, initialize_db, session_scope
from aws_lambda_powertools import Logger


logger = Logger()


class AIColorMatch:
    COLOR_CHOICES = {
        'MULTI': {'color': 'MULTI', 'name': '多色'},
        'ANIMAL PRINT': {'color': 'ANIMAL PRINT', 'name': '动物皮纹'},
        'BLACK': {'color': 'BLACK', 'rgb': (0, 0, 0), 'hex': '000000', 'name': '黑色'},
        'BLUE': {'color': 'BLUE', 'rgb': (0, 0, 255), 'hex': '0000FF', 'name': '蓝色'},
        'BROWN': {'color': 'BROWN', 'rgb': (137, 81, 41), 'hex': '#895129', 'name': '棕色'},
        'BURGUNDY': {'color': 'BURGUNDY', 'rgb': (128, 0, 32), 'hex': '800020', 'name': '酒红色'},
        'SAND': {'color': 'SAND', 'rgb': (203, 189, 147), 'hex': '#CBBD93', 'name': '沙色'},
        'GOLD': {'color': 'GOLD', 'rgb': (255, 215, 0), 'hex': 'FFD700', 'name': '金色'},
        'GRAY': {'color': 'GRAY', 'rgb': (128, 128, 128), 'hex': '808080', 'name': '灰色'},
        'SILVER': {'color': 'SILVER', 'rgb': (196, 196, 196), 'hex': '#C4C4C4', 'name': '银色'},
        'GREEN': {'color': 'GREEN', 'rgb': (0, 128, 0), 'hex': '008000', 'name': '绿色'},
        'METALLIC': {'color': 'METALLIC', 'name': '金属色'},
        'NEUTRAL': {'color': 'NEUTRAL', 'rgb': (240, 223, 207), 'hex': 'F0DFCF', 'name': '中性色'},
        'ORANGE': {'color': 'ORANGE', 'rgb': (255, 165, 0), 'hex': 'FFA500', 'name': '橙色'},
        'PATTERN': {'color': 'PATTERN', 'name': '印花'},
        'PINK': {'color': 'PINK', 'rgb': (255, 192, 203), 'hex': 'FFC0CB', 'name': '粉色'},
        'PURPLE': {'color': 'PURPLE', 'rgb': (128, 0, 128), 'hex': '800080', 'name': '紫色'},
        'RED': {'color': 'RED', 'rgb': (255, 0, 0), 'hex': 'FF0000', 'name': '红色'},
        'WHITE': {'color': 'WHITE', 'rgb': (255, 255, 255), 'hex': 'FFFFFF', 'name': '白色'},
        'YELLOW': {'color': 'YELLOW', 'rgb': (255, 255, 0), 'hex': 'FFFF00', 'name': '黄色'},
        'TRANSPARENT': {'color': 'TRANSPARENT', 'rgb': (255, 255, 255), 'hex': 'FFFFFF', 'name': '透明'},
        'NUDE': {'color': 'NUDE', 'name': '裸色'},
        'NAVY': {'color': 'NAVY', 'name': '海军蓝'},
        'BEIGE': {'color': 'BEIGE', 'name': '米色'},
    }

    def __init__(self):
        self.ai_client = AIHelper()

    def _save_to_db(self, input_color, matched_color, db_session):
        """Store match result in database"""
        try:
            with session_scope() as session:
                item = session.query(ColorAIMatch).filter(ColorAIMatch.input_color == input_color).first()

                if not item:
                    item = ColorAIMatch()
                    item.input_color = input_color
                    item.matched_color = matched_color
                    item.create_datetime = datetime.now()
                    item.update_datetime = item.create_datetime
                    session.add(item)
                else:
                    if item.matched_color != matched_color:
                        item.matched_color = matched_color
                        item.update_datetime = datetime.now()
                        session.add(item)
        except Exception as e:
            logger.error(f"Failed to save color match to DB: {input_color} -> {matched_color}. Error: {str(e)}")

    def match(self, color, ai_direct=False):
        """Match a color and cache the result in both Redis and database

        First checks Redis cache, then database, then calls AI service if needed.
        Results are always stored in both Redis and database when a new match is found.
        """
        session = Session()
        if Session is None:
            initialize_db()

        if not ai_direct:
            # Try Redis cache first (faster)
            data = MatchCache(color).get()
            if data:
                MatchCache(color).expire()
                return data

            # Try database next
            try:
                db_match = session.query(ColorAIMatch).filter_by(input_color=color).first()
                if db_match:
                    # Found in DB but not in cache, update cache
                    MatchCache(color).set(db_match.matched_color)
                    return db_match.matched_color
            except Exception:
                # Continue if DB lookup fails
                pass

        ret = self.ai_client.GROK3().chat(
            user_prompt=f"You are a color matching expert. I need to map the color '{color}' to the closest match in our predefined color list. "
                        f"Here are the available colors: {json.dumps(list(self.COLOR_CHOICES.keys()))}. "
                        f"Consider that many input colors may be compound descriptions (like 'NAVY/WHITE' or 'LIGHT BLUE'), "
                        f"brand-specific names, or contain modifiers. Focus on the dominant color or the closest standard match. ",
            system_prompt="Respond only with a single color name from the provided list. "
                          "If there are multiple colors in the input that do not belong to the same color family, please label them as 'MULTI'."
                          "Output in JSON format: ```json{\"color\": \"COLOR_NAME\"}```"
                          "If you're uncertain (less than 95% confident), respond with 'UNKNOWN' for 'COLOR_NAME'. "
        )
        if "```json" in ret:
            ret = ret.split("```json")[1].split("```")[0].strip()
            ret = json.loads(ret)
            ret = ret["color"]

            if not ai_direct:
                # Store in both Redis and database
                MatchCache(color).set(ret)
                self._save_to_db(color, ret, session)
            return ret
        else:
            return ""
