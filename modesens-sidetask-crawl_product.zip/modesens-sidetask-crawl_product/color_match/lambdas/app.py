import os
from datetime import datetime


from aws_lambda_powertools import Logger, Tracer, Metrics
from aws_lambda_powertools.event_handler import ApiGatewayResolver

from lambdas.match import AIColorMatch


logger = Logger()
tracer = Tracer()
metrics = Metrics(namespace="Powertools", service="color-match")


app = ApiGatewayResolver()



@logger.inject_lambda_context()
@tracer.capture_lambda_handler(capture_response=False)
@metrics.log_metrics(capture_cold_start_metric=True)
def lambda_handler(event, context):
    return app.resolve(event, context)

def check_auth_token(app):
    auth_token = app.current_event.headers.get('Authorization', "")
    if not auth_token:
        auth_token = app.current_event.headers.get('authorization', "")

    if not auth_token:
        return {"message": "No auth token"}, 400

    if auth_token != os.getenv("AUTH_TOKEN", "test_for_color_match"):
        return {"message": "Invalid auth token"}, 401

@app.get("/health")
def get():
    ret = check_auth_token(app)
    if ret:
        return ret

    return {"message": f"Hello, World! {datetime.now().isoformat()}"}, 200

@app.post("/color_match")
def color_match():
    ret = check_auth_token(app)
    if ret:
        return ret

    ai_direct = False
    if app.current_event.query_string_parameters.get("ai_direct", "").upper() == "TRUE":
        ai_direct = True

    body = app.current_event.json_body
    if not body:
        return {"message": "No body provided, expected JSON object with main and to_compare keys"}, 400

    input_color = body.get("input")

    if not input_color:
        return {"message": "Invalid body, expected JSON object with input key"}, 400

    if not isinstance(input_color, str):
        return {"message": "Invalid body, input must be a string"}, 400

    try:
        ret = AIColorMatch().match(input_color, ai_direct)
    except Exception as e:
        logger.error(f" AIColorMatch().match({input_color}, {ai_direct}) error:{str(e)}", exc_info=True)
        return {"message": str(e)}, 500

    return {"matched": ret}, 200


