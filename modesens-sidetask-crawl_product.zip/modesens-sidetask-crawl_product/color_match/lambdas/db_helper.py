import os
import logging
from sqlalchemy import create_engine, text
from sqlalchemy.orm import sessionmaker, scoped_session
from contextlib import contextmanager
from aws_lambda_powertools import Logger


logger = Logger()


# 全局数据库引擎和会话工厂
engine = None
Session = None


@contextmanager
def session_scope():
    """提供事务范围的上下文管理器"""
    session = Session()
    try:
        yield session
        session.commit()
    except:
        session.rollback()
        raise
    finally:
        session.close()


def initialize_db():
    """在冷启动时初始化数据库连接"""
    global engine, Session

    try:


        # 创建连接字符串
        db_url = os.getenv('DATABASE_URL')

        # 创建引擎
        engine = create_engine(
            db_url,
            pool_size=5,  # 连接池大小
            max_overflow=2,  # 允许超过pool_size的临时连接数
            pool_recycle=300,  # 连接回收时间(秒)
            pool_pre_ping=True,  # 执行前检查连接是否有效
            connect_args={
                'connect_timeout': 5  # 连接超时5秒
            }
        )

        # 创建scoped session工厂
        Session = scoped_session(
            sessionmaker(
                bind=engine,
                autocommit=False,
                autoflush=False
            )
        )

        logger.info("Database connection initialized successfully")

    except Exception as e:
        logger.error(f"Failed to initialize database connection: {str(e)}")
        raise


# 冷启动时初始化
try:
    initialize_db()
except Exception as e:
    logger.error(f"Initialization error: {str(e)}")

from sqlalchemy import Column, Integer, String, DateTime
from sqlalchemy.ext.declarative import declarative_base
import datetime

Base = declarative_base()


class ColorAIMatch(Base):
    __tablename__ = 'product_coloraimatch'

    id = Column(Integer, primary_key=True, autoincrement=True)
    input_color = Column(String(100))
    matched_color = Column(String(100))
    create_datetime = Column(DateTime)
    update_datetime = Column(DateTime)

    def __repr__(self):
        return f"{self.input_color} -> {self.matched_color}"

