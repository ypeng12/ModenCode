import os
from openai import OpenAI

from aws_lambda_powertools import Logger


logger = Logger()


class AIError(Exception):
    pass


class AIHelper:
    MODEL_V3 = "deepseek-chat"
    MODEL_R1 = "deepseek-reasoner"
    MODEL_GROK3 = "grok-2-latest"

    _model = MODEL_V3

    def __init__(self):
        self._ds_client = OpenAI(api_key=os.getenv("GROK_API_KEY"), base_url="https://api.x.ai/v1")

    def chat(self, user_prompt, system_prompt=""):
        try:
            logger.debug(f"create a request for ai client model:{self._model}")

            response = self._ds_client.chat.completions.create(
                model=self._model,
                messages=[
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": user_prompt},
                ],
                stream=False
            )
            logger.debug(f"get a response from {self._model}")
            return response.choices[0].message.content
        except Exception as e:
            raise AIError(e)

    def V3(self):
        self._model = self.MODEL_V3
        return self

    def R1(self):
        self._model = self.MODEL_R1
        return self

    def GROK3(self):
        self._model = self.MODEL_GROK3
        return self

    def current_model(self):
        return self._model

